import os
from ament_index_python.packages import get_package_share_directory
from launch import LaunchDescription
from launch.actions import IncludeLaunchDescription, SetEnvironmentVariable
from launch.launch_description_sources import PythonLaunchDescriptionSource
from launch_ros.actions import Node
from launch.actions import IncludeLaunchDescription, AppendEnvironmentVariable

def generate_launch_description():
    # 1. 获取包路径
    pkg_r1_pro = get_package_share_directory('r1_pro')
    pkg_ros_gz_sim = get_package_share_directory('ros_gz_sim')

    # 2. 设置 Gazebo 模型路径 (让 Gazebo 能找到 meshes)
    # 假设 meshes 在 r1_pro 包的上级目录 (即 src 目录)
    # 这里通过拼接路径动态设置环境变量
    # install_dir = os.path.dirname(os.path.dirname(pkg_r1_pro)) # 获取 install 目录
    # 注意：更稳妥的方式是把 mesh 路径写死或者指向源码目录，这里简化处理
    # 建议手动在终端 export GZ_SIM_RESOURCE_PATH，或者在这里硬编码 src 路径
    # 获取 install/r1_pro/share 目录
    pkg_r1_pro = get_package_share_directory('r1_pro')
    
    # 指向 install/r1_pro/share 的上一级，即 install/r1_pro
    # 这样 Gazebo 才能解析 package://r1_pro
    resource_path = os.path.dirname(pkg_r1_pro) 
    
    set_env = AppendEnvironmentVariable(
        name='GZ_SIM_RESOURCE_PATH',
        value=resource_path
    )
    
    
    # 3. 启动 Gazebo (替换 empty_world.launch)
    gazebo = IncludeLaunchDescription(
        PythonLaunchDescriptionSource(
            os.path.join(pkg_ros_gz_sim, 'launch', 'gz_sim.launch.py')
        ),
        # launch_arguments={'gz_args': '-r empty.sdf'}.items(),
        launch_arguments={'gz_args': 'empty.sdf'}.items(),
    )

    # 4. 生成机器人 (替换 spawn_model)
    spawn_entity = Node(
        package='ros_gz_sim',
        executable='create',
        arguments=[
            '-name', 'r1_pro',
            '-file', os.path.join(pkg_r1_pro, 'urdf', 'r1_pro.urdf'), # 确保文件名对
            '-z', '1.0' # 稍微抬高一点防止卡地里
        ],
        output='screen',
    )
    
    # 6. ROS-Gazebo 桥接
    bridge = Node(
        package='ros_gz_bridge',
        executable='parameter_bridge',
        parameters=[{
            # 确保这里的路径指向你刚才创建的 YAML 文件
            'config_file': os.path.join(pkg_r1_pro, 'config', 'data.yaml'),
            'qos_overrides./tf_static.publisher.durability': 'transient_local',
        }],
        output='screen'
    )

    # 5. 发布静态 TF (替换 tf static_transform_publisher)
    # ROS 2 中 args 格式是: x y z qx qy qz qw frame_id child_frame_id
    # 或者: x y z roll pitch yaw frame_id child_frame_id
    # static_tf = Node(
    #     package='tf2_ros',
    #     executable='static_transform_publisher',
    #     arguments=['0', '0', '0', '0', '0', '0', 'base_link', 'base_footprint'],
    #     output='screen'
    # )
    
    # 6. (可选) Robot State Publisher 
    # 读取 URDF 并发布 /robot_description 话题，这对 ROS 2 非常重要
    robot_state_publisher = Node(
        package='robot_state_publisher',
        executable='robot_state_publisher',
        parameters=[{'robot_description': open(os.path.join(pkg_r1_pro, 'urdf', 'r1_pro.urdf'), 'r').read()}]
    )

    return LaunchDescription([
        set_env,
        gazebo,
        robot_state_publisher, # 建议加上这个
        spawn_entity,
        # bridge
        # static_tf,
    ])