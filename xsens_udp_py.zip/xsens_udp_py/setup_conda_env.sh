#!/bin/bash

# Define environment name
ENV_NAME="xsens_env"

# Define colors
GREEN='\033[0;32m'
RED='\033[0;31m'
NC='\033[0m'

echo -e "${GREEN}Starting environment setup for XSens Control...${NC}"

# Check if conda/mamba/micromamba is installed
# Try to find conda if not in PATH
if ! command -v conda &> /dev/null; then
    # Common locations for conda
    POSSIBLE_LOCATIONS=(
        "/home/desaysv/WorkSpace/wss/code/teleop/xr_teleoperate/miniforge3/bin/conda"
        "$HOME/anaconda3/bin/conda"
        "$HOME/miniconda3/bin/conda"
        "$HOME/miniforge3/bin/conda"
        "/opt/conda/bin/conda"
        "/opt/anaconda3/bin/conda"
        "/opt/miniconda3/bin/conda"
        "$HOME/.conda/bin/conda"
    )
    
    for loc in "${POSSIBLE_LOCATIONS[@]}"; do
        if [ -f "$loc" ]; then
            echo -e "${GREEN}Found conda at $loc${NC}"
            export PATH="$(dirname "$loc"):$PATH"
            break
        fi
    done
fi

if command -v conda &> /dev/null; then
    CMD="conda"
elif command -v mamba &> /dev/null; then
    CMD="mamba"
elif command -v micromamba &> /dev/null; then
    CMD="micromamba"
else
    echo -e "${RED}Error: No Conda-compatible package manager found.${NC}"
    echo "Please install Miniforge (recommended) or Anaconda/Miniconda first."
    echo "Download: https://github.com/conda-forge/miniforge/releases"
    exit 1
fi

echo -e "${GREEN}Using package manager: $CMD${NC}"

# Create environment with specific versions from conda-forge
# Pinocchio with CasADi support is ONLY available reliably via conda-forge
if $CMD env list | grep -q "$ENV_NAME"; then
    echo "Environment '$ENV_NAME' already exists. Updating..."
else
    echo "Creating new environment '$ENV_NAME'..."
    $CMD create -n $ENV_NAME -c conda-forge python=3.8 -y
fi

# Activate environment (workaround for shell script)
eval "$($CMD shell.bash hook)"
$CMD activate $ENV_NAME

echo -e "${GREEN}Installing dependencies from conda-forge...${NC}"
# Installing everything from conda-forge ensures binary compatibility
# Specifically pinocchio + casadi + numpy compatibility
$CMD install -c conda-forge -y \
    python=3.8 \
    "pinocchio>=2.6" \
    "casadi>=3.5" \
    "numpy<2.0" \
    scipy \
    ipopt

echo -e "${GREEN}Environment '$ENV_NAME' setup complete!${NC}"
echo ""
echo "To run the project, use the provided run script:"
echo "  ./run_with_conda.sh"
