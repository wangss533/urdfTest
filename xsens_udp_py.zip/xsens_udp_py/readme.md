<!--
 * @Author: uidq5094 Saisai.Wang@desaysv.com
 * @Date: 2026-01-30 17:33:26
 * @LastEditors: uidq5094 Saisai.Wang@desaysv.com
 * @LastEditTime: 2026-01-30 21:15:42
 * @FilePath: \xsens_udp_py\readme.md
 * @Description: 这是默认设置,请设置`customMade`, 打开koroFileHeader查看配置 进行设置: https://github.com/OBKoro1/koro1FileHeader/wiki/%E9%85%8D%E7%BD%AE
-->

<!-- 播包 -->
conda activate common
.\data\broadcast.bat


<!-- 运行 -->
conda activate xsens_env
run_sender.bat --loop

python xsens_ik_solver_integration.py --enable-smooth-start

python xsens_ik_solver_integration.py --enable-smooth-start --use-new-limits