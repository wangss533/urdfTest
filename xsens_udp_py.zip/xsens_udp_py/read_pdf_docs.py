import sys
import os

output_file = "pdf_content.txt"

def log(msg):
    with open(output_file, "a", encoding="utf-8") as f:
        f.write(msg + "\n")
    print(msg)

if os.path.exists(output_file):
    os.remove(output_file)

PdfReader = None
try:
    from pypdf import PdfReader
    log("Using pypdf")
except ImportError:
    try:
        from PyPDF2 import PdfReader
        log("Using PyPDF2")
    except ImportError:
        log("Neither pypdf nor PyPDF2 is installed")
        sys.exit(1)

def read_pdf(file_path):
    if not os.path.exists(file_path):
        log(f"File not found: {file_path}")
        return

    try:
        reader = PdfReader(file_path)
        log(f"--- Extracting text from: {file_path} ---")
        log(f"Number of pages: {len(reader.pages)}")
        
        for i, page in enumerate(reader.pages):
            text = page.extract_text()
            log(f"\n--- Page {i+1} ---")
            log(text)
            
    except Exception as e:
        log(f"Error reading PDF: {e}")

if __name__ == "__main__":
    pdf_path = r"D:\wss\13.Projrct\34.robot\code\00.ik_code_py\xsens_udp_py\docs\双臂二次开发文档.pdf"
    read_pdf(pdf_path)
