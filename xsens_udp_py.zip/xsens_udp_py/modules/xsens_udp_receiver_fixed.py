#!/usr/bin/env python3
"""
修复版本的XSens UDP接收器
适配broadcast.sh发送的实际数据格式
"""

import socket
import struct
import time
import threading
from typing import Optional, Callable

# Use relative import for module structure
from .xsens_data_types import (
    XsensData,
    XsensJointData,
    XsensLinkData,
    XsensLinkState,
    XsensQuaternion,
    XsensTwist,
    XsensCenterOfMassData
)


class XSensUDPReceiverFixed:
    """修复版本的XSens UDP接收器"""
    
    def __init__(self, ip: str = "0.0.0.0", port: int = 9763, buffer_size: int = 10000):
        self.ip = ip
        self.port = port
        self.buffer_size = buffer_size
        self.socket = None
        self.is_running = False
        self.receive_thread = None
        self.data_callback = None
        self.frame_counter = 0
        
        # 数据存储
        self.joint_angles_data = None
        self.quaternion_data = None
        self.linear_kinematics_data = None
        self.angular_kinematics_data = None
        self.com_data = None
        
        # 模型构建标志
        self.model_built = False
        self.link_names = []
        self.joint_names = []
        
        # XSens模型名称映射（与C++版本一致）
        self.xsens_links = [
            "base_link",
            "pelvis", "l5", "l3", "t12", "t8", "neck", "head",
            "right_shoulder", "right_upper_arm", "right_forearm", "right_hand",
            "left_shoulder", "left_upper_arm", "left_forearm", "left_hand",
            "right_upper_leg", "right_lower_leg", "right_foot", "right_toe",
            "left_upper_leg", "left_lower_leg", "left_foot", "left_toe",
            "generic_link"
        ]
        
        self.xsens_joints = [
            "l5_s1", "l4_l3", "l1_t12", "t9_t8", "t1_c7", "c1_head",
            "right_c7_shoulder", "right_shoulder", "right_elbow", "right_wrist",
            "left_c7_shoulder", "left_shoulder", "left_elbow", "left_wrist",
            "right_hip", "right_knee", "right_ankle", "right_ballfoot",
            "left_hip", "left_knee", "left_ankle", "left_ballfoot"
        ]
    
    def set_data_callback(self, callback: Callable[[XsensData], None]):
        """设置数据回调函数"""
        self.data_callback = callback
    
    def initialize(self) -> bool:
        """初始化UDP socket"""
        try:
            # 创建socket
            self.socket = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            
            # 设置socket选项
            self.socket.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
            self.socket.setsockopt(socket.SOL_SOCKET, socket.SO_RCVBUF, self.buffer_size)
            
            # 绑定到指定地址和端口
            self.socket.bind((self.ip, self.port))
            
            # 设置非阻塞
            self.socket.setblocking(False)
            
            print(f"XSens UDP Receiver initialized on {self.ip}:{self.port}")
            return True
            
        except Exception as e:
            print(f"Failed to initialize socket: {e}")
            return False
    
    def start_receiving(self) -> bool:
        """开始接收数据"""
        if self.is_running:
            print("Receiver is already running")
            return False
        
        if not self.socket:
            if not self.initialize():
                print("Failed to initialize socket")
                return False
        
        self.is_running = True
        self.receive_thread = threading.Thread(target=self._receive_loop, daemon=True)
        self.receive_thread.start()
        print("XSens UDP Receiver started")
        return True
    
    def stop_receiving(self):
        """停止接收数据"""
        self.is_running = False
        if self.receive_thread:
            self.receive_thread.join(timeout=2)
        if self.socket:
            self.socket.close()
        print("XSens UDP Receiver stopped")
    
    def _receive_loop(self):
        """接收循环"""
        print("Receive loop started")
        
        while self.is_running:
            try:
                # 接收数据
                data = self.socket.recv(self.buffer_size)
                
                if len(data) > 0:
                    # 解析数据包
                    self._parse_datagram(data)
                    
                    # 如果有数据回调，调用它
                    if self.data_callback:
                        # 构建并传递数据
                        xsens_data = self._build_xsens_data()
                        if xsens_data:
                            self.data_callback(xsens_data)
                
            except BlockingIOError:
                # 没有数据，继续循环
                time.sleep(0.01)
                continue
            except Exception as e:
                if self.is_running:
                    print(f"Error receiving data: {e}")
                break
        
        print("Receive loop stopped")
    
    def _parse_datagram(self, data: bytes):
        """解析XSens数据包"""
        if len(data) < 12:
            return
        
        # 检查是否是MXTP格式
        if len(data) >= 4 and data[:4] != b'MXTP':
            print(f"Not MXTP format: {data[:4]}")
            return
        
        # 修复：解析消息类型（字符串形式）
        if len(data) >= 6:
            msg_type_str = data[4:6].decode('ascii', errors='ignore').strip()
            
            # 映射消息类型
            msg_type_map = {
                '02': 0x02,  # Quaternion
                '20': 0x20,  # JointAngles
                '21': 0x21,  # LinearSegmentKinematics
                '22': 0x22,  # AngularSegmentKinematics
                '24': 0x24   # CenterOfMass
            }
            
            if msg_type_str in msg_type_map:
                message_type = msg_type_map[msg_type_str]
                # print(f"Received message type: {msg_type_str} ({hex(message_type)})")
                
                # 根据消息类型解析数据
                if message_type == 0x20:
                    self._parse_joint_angles(data)
                elif message_type == 0x02:
                    self._parse_quaternion(data)
                elif message_type == 0x21:
                    self._parse_linear_kinematics(data)
                elif message_type == 0x22:
                    self._parse_angular_kinematics(data)
                elif message_type == 0x24:
                    self._parse_com(data)
            else:
                print(f"Unknown message type: '{msg_type_str}'")
        else:
            print(f"Data too short: {len(data)} bytes")
    
    def _parse_joint_angles(self, data: bytes):
        """解析关节角度数据"""
        try:
            offset = 24
            joint_angles = []
            
            # 每个关节数据包大小为20字节
            # 4 bytes parent (segment_id * 256 + point_id)
            # 4 bytes child (segment_id * 256 + point_id)
            # 12 bytes rotation (3 floats)
            while offset + 20 <= len(data):
                # 使用大端序解析
                parent = struct.unpack('>i', data[offset:offset+4])[0]
                child = struct.unpack('>i', data[offset+4:offset+8])[0]
                rotation = struct.unpack('>3f', data[offset+8:offset+20])
                
                # 计算segment id
                parent_segment_id = parent // 256
                child_segment_id = child // 256
                
                joint_angles.append({
                    'parent': parent,
                    'child': child,
                    'parent_segment_id': parent_segment_id,
                    'child_segment_id': child_segment_id,
                    'rotation': list(rotation),
                    'sample_counter': 0,
                    'frame_time': 0,
                    'datagram_counter': 0
                })
                offset += 20
            
            self.joint_angles_data = joint_angles
            # print(f"Parsed {len(joint_angles)} joint angles")
            
        except Exception as e:
            print(f"Error parsing joint angles: {e}")
    
    def _parse_quaternion(self, data: bytes):
        """解析四元数数据"""
        try:
            offset = 24  # 数据包头部是24字节
            quaternions = []
            index = 0
            
            while offset + 32 <= len(data):
                # 使用大端序解析
                # 读取segment ID (4字节）
                segment_id = struct.unpack('>i', data[offset:offset+4])[0]
                
                # 读取sensor position (12字节，3个float）
                sensor_pos = struct.unpack('>3f', data[offset+4:offset+16])
                
                # 读取quaternion rotation (16字节，4个float）
                # C++定义顺序为: re(w), i(x), j(y), k(z)
                quat_rotation = struct.unpack('>4f', data[offset+16:offset+32])
                
                # 调试信息
                # if index < 3:
                #     print(f"  Segment {index}: segment_id={segment_id}, pos={sensor_pos}, quat={quat_rotation}")
                
                quaternions.append({
                    'segment_id': segment_id,
                    'sensor_pos': list(sensor_pos),
                    'quat_rotation': list(quat_rotation), # w, x, y, z
                    'sample_counter': 0,
                    'frame_time': 0,
                    'datagram_counter': 0
                })
                offset += 32
                index += 1
            
            self.quaternion_data = quaternions
            # print(f"Parsed {len(quaternions)} quaternions")
            
        except Exception as e:
            print(f"Error parsing quaternion: {e}")
    
    def _parse_linear_kinematics(self, data: bytes):
        """解析线性运动学数据"""
        try:
            offset = 24  # 数据包头部是24字节
            linear_kinematics = []
            
            while offset + 36 <= len(data):
                # 使用大端序解析
                segment_id = struct.unpack('>i', data[offset:offset+4])[0]
                velocity = struct.unpack('>3f', data[offset+4:offset+16])
                acceleration = struct.unpack('>3f', data[offset+16:offset+28])
                
                linear_kinematics.append({
                    'segment_id': segment_id,
                    'velocity': list(velocity),
                    'acceleration': list(acceleration),
                    'sample_counter': 0,
                    'frame_time': 0,
                    'datagram_counter': 0
                })
                offset += 36
            
            self.linear_kinematics_data = linear_kinematics
            # print(f"Parsed {len(linear_kinematics)} linear kinematics")
            
        except Exception as e:
            print(f"Error parsing linear kinematics: {e}")
    
    def _parse_angular_kinematics(self, data: bytes):
        """解析角运动学数据"""
        try:
            offset = 24  # 修正offset为24
            angular_kinematics = []
            
            while offset + 28 <= len(data):
                # 使用大端序解析
                segment_id = struct.unpack('>i', data[offset:offset+4])[0]
                angular_velocity = struct.unpack('>3f', data[offset+4:offset+16])
                angular_acceleration = struct.unpack('>3f', data[offset+16:offset+28])
                
                angular_kinematics.append({
                    'segment_id': segment_id,
                    'angular_velocity': list(angular_velocity),
                    'angular_acceleration': list(angular_acceleration),
                    'sample_counter': 0,
                    'frame_time': 0,
                    'datagram_counter': 0
                })
                offset += 28
            
            self.angular_kinematics_data = angular_kinematics
            # print(f"Parsed {len(angular_kinematics)} angular kinematics")
            
        except Exception as e:
            print(f"Error parsing angular kinematics: {e}")
    
    def _parse_com(self, data: bytes):
        """解析质心数据"""
        try:
            offset = 24 # 修正offset为24
            if offset + 12 <= len(data):
                # 使用大端序解析
                com_data = struct.unpack('>3f', data[offset:offset+12])
                
                self.com_data = {
                    'com': list(com_data),
                    'sample_counter': 0,
                    'frame_time': 0,
                    'datagram_counter': 0
                }
                # print(f"Parsed COM data: {list(com_data)}")
        except Exception as e:
            print(f"Error parsing COM: {e}")
    
    def _multiply_quaternions(self, q1: XsensQuaternion, q2: XsensQuaternion) -> XsensQuaternion:
        """
        Multiply two quaternions: q_out = q1 * q2
        q1: XsensQuaternion (w, x, y, z)
        q2: XsensQuaternion (w, x, y, z)
        """
        w1, x1, y1, z1 = q1.w, q1.x, q1.y, q1.z
        w2, x2, y2, z2 = q2.w, q2.x, q2.y, q2.z
        
        w = w1*w2 - x1*x2 - y1*y2 - z1*z2
        x = w1*x2 + x1*w2 + y1*z2 - z1*y2
        y = w1*y2 - x1*z2 + y1*w2 + z1*x2
        z = w1*z2 + x1*y2 - y1*x2 + z1*w2
        
        return XsensQuaternion(x=x, y=y, z=z, w=w)

    def _build_xsens_data(self) -> Optional[XsensData]:
        """构建XsensData对象"""
        try:
            xsens_data = XsensData()
            
            # 更新关节数据
            if self.joint_angles_data:
                for i, joint_angle in enumerate(self.joint_angles_data):
                    if i < len(self.xsens_joints):
                        joint_data = XsensJointData()
                        joint_data.name = self.xsens_joints[i]
                        joint_data.angles = [
                            joint_angle['rotation'][0] * 3.14159 / 180.0,
                            joint_angle['rotation'][1] * 3.14159 / 180.0,
                            joint_angle['rotation'][2] * 3.14159 / 180.0
                        ]
                        xsens_data.joint_data.append(joint_data)
            
            # 更新链接数据
            if self.quaternion_data:
                # 修正旋转四元数 (w, x, y, z)
                # 对应C++: Eigen::Quaterniond quat_x_rot_90pos(0.7071068, 0.7071068, 0.0, 0.0);
                quat_x_rot_90pos = XsensQuaternion(w=0.7071068, x=0.7071068, y=0.0, z=0.0)
                # 对应C++: Eigen::Quaterniond quat_x_rot_90neg(0.7071068, -0.7071068, 0.0, 0.0);
                quat_x_rot_90neg = XsensQuaternion(w=0.7071068, x=-0.7071068, y=0.0, z=0.0)
                
                left_arm_links = ["left_upper_arm", "left_forearm", "left_hand"]
                right_arm_links = ["right_upper_arm", "right_forearm", "right_hand"]

                for quat in self.quaternion_data:
                    segment_id = quat['segment_id']
                    
                    # segment ID可以直接作为索引（假设xsens_links与C++定义一致，且ID对应索引）
                    link_index = segment_id
                    if 0 <= link_index < len(self.xsens_links):
                        link_name = self.xsens_links[link_index]
                        link_data = XsensLinkData()
                        link_data.name = link_name
                        
                        link_state = XsensLinkState()
                        link_state.position = quat['sensor_pos']
                        # 创建XsensQuaternion对象，注意四元数的顺序已经在_parse_quaternion中调整为(w, x, y, z)
                        original_quat = XsensQuaternion(
                            x=quat['quat_rotation'][1],
                            y=quat['quat_rotation'][2],
                            z=quat['quat_rotation'][3],
                            w=quat['quat_rotation'][0]
                        )
                        
                        # 应用额外的旋转修正，与C++保持一致
                        # rotateLink("right_...", quat_x_rot_90neg);
                        # rotateLink("left_...", quat_x_rot_90pos);
                        # orientation = orientation * quat (Local Rotation)
                        
                        if link_name in left_arm_links:
                            link_state.orientation = self._multiply_quaternions(original_quat, quat_x_rot_90pos)
                        elif link_name in right_arm_links:
                            link_state.orientation = self._multiply_quaternions(original_quat, quat_x_rot_90neg)
                        else:
                            link_state.orientation = original_quat
                            
                        link_data.link_state = link_state
                        xsens_data.link_data.append(link_data)
                    else:
                        # print(f"segment_id {segment_id} 超出范围 (1-{len(self.xsens_links)})")
                        pass
            
            # 更新质心数据
            if self.com_data:
                xsens_data.com_data.com_data = self.com_data['com']
            
            # 更新帧ID和时间戳
            self.frame_counter += 1
            xsens_data.frame_id = self.frame_counter
            xsens_data.time_stamp = int(time.time() * 1000)
            
            return xsens_data
            
        except Exception as e:
            print(f"Error building XsensData: {e}")
            return None


def main():
    """主函数"""
    print("="*60)
    print("XSens UDP接收器（修复版本）")
    print("="*60)
    
    # 创建接收器
    receiver = XSensUDPReceiverFixed()
    
    # 初始化
    if not receiver.initialize():
        print("Initialization failed!")
        return
    
    # 开始接收
    if not receiver.start_receiving():
        print("Failed to start receiving!")
        return
    
    print("\n开始接收数据...")
    print("按 Ctrl+C 停止接收")
    
    try:
        # 保持运行
        while True:
            time.sleep(1)
    except KeyboardInterrupt:
        print("\n停止接收器...")
        receiver.stop_receiving()


if __name__ == "__main__":
    main()
