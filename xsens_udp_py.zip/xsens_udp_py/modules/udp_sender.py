r'''
Author: uidq5094 Saisai.Wang@desaysv.com
Date: 2026-01-30 09:15:12
LastEditors: uidq5094 Saisai.Wang@desaysv.com
LastEditTime: 2026-01-30 11:23:34
FilePath: \xsens_udp_py\modules\udp_sender.py
Description: 这是默认设置,请设置`customMade`, 打开koroFileHeader查看配置 进行设置: https://github.com/OBKoro1/koro1FileHeader/wiki/%E9%85%8D%E7%BD%AE
'''
import socket
import json

class UDPSender:
    def __init__(self, ip="192.168.2.16", port=9001):
        self.ip = ip
        self.port = port
        self.socket = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        self.socket.setblocking(False) # Non-blocking mode
        print(f"UDP Sender initialized, target: {self.ip}:{self.port}")

    def receive_feedback(self):
        """
        Receive robot feedback
        Returns: dict or None
        """
        try:
            data, _ = self.socket.recvfrom(4096)
            json_str = data.decode('utf-8')
            return json.loads(json_str)
        except BlockingIOError:
            return None
        except socket.timeout:
            return None
        except Exception as e:
            # print(f"Error receiving data: {e}")
            return None

    def send_control_command(self, joint_angles_left, joint_angles_right, start_flag=None, switch_on=None, try_lock=None):
        """
        Send joint control command via UDP
        joint_angles_left: list of 7 floats (radians)
        joint_angles_right: list of 7 floats (radians)
        start_flag: bool or None, StartFlag (None to omit)
        switch_on: bool or None, SwitchOn (None to omit)
        try_lock: bool or None, tryLock (None to omit)
        """
        # Construct the JSON payload according to documentation
        
        # Based on udp_demo.cpp logic:
        # 1. StartFlag: {"StartFlag": true/false}
        # 2. SwitchOn: {"SwitchOn": true/false}
        # 3. tryLock: {"tryLock": true/false}
        # 4. Control Data: {"Robot": {...}, "RightArm": {...}}
        
        # If any of the flags is set, send a separate packet for it
        if start_flag is not None:
            self._send_json({"StartFlag": start_flag})
            return # Usually flags are sent separately

        if switch_on is not None:
            self._send_json({"SwitchOn": switch_on})
            return

        if try_lock is not None:
            self._send_json({"tryLock": try_lock})
            return

        # If no flags are set, send control data
        # We only set P (Position), others can be 0
        zeros_7 = [0.0] * 7
        
        payload = {
            "Robot": {
                "P": joint_angles_left,
                "V": zeros_7,
                "T": zeros_7,
                "kp": zeros_7,
                "kd": zeros_7
            },
            "RightArm": {
                "P": joint_angles_right,
                "V": zeros_7,
                "T": zeros_7,
                "kp": zeros_7,
                "kd": zeros_7
            }
        }
        
        self._send_json(payload)

    def _send_json(self, payload):
        try:
            json_str = json.dumps(payload)
            self.socket.sendto(json_str.encode('utf-8'), (self.ip, self.port))
            # print(f"Sent UDP command to {self.ip}:{self.port}")
        except Exception as e:
            print(f"Error sending UDP command: {e}")
