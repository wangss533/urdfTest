#!/usr/bin/env python3
"""
手臂映射模块
根据XSens数据计算手臂末端在肩膀坐标系中的位置和姿态
参考C++实现：xsensDataMap.cpp::armToshoulderCoordinate
"""

import numpy as np
from typing import Tuple, Optional
from dataclasses import dataclass

from .xsens_data_types import (
    XsensData,
    XsensLinkData,
    XsensQuaternion
)


@dataclass
class ArmMappingResult:
    """手臂映射结果"""
    shoulder_name: str  # 肩膀名称（left_shoulder 或 right_shoulder）
    end_effector_position: np.ndarray  # 末端位置 [x, y, z]
    end_effector_orientation: np.ndarray  # 末端姿态（旋转矩阵 3x3）
    end_effector_orientation_quat: np.ndarray  # 末端姿态（四元数 [x, y, z, w]）
    arm_length: float  # 手臂长度
    success: bool = True  # 是否成功


class ArmMapper:
    """手臂映射器"""
    
    def __init__(self):
        # 肩膀相对于躯干的位置（单位：米）
        self.left_shoulder_pos_torso = np.array([0.0, 0.1243, 0.0])
        self.right_shoulder_pos_torso = np.array([0.0, -0.1243, 0.0])
        
        # 比例因子（手臂长度缩放）
        self.ration = 1.2
        
        # 链接名称映射
        self.link_name_map = {
            'left_shoulder': 'left_shoulder',
            'left_upper_arm': 'left_upper_arm',
            'left_forearm': 'left_forearm',
            'left_hand': 'left_hand',
            'right_shoulder': 'right_shoulder',
            'right_upper_arm': 'right_upper_arm',
            'right_forearm': 'right_forearm',
            'right_hand': 'right_hand'
        }
    
    def quaternion_to_rotation_matrix(self, quat: XsensQuaternion) -> np.ndarray:
        """
        将四元数转换为旋转矩阵
        
        Args:
            quat: 四元数 [x, y, z, w]
            
        Returns:
            3x3 旋转矩阵
        """
        x, y, z, w = quat.x, quat.y, quat.z, quat.w
        
        # 归一化四元数
        norm = np.sqrt(x*x + y*y + z*z + w*w)
        if norm > 0:
            x, y, z, w = x/norm, y/norm, z/norm, w/norm
        
        # 转换为旋转矩阵
        R = np.array([
            [1 - 2*(y*y + z*z), 2*(x*y - z*w), 2*(x*z + y*w)],
            [2*(x*y + z*w), 1 - 2*(x*x + z*z), 2*(y*z - x*w)],
            [2*(x*z - y*w), 2*(y*z + x*w), 1 - 2*(x*x + y*y)]
        ])
        
        return R
    
    def get_link_data(self, xsens_data: XsensData, link_name: str) -> Optional[XsensLinkData]:
        """
        从XSens数据中获取指定链接的数据
        
        Args:
            xsens_data: XSens数据
            link_name: 链接名称
            
        Returns:
            链接数据，如果找不到则返回None
        """
        # 调试信息：打印所有可用的链接名称
        # available_links = [link.name for link in xsens_data.link_data]
        # print(f"查找链接 '{link_name}'，可用链接: {available_links}")
        
        for link in xsens_data.link_data:
            if link.name == link_name:
                # print(f"找到链接 '{link_name}'，位置: {link.link_state.position}")
                return link
        # print(f"未找到链接 '{link_name}'")
        return None
    
    def arm_to_shoulder_coordinate(
        self,
        xsens_data: XsensData,
        shoulder_name: str
    ) -> ArmMappingResult:
        """
        将手臂数据转换到肩膀坐标系
        
        参考C++实现：armToshoulderCoordinate
        
        Args:
            xsens_data: XSens数据
            shoulder_name: 肩膀名称（"left_shoulder" 或 "right_shoulder"）
            
        Returns:
            ArmMappingResult: 映射结果
        """
        # 验证输入
        if shoulder_name not in ["left_shoulder", "right_shoulder"]:
            return ArmMappingResult(
                shoulder_name=shoulder_name,
                end_effector_position=np.zeros(3),
                end_effector_orientation=np.eye(3),
                end_effector_orientation_quat=np.array([0.0, 0.0, 0.0, 1.0]),
                arm_length=0.0,
                success=False
            )
        
        # 获取肩膀和手的数据
        shoulder_link = self.get_link_data(xsens_data, shoulder_name)
        hand_link_name = "left_hand" if shoulder_name == "left_shoulder" else "right_hand"
        hand_link = self.get_link_data(xsens_data, hand_link_name)
        
        if shoulder_link is None or hand_link is None:
            return ArmMappingResult(
                shoulder_name=shoulder_name,
                end_effector_position=np.zeros(3),
                end_effector_orientation=np.eye(3),
                end_effector_orientation_quat=np.array([0.0, 0.0, 0.0, 1.0]),
                arm_length=0.0,
                success=False
            )
        
        # 检查手的位置是否有效
        hand_pos = np.array(hand_link.link_state.position)
        if np.all(hand_pos == 0.0):
            return ArmMappingResult(
                shoulder_name=shoulder_name,
                end_effector_position=np.zeros(3),
                end_effector_orientation=np.eye(3),
                end_effector_orientation_quat=np.array([0.0, 0.0, 0.0, 1.0]),
                arm_length=0.0,
                success=False
            )
        
        # 获取肩膀的全局位置和姿态
        P_shoulder = np.array(shoulder_link.link_state.position)
        Q_shoulder = shoulder_link.link_state.orientation
        R_shoulder = self.quaternion_to_rotation_matrix(Q_shoulder)
        # print(f"肩膀位置: {P_shoulder}")
        # print(f"肩膀姿态: {Q_shoulder}")
        
        # 获取手的全局位置和姿态
        P_hand = np.array(hand_link.link_state.position)
        Q_hand = hand_link.link_state.orientation
        R_hand = self.quaternion_to_rotation_matrix(Q_hand)
        # print(f"手位置: {P_hand}")
        # print(f"手姿态: {Q_hand}")
        
        # 计算手相对于肩膀的位置差（全局坐标系）
        delta_P = P_hand - P_shoulder
        
        # 计算手臂长度
        arm_length = np.linalg.norm(delta_P)
        
        # 转换到肩膀坐标系
        # P_hand_shoulder = R_shoulder^T * delta_P
        P_hand_shoulder = R_shoulder.T @ delta_P
        
        # R_hand_shoulder = R_shoulder^T * R_hand
        R_hand_shoulder = R_shoulder.T @ R_hand
        
        # 应用比例因子
        P_hand_shoulder *= self.ration
        
        # 检查转换后的位置是否有效
        if np.all(P_hand_shoulder == 0.0):
            return ArmMappingResult(
                shoulder_name=shoulder_name,
                end_effector_position=np.zeros(3),
                end_effector_orientation=np.eye(3),
                end_effector_orientation_quat=np.array([0.0, 0.0, 0.0, 1.0]),
                arm_length=0.0,
                success=False
            )
        
        # 获取肩膀相对于躯干的位置
        if shoulder_name == "left_shoulder":
            P_shoulder_torso = self.left_shoulder_pos_torso.copy()
        else:
            P_shoulder_torso = self.right_shoulder_pos_torso.copy()
        
        # 添加肩膀相对于躯干的位置偏移
        P_hand_shoulder += P_shoulder_torso
        
        # 计算四元数姿态
        end_effector_quat = self.rotation_matrix_to_quaternion(R_hand_shoulder)
        
        # 返回结果
        return ArmMappingResult(
            shoulder_name=shoulder_name,
            end_effector_position=P_hand_shoulder,
            end_effector_orientation=R_hand_shoulder,
            end_effector_orientation_quat=end_effector_quat,
            arm_length=arm_length,
            success=True
        )
    
    def map_both_arms(self, xsens_data: XsensData) -> Tuple[ArmMappingResult, ArmMappingResult]:
        """
        同时映射左右手臂
        
        Args:
            xsens_data: XSens数据
            
        Returns:
            (left_arm_result, right_arm_result): 左右手臂的映射结果
        """
        left_result = self.arm_to_shoulder_coordinate(xsens_data, "left_shoulder")
        right_result = self.arm_to_shoulder_coordinate(xsens_data, "right_shoulder")
        
        return left_result, right_result
    
    def print_mapping_result(self, result: ArmMappingResult):
        """
        打印映射结果
        
        Args:
            result: 映射结果
        """
        if not result.success:
            print(f"{result.shoulder_name}: 映射失败")
            return
        
        print(f"\n{'='*60}")
        print(f"{result.shoulder_name} 手臂映射结果")
        print(f"{'='*60}")
        print(f"手臂长度: {result.arm_length:.4f} 米")
        print(f"\n末端位置 (肩膀坐标系):")
        print(f"  X: {result.end_effector_position[0]:.6f} 米")
        print(f"  Y: {result.end_effector_position[1]:.6f} 米")
        print(f"  Z: {result.end_effector_position[2]:.6f} 米")
        
        print(f"\n末端姿态 (旋转矩阵):")
        for i in range(3):
            print(f"  [{result.end_effector_orientation[i,0]:.4f}, "
                  f"{result.end_effector_orientation[i,1]:.4f}, "
                  f"{result.end_effector_orientation[i,2]:.4f}]")
        
        # 计算欧拉角
        euler_angles = self.rotation_matrix_to_euler(result.end_effector_orientation)
        print(f"\n末端姿态 (欧拉角):")
        print(f"  Roll:  {np.degrees(euler_angles[0]):.2f}°")
        print(f"  Pitch: {np.degrees(euler_angles[1]):.2f}°")
        print(f"  Yaw:   {np.degrees(euler_angles[2]):.2f}°")
        print(f"{'='*60}")
    
    def rotation_matrix_to_euler(self, R: np.ndarray) -> np.ndarray:
        """
        将旋转矩阵转换为欧拉角（ZYX顺序）
        
        Args:
            R: 3x3 旋转矩阵
            
        Returns:
            欧拉角 [roll, pitch, yaw] (弧度)
        """
        # 从旋转矩阵提取欧拉角
        sy = np.sqrt(R[0,0]**2 + R[1,0]**2)
        
        singular = sy < 1e-6
        
        if not singular:
            roll = np.arctan2(R[2,1], R[2,2])
            pitch = np.arctan2(-R[2,0], sy)
            yaw = np.arctan2(R[1,0], R[0,0])
        else:
            roll = np.arctan2(-R[1,2], R[1,1])
            pitch = np.arctan2(-R[2,0], sy)
            yaw = 0
        
        return np.array([roll, pitch, yaw])
    
    def rotation_matrix_to_quaternion(self, R: np.ndarray) -> np.ndarray:
        """
        将旋转矩阵转换为四元数 [x, y, z, w]
        
        Args:
            R: 3x3 旋转矩阵
            
        Returns:
            四元数 [x, y, z, w]
        """
        # 计算四元数
        trace = np.trace(R)
        
        if trace > 0:
            s = 0.5 / np.sqrt(trace + 1.0)
            w = 0.25 / s
            x = (R[2, 1] - R[1, 2]) * s
            y = (R[0, 2] - R[2, 0]) * s
            z = (R[1, 0] - R[0, 1]) * s
        else:
            if R[0, 0] > R[1, 1] and R[0, 0] > R[2, 2]:
                s = 2.0 * np.sqrt(1.0 + R[0, 0] - R[1, 1] - R[2, 2])
                w = (R[2, 1] - R[1, 2]) / s
                x = 0.25 * s
                y = (R[0, 1] + R[1, 0]) / s
                z = (R[0, 2] + R[2, 0]) / s
            elif R[1, 1] > R[2, 2]:
                s = 2.0 * np.sqrt(1.0 + R[1, 1] - R[0, 0] - R[2, 2])
                w = (R[0, 2] - R[2, 0]) / s
                x = (R[0, 1] + R[1, 0]) / s
                y = 0.25 * s
                z = (R[1, 2] + R[2, 1]) / s
            else:
                s = 2.0 * np.sqrt(1.0 + R[2, 2] - R[0, 0] - R[1, 1])
                w = (R[1, 0] - R[0, 1]) / s
                x = (R[0, 2] + R[2, 0]) / s
                y = (R[1, 2] + R[2, 1]) / s
                z = 0.25 * s
        
        # 归一化四元数
        norm = np.sqrt(x*x + y*y + z*z + w*w)
        if norm > 0:
            x, y, z, w = x/norm, y/norm, z/norm, w/norm
            
        return np.array([x, y, z, w])
    
    def get_arm_parameters(self, xsens_data: XsensData, shoulder_name: str) -> dict:
        """
        获取手臂的详细参数信息
        
        Args:
            xsens_data: XSens数据
            shoulder_name: 肩膀名称
            
        Returns:
            包含手臂参数的字典
        """
        # 获取映射结果
        result = self.arm_to_shoulder_coordinate(xsens_data, shoulder_name)
        
        if not result.success:
            return {
                'shoulder_name': shoulder_name,
                'success': False,
                'error': 'Mapping failed'
            }
        
        # 获取手臂各链接数据
        arm_links = []
        if shoulder_name == "left_shoulder":
            link_names = ['left_shoulder', 'left_upper_arm', 'left_forearm', 'left_hand']
        else:
            link_names = ['right_shoulder', 'right_upper_arm', 'right_forearm', 'right_hand']
        
        for link_name in link_names:
            link = self.get_link_data(xsens_data, link_name)
            if link is not None:
                arm_links.append({
                    'name': link_name,
                    'position': link.link_state.position,
                    'orientation': {
                        'x': link.link_state.orientation.x,
                        'y': link.link_state.orientation.y,
                        'z': link.link_state.orientation.z,
                        'w': link.link_state.orientation.w
                    },
                    'velocity': {
                        'linear': link.link_state.velocity.linear,
                        'angular': link.link_state.velocity.angular
                    }
                })
        
        # 计算欧拉角
        euler_angles = self.rotation_matrix_to_euler(result.end_effector_orientation)
        
        return {
            'shoulder_name': shoulder_name,
            'success': True,
            'arm_length': result.arm_length,
            'end_effector': {
                'position': result.end_effector_position.tolist(),
                'orientation_matrix': result.end_effector_orientation.tolist(),
                'euler_angles': {
                    'roll': float(np.degrees(euler_angles[0])),
                    'pitch': float(np.degrees(euler_angles[1])),
                    'yaw': float(np.degrees(euler_angles[2]))
                }
            },
            'links': arm_links,
            'shoulder_pos_torso': self.left_shoulder_pos_torso.tolist() if shoulder_name == "left_shoulder" 
                               else self.right_shoulder_pos_torso.tolist(),
            'ration': self.ration
        }
