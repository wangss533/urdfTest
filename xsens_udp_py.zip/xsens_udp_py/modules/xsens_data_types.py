#!/usr/bin/env python3
"""
XSens数据类型定义
包含所有XSens相关的数据结构
"""

from dataclasses import dataclass, field
from typing import List


@dataclass
class XsensTwist:
    """速度和加速度数据结构"""
    linear: List[float] = field(default_factory=lambda: [0.0, 0.0, 0.0])
    angular: List[float] = field(default_factory=lambda: [0.0, 0.0, 0.0])


@dataclass
class XsensQuaternion:
    """四元数数据结构"""
    x: float = 0.0
    y: float = 0.0
    z: float = 0.0
    w: float = 0.0


@dataclass
class XsensLinkState:
    """链接状态数据结构"""
    position: List[float] = field(default_factory=lambda: [0.0, 0.0, 0.0])
    orientation: XsensQuaternion = field(default_factory=XsensQuaternion)
    velocity: XsensTwist = field(default_factory=XsensTwist)
    acceleration: XsensTwist = field(default_factory=XsensTwist)


@dataclass
class XsensJointData:
    """关节数据结构"""
    name: str = ""
    angles: List[float] = field(default_factory=lambda: [0.0, 0.0, 0.0])


@dataclass
class XsensLinkData:
    """链接数据结构"""
    name: str = ""
    parent_joint: str = ""
    length: List[float] = field(default_factory=lambda: [0.0, 0.0, 0.0])
    link_state: XsensLinkState = field(default_factory=XsensLinkState)


@dataclass
class XsensCenterOfMassData:
    """质心数据结构"""
    com_data: List[float] = field(default_factory=lambda: [0.0, 0.0, 0.0])


@dataclass
class XsensData:
    """完整的XSens数据结构"""
    frame_id: int = 0
    time_stamp: int = 0
    joint_data: List[XsensJointData] = field(default_factory=list)
    link_data: List[XsensLinkData] = field(default_factory=list)
    com_data: XsensCenterOfMassData = field(default_factory=XsensCenterOfMassData)
    join_angle_timestamp: int = 0
    link_pose_timestamp: int = 0
    link_linear_twist_timestamp: int = 0
    link_angular_twist_timestamp: int = 0
    com_timestamp: int = 0
    join_angle_sample_cnt: int = 0
    join_angle_datagram_cnt: int = 0
    link_pose_sample_cnt: int = 0
    link_pose_datagram_cnt: int = 0
    link_linear_twist_sample_cnt: int = 0
    link_linear_twist_datagram_cnt: int = 0
    link_angular_twist_sample_cnt: int = 0
    link_angular_twist_datagram_cnt: int = 0
    com_sample_cnt: int = 0
    com_datagram_cnt: int = 0
