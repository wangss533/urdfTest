#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Dual-arm IK adapter with Pinocchio+CasADi and a corrected human arm-angle (psi) loader.

Key assumptions (as provided by user):
- Human TXT quaternion format: wxyz
- Human segment orientations are expressed in WORLD frame
- World frame: +x forward, +y left, +z up

This script:
- Solves dual-arm IK using CasADi+Pinocchio
- Computes robot psi via proxy joint frames (Route B)
- Loads human psi from a TXT (56 floats per line: left 4 segments + right 4 segments, each xyz+qwxyz)
  and reconstructs elbow/wrist centers using segment orientation + bone lengths
"""

from cgi import print_form
import sys
from pathlib import Path
import argparse
import numpy as np

# Ensure "tv" env packages preferred (optional, keep as in user's code)
# sys.path.insert(0, "/home/desaysv/.conda/envs/tv/lib/python3.8/site-packages")

import casadi as casadi
import pinocchio as pin
from pinocchio import casadi as cpin

# Optional: user local util
try:
    from .utils.weighted_moving_filter import WeightedMovingFilter
    print("WeightedMovingFilter loaded successfully.")
except Exception as e:
    WeightedMovingFilter = None
    print(f"WeightedMovingFilter not found. Error: {e}")
    print("Please install it from https://github.com/desaysv/utils.")


class Arm_IK_Casadi_Adapter_Interpolated_Filtered:
    def __init__(self, urdf_path, urdf_dir,
                 debug=False, verbose=False, log_file=None,
                 psi_enabled=True, psi_weight=0.2,
                 world_up=(0.0, 0.0, 1.0),
                 psi_mode='hold', psi_target=None, use_new_limits=False):
        self.debug = bool(debug)
        self.verbose = bool(verbose)
        self.log_file = log_file

        # --- Psi config (Route B) ---
        self.psi_enabled = bool(psi_enabled)
        self.psi_weight = float(psi_weight)
        self.psi_mode = str(psi_mode)
        self.psi_target = psi_target

        self.world_up = np.array(world_up, dtype=float).reshape(3,)
        wu_norm = float(np.linalg.norm(self.world_up))
        if wu_norm < 1e-9:
            self.world_up = np.array([0.0, 0.0, 1.0], dtype=float)
        else:
            self.world_up /= wu_norm

        self.prev_psi_l = 0.0
        self.prev_psi_r = 0.0

        # --- Real-time interpolation/filtering config ---
        self.interp_enabled = True
        self.interp_factor = 10
        self.filter_enabled = True
        self.filter_type = 'ema'  # 'ema' or 'wma'
        self.alpha = 0.3
        self.adaptive = True
        self.prev_joint = None
        self.interp_buffer = []
        self.ema_filtered = None

        if self.debug:
            import logging
            logging.basicConfig(
                level=logging.DEBUG,
                format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
                filename=log_file if log_file else None,
                filemode='w' if log_file else 'a'
            )
            self.logger = logging.getLogger(__name__)

        np.set_printoptions(precision=5, suppress=True, linewidth=220)

        # -----------------------------
        # Build robot / reduced model
        # -----------------------------
        self.model = pin.buildModelFromUrdf(urdf_path)
        
        # Override joint limits if requested
        if use_new_limits:
            print("[IK] Applying NEW joint limits...")
            # New limits from user (Degrees to Radians)
            # Left Arm (Joint 1-7)
            # J1: -170 ~ 170  -> -168 ~ 168
            # J2: -89 ~ 14    -> -87 ~ 12
            # J3: -148 ~ 148  -> -146 ~ 146
            # J4: -145 ~ 10   -> -143 ~ 8
            # J5: -148 ~ 148  -> -146 ~ 146
            # J6: -58 ~ 58    -> -56 ~ 56
            # J7: -50 ~ 50    -> -48 ~ 48
            
            deg2rad = np.pi / 180.0
            
            # Map to pinocchio model joint names
            # Assuming left arm joints are named: joint_arm_l1 ... joint_arm_l7
            # And right arm joints are symmetric or same logic? User only provided one set "left arm".
            # Usually symmetric robot has mirrored limits (signs flipped or same range depending on axis def).
            # Assuming symmetric range magnitude for Right Arm for now, but usually we need specific Right Arm limits.
            # If user only said "this is left arm limits", I will apply it to Left Arm.
            # But what about Right Arm? I'll assume symmetry for safety or keep original for Right?
            # Let's apply to Left Arm first.
            
            limits_deg = [
                (-168, 168), # J1
                (-87, 12),   # J2
                (-146, 146), # J3
                (-143, 8),   # J4
                (-146, 146), # J5
                (-56, 56),   # J6
                (-48, 48)    # J7
            ]
            
            for i, (min_deg, max_deg) in enumerate(limits_deg):
                joint_name = f"joint_arm_l{i+1}"
                if self.model.existJointName(joint_name):
                    idx = self.model.getJointId(joint_name)
                    # Pinocchio model stores limits in model.lowerPositionLimit and upperPositionLimit (nq size vector)
                    # But we need to find the q index.
                    # For reduced model it's easier, but here we modify the full model BEFORE reducing.
                    
                    # Note: getJointId returns index in joint vector, but q vector index might differ (e.g. floating base)
                    # For fixed base revolute joints, usually joint_idx matches q_idx offset?
                    # Pinocchio: model.joints[idx].idx_q
                    idx_q = self.model.joints[idx].idx_q
                    if idx_q >= 0:
                        self.model.lowerPositionLimit[idx_q] = min_deg * deg2rad
                        self.model.upperPositionLimit[idx_q] = max_deg * deg2rad
                        # print(f"Set {joint_name} limits: [{min_deg}, {max_deg}] deg")
                        
                # Also apply to Right Arm?
                # Assuming symmetry:
                # J1: -170 ~ 170 (Symmetric)
                # J2: -89 ~ 14 -> Right might be -14 ~ 89? Or same if axis is same?
                # Usually symmetric arms:
                # J2 (Shoulder Roll/Pitch): If Left moves out is -, Right moves out is +?
                # Without specific Right Arm data, I should probably NOT touch Right Arm limits 
                # OR apply mirrored limits if I'm sure about the URDF axis.
                # Let's apply SAME limits magnitude if range is symmetric (-170, 170),
                # but for asymmetric ones (-89, 14), it's risky.
                # However, the user said "This is left arm threshold".
                # I will ONLY apply to Left Arm joints for now to be safe and correct.
                
                # Update: If I only change Left, the Right might behave differently.
                # But let's follow instruction "This is left arm threshold".
            
            # Right Arm (Joint 1-7)
            # J1: -170 ~ 170  -> -168 ~ 168
            # J2: -89 ~ 14    -> -87 ~ 12
            # J3: -148 ~ 148  -> -146 ~ 146
            # J4: -10 ~ 145   -> -8 ~ 143 (Different from Left!)
            # J5: -148 ~ 148  -> -146 ~ 146
            # J6: -58 ~ 58    -> -56 ~ 56
            # J7: -50 ~ 50    -> -48 ~ 48
            
            limits_deg_r = [
                (-168, 168), # J1
                (-87, 12),   # J2
                (-146, 146), # J3
                (-8, 143),   # J4 (Asymmetric to Left)
                (-146, 146), # J5
                (-56, 56),   # J6
                (-48, 48)    # J7
            ]
            
            for i, (min_deg, max_deg) in enumerate(limits_deg_r):
                joint_name = f"joint_arm_r{i+1}"
                if self.model.existJointName(joint_name):
                    idx = self.model.getJointId(joint_name)
                    idx_q = self.model.joints[idx].idx_q
                    if idx_q >= 0:
                        self.model.lowerPositionLimit[idx_q] = min_deg * deg2rad
                        self.model.upperPositionLimit[idx_q] = max_deg * deg2rad
        
        self.robot = pin.RobotWrapper(self.model)

        # Lock non-arm joints (Rock_C05)
        self.mixed_jointsToLockIDs = [
            "joint_waist_pitch",
            "joint_waist_up",
            "joint_wheel_l",
            "joint_wheel_r"
        ]

        joint_ids_to_lock = []
        for joint_name in self.mixed_jointsToLockIDs:
            try:
                joint_ids_to_lock.append(self.robot.model.getJointId(joint_name))
            except Exception:
                print(f"Warning: Joint {joint_name} not found in model")

        reference_config = np.zeros(self.robot.model.nq)
        reduced_model = pin.buildReducedModel(self.robot.model, joint_ids_to_lock, reference_config)
        self.reduced_robot = pin.RobotWrapper(reduced_model)

        # -----------------------------
        # Add frames (EE + psi proxies)
        # -----------------------------
        try:
            # Right EE at joint_arm_r7
            joint_arm_r7_id = self.reduced_robot.model.getJointId('joint_arm_r7')
            gripper_pos_r = np.array([0, -0.128, -0.037], dtype=float)
            gripper_rpy_r = np.array([-1.5708, -1.5708, 0], dtype=float)
            gripper_rot_r = pin.rpy.rpyToMatrix(*gripper_rpy_r.tolist())
            self.reduced_robot.model.addFrame(
                pin.Frame('R_ee', joint_arm_r7_id, pin.SE3(gripper_rot_r, gripper_pos_r), pin.FrameType.OP_FRAME)
            )

            # Psi proxy frames
            I3 = pin.SE3.Identity()
            jid_l1 = self.reduced_robot.model.getJointId('joint_arm_l1')
            jid_l4 = self.reduced_robot.model.getJointId('joint_arm_l4')
            jid_l7 = self.reduced_robot.model.getJointId('joint_arm_l7')
            jid_r1 = self.reduced_robot.model.getJointId('joint_arm_r1')
            jid_r4 = self.reduced_robot.model.getJointId('joint_arm_r4')
            jid_r7 = self.reduced_robot.model.getJointId('joint_arm_r7')

            self.reduced_robot.model.addFrame(pin.Frame('L_shoulder', jid_l1, I3, pin.FrameType.OP_FRAME))
            self.reduced_robot.model.addFrame(pin.Frame('L_elbow',    jid_l4, I3, pin.FrameType.OP_FRAME))
            self.reduced_robot.model.addFrame(pin.Frame('L_wrist',    jid_l7, I3, pin.FrameType.OP_FRAME))
            self.reduced_robot.model.addFrame(pin.Frame('R_shoulder', jid_r1, I3, pin.FrameType.OP_FRAME))
            self.reduced_robot.model.addFrame(pin.Frame('R_elbow',    jid_r4, I3, pin.FrameType.OP_FRAME))
            self.reduced_robot.model.addFrame(pin.Frame('R_wrist',    jid_r7, I3, pin.FrameType.OP_FRAME))

            # Left EE at joint_arm_l7
            joint_arm_l7_id = self.reduced_robot.model.getJointId('joint_arm_l7')
            gripper_pos_l = np.array([0, 0.128, -0.037], dtype=float)
            gripper_rpy_l = np.array([1.5708, -1.5708, 0], dtype=float)
            gripper_rot_l = pin.rpy.rpyToMatrix(*gripper_rpy_l.tolist())
            self.reduced_robot.model.addFrame(
                pin.Frame('L_ee', joint_arm_l7_id, pin.SE3(gripper_rot_l, gripper_pos_l), pin.FrameType.OP_FRAME)
            )

            self.reduced_robot.data = self.reduced_robot.model.createData()

        except Exception as e:
            print(f"Error: Could not add frames. Check joint names. {e}")
            raise

        # Frame IDs
        self.L_hand_id = self.reduced_robot.model.getFrameId("L_ee")
        self.R_hand_id = self.reduced_robot.model.getFrameId("R_ee")
        self.L_sh_id = self.reduced_robot.model.getFrameId("L_shoulder")
        self.L_el_id = self.reduced_robot.model.getFrameId("L_elbow")
        self.L_wr_id = self.reduced_robot.model.getFrameId("L_wrist")
        self.R_sh_id = self.reduced_robot.model.getFrameId("R_shoulder")
        self.R_el_id = self.reduced_robot.model.getFrameId("R_elbow")
        self.R_wr_id = self.reduced_robot.model.getFrameId("R_wrist")

        # Initial joints (14 DoF: 7L + 7R)
        self.init_data = np.zeros(self.reduced_robot.model.nq)
        self.init_data[:7] = np.array([-0.4531, -1.4079, 0.3750, -0.4259, -0.1644, -0.3088, -0.1463], dtype=float)
        self.init_data[7:] = np.array([ 0.4531, -1.4079, 0.3750,  0.4259,  0.1644, -0.3088,  0.1463], dtype=float)

        # Init psi state from initial configuration
        try:
            self.prev_psi_l, self.prev_psi_r = self._compute_psi_np(self.init_data)
        except Exception:
            self.prev_psi_l, self.prev_psi_r = 0.0, 0.0

        # -----------------------------
        # CasADi model
        # -----------------------------
        self.cmodel = cpin.Model(self.reduced_robot.model)
        self.cdata = self.cmodel.createData()

        self.cq = casadi.SX.sym("q", self.reduced_robot.model.nq, 1)
        self.cTf_l = casadi.SX.sym("tf_l", 4, 4)
        self.cTf_r = casadi.SX.sym("tf_r", 4, 4)
        cpin.framesForwardKinematics(self.cmodel, self.cdata, self.cq)

        # ---- symbolic psi ----
        def _safe_norm_sx(v, eps=1e-6):
            return casadi.sqrt(casadi.dot(v, v) + eps)

        def _unit_sx(v):
            return v / _safe_norm_sx(v)

        def _psi_from_points_sx(Ps, Pe, Pw):
            # print(f"Ps: {Ps}, Pe: {Pe}, Pw: {Pw}")
            wu = casadi.SX(self.world_up.tolist())
            a = _unit_sx(Pw - Ps)
            n_arm = _unit_sx(casadi.cross(Pe - Ps, Pw - Ps))
            
            # Handle degeneracy when Pw-Ps nearly parallel to world_up
            n_ref_raw = casadi.cross(wu, Pw - Ps)
            n_ref_norm = _safe_norm_sx(n_ref_raw)
            
            # Use conditional to handle degeneracy
            ex = casadi.SX([1.0, 0.0, 0.0])
            ey = casadi.SX([0.0, 1.0, 0.0])
            
            # Choose reference axis based on dot product with arm axis
            dot_ex_a = casadi.dot(ex, a)
            use_ex = casadi.fabs(dot_ex_a) < 0.95
            ref_dir = casadi.if_else(use_ex, ex, ey)
            
            # Fallback reference when n_ref is too small (increased threshold)
            n_ref_fallback = _unit_sx(casadi.cross(ref_dir, Pw - Ps))
            n_ref = casadi.if_else(n_ref_norm < 1e-4, n_ref_fallback, _unit_sx(n_ref_raw))
            
            s = casadi.dot(casadi.cross(n_ref, n_arm), a)
            c = casadi.dot(n_ref, n_arm)
            return casadi.atan2(s, c)

        Ps_l = self.cdata.oMf[self.L_sh_id].translation
        Pe_l = self.cdata.oMf[self.L_el_id].translation
        Pw_l = self.cdata.oMf[self.L_wr_id].translation
        Ps_r = self.cdata.oMf[self.R_sh_id].translation
        Pe_r = self.cdata.oMf[self.R_el_id].translation
        Pw_r = self.cdata.oMf[self.R_wr_id].translation

        self.psi_l_sx = _psi_from_points_sx(Ps_l, Pe_l, Pw_l)
        self.psi_r_sx = _psi_from_points_sx(Ps_r, Pe_r, Pw_r)

        self.psi_fun = casadi.Function('psi_fun', [self.cq], [self.psi_l_sx, self.psi_r_sx])
        self.psi_grad_fun = casadi.Function(
            'psi_grad_fun',
            [self.cq],
            [casadi.jacobian(self.psi_l_sx, self.cq), casadi.jacobian(self.psi_r_sx, self.cq)]
        )

        # Task-space error (dual ee)
        # Use log6 for orientation error? Or simple position + quaternion diff?
        # log6 is geometrically correct but can have singularities at 180 deg rotation.
        # Try simple position error + quaternion dot product for robustness if needed.
        # But here we stick to log6 as it's standard in Pinocchio.
        # However, to avoid NaN in log6 gradient at identity or singularity, we can add regularization or safe log.
        # Pinocchio's log6 should be safe?
        # The error "NaN detected for output grad_f_x" usually comes from cost function gradient.
        # The cost is sumsqr(error). error is log6 vector.
        # If log6 has singularity, gradient is NaN.
        # Log6 singularity is at angle = pi.
        # Maybe use simple rotation matrix difference norm for cost? Or Quat difference.
        # Let's keep log6 but be aware.
        
        # New robust error function: Position error + Quaternion error (instead of log6)
        # log6(T) can have NaN gradient near 180 deg rotation or 0 rotation (if implemented poorly).
        # Let's use simple geometric error to avoid NaN.
        
        # Position error
        pos_err_l = self.cdata.oMf[self.L_hand_id].translation - self.cTf_l[:3, 3]
        pos_err_r = self.cdata.oMf[self.R_hand_id].translation - self.cTf_r[:3, 3]
        
        # Orientation error (Quaternion dot product)
        # q_curr = pin.Quaternion(R_curr)
        # q_targ = pin.Quaternion(R_targ)
        # error = 1 - |q_curr . q_targ| (or similar)
        # CasADi rotation to quaternion is tricky.
        # Alternatively, use Rotation Matrix distance: ||R_curr - R_targ||_F
        
        rot_err_l = self.cdata.oMf[self.L_hand_id].rotation - self.cTf_l[:3, :3]
        rot_err_r = self.cdata.oMf[self.R_hand_id].rotation - self.cTf_r[:3, :3]
        
        # Reshape to vector
        self.error = casadi.Function(
            "error",
            [self.cq, self.cTf_l, self.cTf_r],
            [casadi.vertcat(
                pos_err_l,
                casadi.reshape(rot_err_l, 9, 1),
                pos_err_r,
                casadi.reshape(rot_err_r, 9, 1)
            )],
        )
        self.Jerr_fun = casadi.Function(
            'Jerr_fun',
            [self.cq, self.cTf_l, self.cTf_r],
            [casadi.jacobian(self.error(self.cq, self.cTf_l, self.cTf_r), self.cq)]
        )

        # NLP (IK)
        self.opti = casadi.Opti()
        self.var_q = self.opti.variable(self.reduced_robot.model.nq)
        self.param_tf_l = self.opti.parameter(4, 4)
        self.param_tf_r = self.opti.parameter(4, 4)

        totalcost = casadi.sumsqr(self.error(self.var_q, self.param_tf_l, self.param_tf_r))
        regularization = casadi.sumsqr(self.var_q)

        self.opti.subject_to(self.opti.bounded(
            self.reduced_robot.model.lowerPositionLimit,
            self.var_q,
            self.reduced_robot.model.upperPositionLimit
        ))
        self.opti.minimize(20 * totalcost + 0.01 * regularization)

        opts = {
            'ipopt': {
                'print_level': 0, 
                'max_iter': 50, 
                'tol': 1e-4,
                'acceptable_tol': 1e-2, # Relax tolerance for acceptable solution
                'acceptable_iter': 5,
                # 'mu_strategy': 'adaptive' # Can be more robust
            },
            'print_time': False
        }
        self.opti.solver("ipopt", opts)

    # -----------------------------
    # Numeric psi (robot)
    # -----------------------------
    @staticmethod
    def _unit_np(v, eps=1e-9):
        n = float(np.linalg.norm(v))
        return v / (n + eps)

    @staticmethod
    def _angle_wrap_pi(a):
        """wrap to [-pi, pi]"""
        a = float(a)
        while a > np.pi:
            a -= 2*np.pi
        while a < -np.pi:
            a += 2*np.pi
        return a

    @staticmethod
    def _angle_diff(a, b):
        """minimal (a-b) in [-pi, pi]"""
        return Arm_IK_Casadi_Adapter_Interpolated_Filtered._angle_wrap_pi(float(a) - float(b))

    @staticmethod
    def _unwrap_angle_sequence(angle_list):
        """
        Unwrap angles so they are continuous over time.
        Input: list[float] in [-pi, pi] (or any)
        Output: list[float] continuous
        """
        if angle_list is None or len(angle_list) == 0:
            return []

        out = [float(angle_list[0])]
        for k in range(1, len(angle_list)):
            a = float(angle_list[k])
            prev = out[-1]
            # choose a+2pi*m closest to prev
            diff = a - prev
            while diff > np.pi:
                a -= 2.0 * np.pi
                diff = a - prev
            while diff < -np.pi:
                a += 2.0 * np.pi
                diff = a - prev
            out.append(a)
        return out

    @staticmethod
    def _ema_filter_sequence(x_list, alpha=0.2):
        """
        Simple EMA low-pass on a scalar sequence.
        alpha: 0~1, smaller -> stronger smoothing
        """
        if x_list is None or len(x_list) == 0:
            return []
        alpha = float(np.clip(alpha, 0.0, 1.0))
        y = float(x_list[0])
        out = [y]
        for k in range(1, len(x_list)):
            x = float(x_list[k])
            y = alpha * x + (1.0 - alpha) * y
            out.append(y)
        return out

    @staticmethod
    def _adjust_psi_reference(psi_current, psi_target):
        """adjust psi_target by 2pi*k to be closest to psi_current"""
        psi_current = float(psi_current)
        psi_target = float(psi_target)
        diff = psi_target - psi_current
        while diff > np.pi:
            diff -= 2*np.pi
        while diff < -np.pi:
            diff += 2*np.pi
        return Arm_IK_Casadi_Adapter_Interpolated_Filtered._angle_wrap_pi(psi_current + diff)

    def _psi_from_points_np(self, Ps, Pe, Pw):
        """
        Robust psi computation from 3 points.
        Uses reference plane normal n_ref = cross(world_up, Pw-Ps).
        Handles degeneracy when Pw-Ps nearly parallel to world_up.
        """
        Ps = np.asarray(Ps, dtype=float).reshape(3,)
        Pe = np.asarray(Pe, dtype=float).reshape(3,)
        Pw = np.asarray(Pw, dtype=float).reshape(3,)

        a = self._unit_np(Pw - Ps)
        n_arm = np.cross(Pe - Ps, Pw - Ps)
        n_arm = self._unit_np(n_arm)

        n_ref_raw = np.cross(self.world_up, Pw - Ps)
        if float(np.linalg.norm(n_ref_raw)) < 1e-6:
            # fallback: choose another reference axis not collinear with arm axis
            ex = np.array([1.0, 0.0, 0.0])
            ey = np.array([0.0, 1.0, 0.0])
            ref_dir = ex if abs(float(np.dot(ex, a))) < 0.95 else ey
            n_ref_raw = np.cross(ref_dir, Pw - Ps)
        n_ref = self._unit_np(n_ref_raw)

        s = float(np.dot(np.cross(n_ref, n_arm), a))
        c = float(np.dot(n_ref, n_arm))
        return float(np.arctan2(s, c))

    def _compute_psi_np(self, q):
        pin.framesForwardKinematics(self.reduced_robot.model, self.reduced_robot.data, q)
        pin.updateFramePlacements(self.reduced_robot.model, self.reduced_robot.data)

        Ps_l = self.reduced_robot.data.oMf[self.L_sh_id].translation
        Pe_l = self.reduced_robot.data.oMf[self.L_el_id].translation
        Pw_l = self.reduced_robot.data.oMf[self.L_wr_id].translation

        Ps_r = self.reduced_robot.data.oMf[self.R_sh_id].translation
        Pe_r = self.reduced_robot.data.oMf[self.R_el_id].translation
        Pw_r = self.reduced_robot.data.oMf[self.R_wr_id].translation

        return (self._psi_from_points_np(Ps_l, Pe_l, Pw_l),
                self._psi_from_points_np(Ps_r, Pe_r, Pw_r))

    # -----------------------------
    # Nullspace projector + psi correction
    # -----------------------------
    def _nullspace_projector(self, J, damping=1e-6):
        m, n = J.shape
        JJt = J @ J.T
        A = JJt + float(damping) * np.eye(m)
        X = np.linalg.solve(A, J)   # (m x m)^{-1} (m x n) -> (m x n)
        N = np.eye(n) - J.T @ X
        return N

    def _apply_psi_nullspace_correction(self, q, left_pose, right_pose,
                                        psi_ref_l, psi_ref_r,
                                        steps=3, gain=0.2, damping=1e-4, # 改动1: 默认damping增大一点防抖
                                        verbose=False):
        nq = self.reduced_robot.model.nq
        q = np.asarray(q, dtype=float).reshape(nq,).copy()

        lower = np.asarray(self.reduced_robot.model.lowerPositionLimit, dtype=float).reshape(-1)
        upper = np.asarray(self.reduced_robot.model.upperPositionLimit, dtype=float).reshape(-1)

        psi_ref_l = float(psi_ref_l)
        psi_ref_r = float(psi_ref_r)
        
        # 预估手臂最大长度 (用于检测伸直奇异点)
        # 你的URDF大概是 Upper(0.3) + Fore(0.26) ≈ 0.56m，留一点余量设为 0.55
        MAX_ARM_LENGTH = 0.55

        for _ in range(int(steps)):
            q_col = q.reshape(nq, 1)

            # 1. Update Kinematics
            pin.framesForwardKinematics(self.reduced_robot.model, self.reduced_robot.data, q)
            # pin.updateFramePlacements(self.reduced_robot.model, self.reduced_robot.data) # framesForwardKinematics通常已包含更新

            # 2. Get Positions
            Ps_l = self.reduced_robot.data.oMf[self.L_sh_id].translation
            Pe_l = self.reduced_robot.data.oMf[self.L_el_id].translation
            Pw_l = self.reduced_robot.data.oMf[self.L_wr_id].translation

            Ps_r = self.reduced_robot.data.oMf[self.R_sh_id].translation
            Pe_r = self.reduced_robot.data.oMf[self.R_el_id].translation
            Pw_r = self.reduced_robot.data.oMf[self.R_wr_id].translation

            # 3. 计算当前 Psi
            psi_l = self._psi_from_points_np(Ps_l, Pe_l, Pw_l)
            psi_r = self._psi_from_points_np(Ps_r, Pe_r, Pw_r)

            # 4. 奇异点阻尼 (Singularity Damping) - 关键修复 !!!
            # 计算肩膀到手腕的距离
            dist_l = np.linalg.norm(Pw_l - Ps_l)
            dist_r = np.linalg.norm(Pw_r - Ps_r)

            # 计算伸展比率 (0~1)
            ratio_l = np.clip(dist_l / MAX_ARM_LENGTH, 0.0, 1.0)
            ratio_r = np.clip(dist_r / MAX_ARM_LENGTH, 0.0, 1.0)

            # 定义淡出系数：如果伸展超过 90%，开始减弱修正；超过 98% 完全停止修正
            # 这样可以防止手臂伸直时因为数学计算不稳定导致的剧烈抖动
            def get_singularity_scale(ratio):
                threshold_start = 0.90
                threshold_end = 0.98
                if ratio < threshold_start:
                    return 1.0
                elif ratio > threshold_end:
                    return 0.0
                else:
                    return 1.0 - (ratio - threshold_start) / (threshold_end - threshold_start)

            scale_l = get_singularity_scale(ratio_l)
            scale_r = get_singularity_scale(ratio_r)

            # 5. 计算误差
            psi_ref_l_adj = self._adjust_psi_reference(psi_l, psi_ref_l)
            psi_ref_r_adj = self._adjust_psi_reference(psi_r, psi_ref_r)
            
            diff_l = self._angle_diff(psi_l, psi_ref_l_adj)
            diff_r = self._angle_diff(psi_r, psi_ref_r_adj)

            # 如果两只手都在奇异区域，直接跳过计算，节省时间并防抖
            if scale_l < 0.01 and scale_r < 0.01:
                continue

            # 6. 计算梯度
          
            g_l_dm, g_r_dm = self.psi_grad_fun(q_col)
            g_l = np.array(g_l_dm, dtype=float).reshape(-1)[:nq]
            g_r = np.array(g_r_dm, dtype=float).reshape(-1)[:nq]


            grad = (diff_l * scale_l) * g_l + (diff_r * scale_r) * g_r
            grad_norm = np.linalg.norm(grad)
            if grad_norm < 1e-6:
                continue


            J_dm = self.Jerr_fun(q_col, left_pose, right_pose)
            # The Jacobian Jerr_fun returns Jacobian of error() w.r.t q.
            # error() output dimension depends on definition.
            # Previously: log6(L)+log6(R) -> 6+6=12. So J was (12, 14).
            # Now: pos(3)+rot(9)+pos(3)+rot(9) = 24. So J is (24, 14).
            # We need to update the reshape size!
            
            # Dimension check:
            # error vector size = 3 + 9 + 3 + 9 = 24
            # nq = 14
            # Jacobian size = (24, 14) -> 336 elements.
            
            J = np.array(J_dm, dtype=float).reshape(24, nq)
            
            # Note: Nullspace projector formula N = I - J+ J requires J to be full rank or use pseudo-inverse.
            # Our custom _nullspace_projector implementation uses damped least squares inverse:
            # X = (JJt + damp*I)^-1 @ J
            # N = I - J.T @ X
            # This works for any J dimension (m x n), provided m >= n usually?
            # Wait, if m > n (24 constraints, 14 dof), the system is over-constrained.
            # The nullspace of a full-rank over-constrained Jacobian is empty (only 0 vector).
            # This means we cannot move in nullspace without violating the primary task!
            # If we want to use nullspace optimization (Arm Angle), the primary task MUST leave some redundancy.
            #
            # The primary task should only constrain 6 DoF (Position+Orientation) per arm?
            # Or maybe just Position (3) + Aim Axis (2) = 5?
            #
            # If we constrain full Rotation Matrix (9 numbers), it is redundant constraints (only 3 dof).
            # But mathematically J will have rank at most 6 per arm.
            #
            # If we use 24-dim error, the Jacobian has 24 rows.
            # Rank is at most 12 (6 per arm).
            # The damped inverse (JJt + dI)^-1 will work numerically even if rank < 24.
            # However, physically, is there any nullspace left?
            # Yes, if we only care about 6D pose, we have 7 joints. 7-6 = 1 DoF redundancy.
            # The Jacobian (24x7) will have rank 6.
            # The nullspace projector should correctly project onto that 1D subspace.
            #
            # So updating reshape to (24, nq) is correct for the code to run.
            
            N = self._nullspace_projector(J, damping=damping)


            p = N @ grad
            p_norm = np.linalg.norm(p)
            if p_norm < 1e-8:
                continue
            p = p / p_norm


            # 8) 信赖域/限幅 step（而不是 gain）
            step0 = float(gain) # 你传入的 gain 当成“每步最大rad”，比如 0.05
            dq = -step0 * p


            # 范数限幅（双保险）
            dq_max = step0
            dq_norm = np.linalg.norm(dq)
            if dq_norm > dq_max:
                dq = dq * (dq_max / dq_norm)


            q_prev = q.copy()
            # q = np.clip(q + dq, lower, upper)

            # 8. 限幅 (Clamping)
            # dq_limit = 0.1  # 稍微减小一点限幅，原值0.02可能略大
            # dq = np.clip(dq, -dq_limit, dq_limit)
            # print(f"Before Step {_}: q={q}")
            q = np.clip(q + dq, lower, upper)
            # print(f"After Step {_}: q={q}")
            if verbose:
                print(f"Step {_}: psi_l={psi_l:.3f}, psi_ref_l={psi_ref_l_adj:.3f}, diff_l={diff_l:.3f}, "
                      f"psi_r={psi_r:.3f}, psi_ref_r={psi_ref_r_adj:.3f}, diff_r={diff_r:.3f}, "
                      f"scale_l={scale_l:.3f}, scale_r={scale_r:.3f}, "
                      f"grad_norm={np.linalg.norm(grad):.3f}, "
                      f"dq_norm={np.linalg.norm(dq):.3f}, "
                      f"q_diff_norm={np.linalg.norm(q - q_col):.3f}")
        return q

    # -----------------------------
    # IK solve
    # -----------------------------
    def ik_fun(self, left_pose, right_pose, motorstate=None, motorV=None, psi_ref_l=None, psi_ref_r=None):
        if motorstate is not None:
            self.init_data = np.asarray(motorstate, dtype=float).copy()

        self.opti.set_initial(self.var_q, self.init_data)
        self.opti.set_value(self.param_tf_l, left_pose)
        self.opti.set_value(self.param_tf_r, right_pose)

        # Determine psi reference
        if psi_ref_l is not None and psi_ref_r is not None:
            psi_ref_l_base, psi_ref_r_base = float(psi_ref_l), float(psi_ref_r)
        elif self.psi_mode == 'zero':
            psi_ref_l_base, psi_ref_r_base = 0.0, 0.0
        elif self.psi_mode == 'target' and (self.psi_target is not None):
            psi_ref_l_base, psi_ref_r_base = float(self.psi_target), float(self.psi_target)
        else:
            psi_ref_l_base, psi_ref_r_base = float(self.prev_psi_l), float(self.prev_psi_r)

        try:
            sol = self.opti.solve_limited()
            sol_q = np.asarray(self.opti.value(self.var_q), dtype=float).reshape(-1)

            # post-solve psi correction
            if self.psi_enabled:
                sol_q = self._apply_psi_nullspace_correction(
                    sol_q, left_pose, right_pose,
                    psi_ref_l_base, psi_ref_r_base,
                    steps=2, gain=float(self.psi_weight), damping=1e-6,
                    verbose=self.verbose
                )

            # update psi memory
            if self.psi_enabled:
                try:
                    self.prev_psi_l, self.prev_psi_r = self._compute_psi_np(sol_q)
                except Exception:
                    pass

            # velocity (not used here)
            if motorV is not None:
                v = np.asarray(motorV, dtype=float) * 0.0
            else:
                v = (sol_q - self.init_data) * 0.0

            self.init_data = sol_q

            # tau_ff calculation removed for performance
            # tau_ff = pin.rnea(self.reduced_robot.model, self.reduced_robot.data,
            #                   sol_q, v, np.zeros(self.reduced_robot.model.nv))
            return sol_q, None

        except Exception as e:
            print(f"ERROR in IK convergence: {e}")
            return self.init_data, None

    # -----------------------------
    # Pose loaders (robot EE target)
    # -----------------------------
    def load_poses_from_txt(self, poses_file):
        """
        Each line: left [x y z qw qx qy qz] + right [x y z qw qx qy qz] = 14 floats
        (Quaternion is wxyz)
        """
        poses = []
        with open(poses_file, 'r') as f:
            for i, line in enumerate(f):
                line = line.strip()
                if not line:
                    continue
                vals = list(map(float, line.replace(',', ' ').split()))
                if len(vals) != 14:
                    print(f"Warning: Invalid pose data at line {i+1}, expected 14 floats, got {len(vals)}")
                    continue

                left = vals[:7]
                right = vals[7:]

                left_pos = np.array(left[:3], dtype=float)
                qx, qy, qz,qw = left[3:]
                left_rot = pin.Quaternion(qw, qx, qy, qz).toRotationMatrix()
                Tl = np.eye(4)
                Tl[:3, :3] = left_rot
                Tl[:3, 3] = left_pos

                right_pos = np.array(right[:3], dtype=float)
                qx, qy, qz,qw = right[3:]
                right_rot = pin.Quaternion(qw, qx, qy, qz).toRotationMatrix()
                Tr = np.eye(4)
                Tr[:3, :3] = right_rot
                Tr[:3, 3] = right_pos

                poses.append((Tl, Tr))

        return poses

    # -----------------------------
    # Corrected human psi loader (MAIN FIX)
    # -----------------------------
    @staticmethod
    def _quat_wxyz_to_R(quat_wxyz):
        qw, qx, qy, qz = map(float, quat_wxyz)
        return pin.Quaternion(qw, qx, qy, qz).toRotationMatrix()

    @staticmethod
    def _parse_block_pose_wxyz(block, idx):
        base = idx * 7
        p = np.array(block[base:base+3], dtype=float)
        q = block[base+3:base+7]  # qw,qx,qy,qz
        R = Arm_IK_Casadi_Adapter_Interpolated_Filtered._quat_wxyz_to_R(q)
        return p, R

    def load_human_psi_from_txt(self,
                               poses_file,
                               upper_arm_length=0.30,
                               forearm_length=0.26,
                               bone_axis_local=(0.0, 0.0, 1.0),
                               use_wrist_position_correction=True,
                               wrist_correction_alpha=0.35,
                               verbose=False):
        """
        Each line: 56 floats = (left 4 segments + right 4 segments) * 7
          seg order per arm:
            0 shoulder: xyz + qw qx qy qz
            1 upperarm: xyz + qw qx qy qz
            2 forearm : xyz + qw qx qy qz
            3 wrist   : xyz + qw qx qy qz
        Assumptions: quaternion is WORLD orientation of each segment frame.

        Joint reconstruction:
          Pe = Ps + R_upperarm * (bone_axis_local * L_upper)
          Pw_pred = Pe + R_forearm * (bone_axis_local * L_fore)
          Pw = (1-a)*Pw_pred + a*Pw_meas   (optional correction)
        """
        bone_axis_local = np.array(bone_axis_local, dtype=float).reshape(3,)
        L1 = float(upper_arm_length)
        L2 = float(forearm_length)
        a = float(np.clip(wrist_correction_alpha, 0.0, 1.0))

        psi_list = []
        with open(poses_file, 'r') as f:
            for lineno, line in enumerate(f, start=1):
                s = line.strip()
                if not s:
                    continue
                try:
                    data = list(map(float, s.replace(',', ' ').split()))
                except ValueError:
                    if verbose:
                        print(f"[human_psi] line {lineno}: parse fail")
                    continue

                if len(data) != 56:
                    if verbose:
                        print(f"[human_psi] line {lineno}: expected 56 floats, got {len(data)}")
                    continue

                left = data[:28]
                right = data[28:]

                try:
                    Ps_l, _Rsh_l = self._parse_block_pose_wxyz(left, 0)
                    _Pua_l, Rua_l = self._parse_block_pose_wxyz(left, 1)
                    _Pfa_l, Rfa_l = self._parse_block_pose_wxyz(left, 2)
                    Pw_l_meas, _Rw_l = self._parse_block_pose_wxyz(left, 3)

                    Ps_r, _Rsh_r = self._parse_block_pose_wxyz(right, 0)
                    _Pua_r, Rua_r = self._parse_block_pose_wxyz(right, 1)
                    _Pfa_r, Rfa_r = self._parse_block_pose_wxyz(right, 2)
                    Pw_r_meas, _Rw_r = self._parse_block_pose_wxyz(right, 3)

                    # Pe_l = Ps_l + (Rua_l @ (bone_axis_local * L1))
                    # Pe_r = Ps_r + (Rua_r @ (bone_axis_local * L1))
                    pe_l = _Pfa_l
                    pe_r = _Pfa_r

                    # Pw_l_pred = Pe_l + (Rfa_l @ (bone_axis_local * L2))
                    # Pw_r_pred = Pe_r + (Rfa_r @ (bone_axis_local * L2))

                    # if use_wrist_position_correction:
                    #     Pw_l = (1.0 - a) * Pw_l_pred + a * Pw_l_meas
                    #     Pw_r = (1.0 - a) * Pw_r_pred + a * Pw_r_meas
                    # else:
                    #     Pw_l, Pw_r = Pw_l_pred, Pw_r_pred
                    pw_r = Pw_r_meas
                    pw_l = Pw_l_meas

                    psi_l = self._psi_from_points_np(Ps_l, pe_l, pw_l)
                    psi_r = self._psi_from_points_np(Ps_r, pe_r, pw_r)
                    psi_list.append((psi_l, psi_r))

                    if verbose and lineno <= 3:
                        print(f"[human_psi] line {lineno}: "
                              f"psi_l={psi_l:+.3f}, psi_r={psi_r:+.3f}")

                except Exception as e:
                    if verbose:
                        print(f"[human_psi] line {lineno}: compute fail: {e}")
                    continue
        # ---- Step2: make psi continuous + low-pass (strongly recommended) ----
        if len(psi_list) > 1:
            psi_l_raw = [p[0] for p in psi_list]
            psi_r_raw = [p[1] for p in psi_list]

            # unwrap to continuous
            psi_l_unwrap = self._unwrap_angle_sequence(psi_l_raw)
            psi_r_unwrap = self._unwrap_angle_sequence(psi_r_raw)

            # EMA low-pass (tune alpha: 0.05~0.3)
            # alpha smaller -> smoother but more lag
            alpha_psi = 0.15
            psi_l_f = self._ema_filter_sequence(psi_l_unwrap, alpha=alpha_psi)
            psi_r_f = self._ema_filter_sequence(psi_r_unwrap, alpha=alpha_psi)

            psi_list = list(zip(psi_l_f, psi_r_f))

        return psi_list


    # -----------------------------
    # Realtime filtering/interp (optional)
    # -----------------------------
    def apply_realtime_filter(self, joint_angles):
        if not self.filter_enabled:
            return joint_angles

        joint_angles = np.asarray(joint_angles, dtype=float)

        if self.filter_type == 'ema':
            if self.ema_filtered is None:
                self.ema_filtered = joint_angles.copy()
                return joint_angles

            if self.adaptive:
                velocity = joint_angles - self.ema_filtered
                vmag = float(np.linalg.norm(velocity))
                max_velocity = 1.0
                vnorm = min(vmag / max_velocity, 1.0)
                adaptive_alpha = self.alpha + 0.3 * vnorm
                adaptive_alpha = float(np.clip(adaptive_alpha, 0.1, 0.9))
            else:
                adaptive_alpha = float(self.alpha)

            self.ema_filtered = adaptive_alpha * joint_angles + (1 - adaptive_alpha) * self.ema_filtered
            return self.ema_filtered

        if self.filter_type == 'wma' and WeightedMovingFilter is not None:
            if not hasattr(self, 'wma_filter'):
                self.wma_filter = WeightedMovingFilter([0.4, 0.3, 0.2, 0.1], data_size=14)
            self.wma_filter.add_data(joint_angles)
            return self.wma_filter.filtered_data

        return joint_angles

    def process_ik_solution_realtime(self, sol_q):
        processed = []
        sol_q = np.asarray(sol_q, dtype=float)

        if not self.interp_enabled:
            processed.append(self.apply_realtime_filter(sol_q))
            return processed, True

        if self.prev_joint is None:
            self.prev_joint = sol_q
            processed.append(self.apply_realtime_filter(sol_q))
            return processed, True

        if len(self.interp_buffer) > 0:
            for j in self.interp_buffer:
                processed.append(self.apply_realtime_filter(j))
            self.interp_buffer = []
            return processed, False

        step = (sol_q - self.prev_joint) / float(self.interp_factor)
        for k in range(1, int(self.interp_factor) + 1):
            if k < self.interp_factor:
                self.interp_buffer.append(self.prev_joint + step * k)
            else:
                self.prev_joint = sol_q
                processed.append(self.apply_realtime_filter(sol_q))

        if len(self.interp_buffer) > 0:
            for j in self.interp_buffer:
                processed.append(self.apply_realtime_filter(j))
            self.interp_buffer = []

        return processed, True

    def reset_realtime_state(self):
        self.prev_joint = None
        self.interp_buffer = []
        self.ema_filtered = None
        if hasattr(self, 'wma_filter'):
            del self.wma_filter

    def set_realtime_config(self, interp_enabled=True, interp_factor=10,
                            filter_enabled=True, filter_type='ema',
                            alpha=0.3, adaptive=True):
        self.interp_enabled = bool(interp_enabled)
        self.interp_factor = int(interp_factor)
        self.filter_enabled = bool(filter_enabled)
        self.filter_type = str(filter_type)
        self.alpha = float(alpha)
        self.adaptive = bool(adaptive)

    # -----------------------------
    # Batch processing helpers
    # -----------------------------
    def process_poses_realtime(self, poses_file, human_psi=None):
        self.reset_realtime_state()
        poses = self.load_poses_from_txt(poses_file)
        out = []

        if human_psi is not None and len(human_psi) != len(poses):
            print(f"Warning: human psi length {len(human_psi)} != poses {len(poses)} (will use min length).")

        for i, (Tl, Tr) in enumerate(poses):
            psi_ref_l = psi_ref_r = None
            if human_psi is not None and i < len(human_psi):
                psi_ref_l, psi_ref_r = human_psi[i]

            sol_q, _ = self.ik_fun(Tl, Tr, psi_ref_l=psi_ref_l, psi_ref_r=psi_ref_r)
            processed, _ = self.process_ik_solution_realtime(sol_q)
            out.extend(processed)

        return out
