#!/usr/bin/env python3
"""
XSens IK Solver Integration
Integrates XSens UDP Receiver, Arm Mapping, and Null-space IK Solver.
"""

import sys
import os
import time
import argparse
import numpy as np
import pinocchio as pin
from datetime import datetime
import csv
from pathlib import Path
import threading
import queue
import socket
import json

# Add current directory to path
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from modules.xsens_udp_receiver_fixed import XSensUDPReceiverFixed
from modules.arm_mapper import ArmMapper
from modules.xsens_data_types import XsensData, XsensQuaternion
from modules.ik_solver_null import Arm_IK_Casadi_Adapter_Interpolated_Filtered
from modules.udp_sender import UDPSender

class XSensIKSolverProcessor:
    def __init__(self, args):
        self.args = args
        self.save_csv = not args.no_save_csv
        self.csv_file = None
        self.csv_writer = None
        if self.save_csv:
            self.output_file = Path(args.output)
            self.output_file.parent.mkdir(parents=True, exist_ok=True)
            self.csv_file = open(self.output_file, 'w', newline='')
            self.csv_writer = csv.writer(self.csv_file)
            header = [f"joint_{i+1}" for i in range(14)]
            self.csv_writer.writerow(header)
        
        # Initialize UDP Sender
        self.udp_sender = UDPSender(ip=args.target_ip, port=args.target_port)
        
        # Initialize ArmMapper
        self.mapper = ArmMapper()
        
        # Initialize IK Solver
        # Handle URDF path
        urdf_path = args.urdf
        if not os.path.exists(urdf_path):
            # Try finding it in ../urdf
            alt_path = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "urdf", "Rock_C05.urdf")
            if os.path.exists(alt_path):
                print(f"URDF not found at {urdf_path}, using {alt_path}")
                urdf_path = alt_path
            else:
                print(f"Warning: URDF not found at {urdf_path}")

        self.ik_solver = Arm_IK_Casadi_Adapter_Interpolated_Filtered(
            urdf_path=urdf_path,
            urdf_dir=os.path.dirname(urdf_path),
            debug=args.debug,
            verbose=args.verbose,
            log_file=args.log_file,
            psi_enabled=(not args.psi_disabled),
            psi_weight=args.psi_weight,
            world_up=tuple(map(float, args.world_up.split(','))),
            psi_mode=args.psi_mode,
            psi_target=args.psi_target,
            use_new_limits=args.use_new_limits
        )
        
        # Realtime config
        self.ik_solver.set_realtime_config(
            interp_enabled=bool(args.interpolate),
            interp_factor=int(args.interp_factor),
            filter_enabled=(args.filter_type != 'none'),
            filter_type=args.filter_type,
            alpha=float(args.alpha),
            adaptive=bool(args.adaptive)
        )
        
        self.frame_count = 0
        self.last_stat_time = time.time()
        self.stat_interval = 2.0
        
        # Bone parameters for Psi calculation
        self.upper_arm_length = args.upper_arm_length
        self.forearm_length = args.forearm_length
        self.bone_axis_local = np.array(list(map(float, args.bone_axis.split(','))), dtype=float)
        
        # Threading support
        self.data_queue = queue.Queue(maxsize=100) # Buffer size for incoming data
        self.is_running = False
        self.process_thread = None
        self.dropped_frames = 0 # Counter for dropped frames
        
        # UDP Control State (similar to example_send_fixed_joints.py)
        # We need a state machine to handle the initialization sequence:
        # 1. StartFlag -> 2. SwitchOn -> 3. TryLock -> 4. Loop (Send Data)
        self.control_state = 0 # 0=Init, 1=Running
        self.init_step = 0 # 0=StartFlag, 1=SwitchOn, 2=TryLock
        self.init_timer = 0
        self.last_init_time = 0
        self.last_feedback_time = 0 # Track last valid feedback time
        
        # --- Advanced Control State Machine ---
        # 0: INIT_SEQ (UDP Handshake)
        # 1: MOVING_TO_HOME (Robot moves to predefined home pose)
        # 2: WAITING_FOR_ALIGNMENT (Robot holds home, waits for human to match)
        # 3: TELEOP_RUNNING (Normal IK control)
        self.control_mode = 0 
        
        # Home Pose (Configurable, using T-pose or similar safe pose)
        # Assuming typical 7-DOF arm, 0s might be T-pose or straight out depending on calibration
        self.HOME_POSE_LEFT = [0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0]
        self.HOME_POSE_RIGHT = [0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0]
        
        # Current Robot State (Updated from Feedback)
        self.robot_current_left = None
        self.robot_current_right = None
        
        # Safety parameters
        self.MAX_JOINT_SPEED = 0.002 # rad/frame (approx 0.1 deg/frame @ 50Hz) - For Homing Only
        self.ALIGNMENT_THRESHOLD = 0.3 # rad 
        self.ALIGNMENT_COUNTER = 0
        self.ALIGNMENT_REQUIRED_FRAMES = 50 
        
        # Teleop Thresholds
        import math
        self.JUMP_THRESHOLD = (5.0 / 180.0) * math.pi # 5 degrees in rad
        self.SMOOTH_STEP = self.JUMP_THRESHOLD # Max step allowed if jump detected (clamp to 5 deg)
        # Actually, user said: "if >= 5 deg, smooth it (step <= 5 deg). If < 5 deg, send directly."
        # This implies that a 4 degree jump is considered "safe" to send directly? 
        # But I will follow the instruction exactly: 
        # Threshold = 5 deg. 
        # If diff >= 5 deg: clamp change to 5 deg (or smaller? usually smooth means smaller steps).
        # "步长可以按照不大于5度去平滑" -> This means max step is 5 deg.
        # So essentially, we just clamp the output change to max 5 degrees per frame.
        
        # However, usually "smooth" means taking MULTIPLE frames to reach.
        # If I clamp to 5 deg, and the jump was 50 deg, it will take 10 frames.
        # If the jump was 4 deg, it takes 1 frame.
        # This seems to be the request.
        
    def _update_robot_state_from_feedback(self):
        """Try to get latest feedback from robot to update current state"""
        # Drain the socket buffer to get the LATEST packet
        # Since it's non-blocking, we can loop until None
        latest_fb = None
        while True:
            fb = self.udp_sender.receive_feedback()
            if fb is None:
                break
            latest_fb = fb
            
        if latest_fb:
            try:
                self.robot_current_left = latest_fb.get("data", {}).get("Robot", {}).get("AP", None)
                self.robot_current_right = latest_fb.get("data", {}).get("RightArm", {}).get("AP", None)
                self.last_feedback_time = time.time()
                return True
            except:
                pass
        return False

    def _ensure_initialized(self, dummy_left, dummy_right):
        """
        Handle initialization sequence.
        Returns True if UDP handshake is done.
        """
        if self.control_mode > 0:
            return True
            
        current_time = time.time()
        if current_time - self.last_init_time < 0.1: 
            return False

        if self.init_step == 0:
            print("[IK-INT] [STEP] StartFlag = true")
            self.udp_sender.send_control_command(dummy_left, dummy_right, start_flag=True)
            self.init_step += 1
            self.last_init_time = current_time
            return False
            
        elif self.init_step == 1:
            print("[IK-INT] [STEP] SwitchOn = true")
            self.udp_sender.send_control_command(dummy_left, dummy_right, switch_on=True)
            self.init_step += 1
            self.last_init_time = current_time
            return False
            
        elif self.init_step == 2:
            print("[IK-INT] [STEP] tryLock = true")
            self.udp_sender.send_control_command(dummy_left, dummy_right, try_lock=True)
            self.init_step += 1
            self.last_init_time = current_time
            return False
            
        elif self.init_step == 3:
            print("[IK-INT] [INFO] UDP Handshake Complete. Moving to Home Pose...")
            
            if self.args.enable_homing:
                self.control_mode = 1 # Switch to MOVING_TO_HOME
                print("[IK-INT] Homing enabled: Moving to Home Pose...")
            else:
                self.control_mode = 3 # Skip homing, jump directly to TELEOP
                print("[IK-INT] Homing disabled: Jumping directly to Teleoperation...")
                
            return True
            
        return False

    def _process_control_logic(self, ik_target_left, ik_target_right):
        """
        Main control loop logic implementing the state machine.
        Returns: (final_cmd_left, final_cmd_right) or (None, None) if no command should be sent
        """
        # Always try to update robot state first
        has_feedback = self._update_robot_state_from_feedback()
        
        # If we don't have feedback yet, we can't do closed-loop control safely
        # But for INIT_SEQ we don't need feedback
        if self.control_mode == 0:
            if self._ensure_initialized(ik_target_left, ik_target_right):
                # Just transitioned to mode 1, but for this frame return None
                return None, None
            return None, None # Still initializing
            
        # For all other modes, we MUST have robot feedback to be safe
        # But we allow using cached feedback if it's recent enough (e.g. < 0.5s)
        if self.robot_current_left is None:
             return None, None
             
        if time.time() - self.last_feedback_time > 0.5:
             # Too stale, stop sending commands for safety
             if self.frame_count % 50 == 0:
                 print("[WARN] Robot feedback timeout > 0.5s. Stopping control.")
             return None, None

        # Current actual positions
        curr_l = list(self.robot_current_left)
        curr_r = list(self.robot_current_right)
        
        # Output commands (initially same as current)
        cmd_l = list(curr_l)
        cmd_r = list(curr_r)
        
        # --- STATE MACHINE ---
        
        if self.control_mode == 1: # MOVING_TO_HOME
            # Target is Home Pose
            target_l = self.HOME_POSE_LEFT
            target_r = self.HOME_POSE_RIGHT
            
            # Interpolate towards Home
            reached = True
            for i in range(7):
                # Left
                diff = target_l[i] - curr_l[i]
                if abs(diff) > self.MAX_JOINT_SPEED:
                    cmd_l[i] += self.MAX_JOINT_SPEED if diff > 0 else -self.MAX_JOINT_SPEED
                    reached = False
                else:
                    cmd_l[i] = target_l[i]
                    
                # Right
                diff = target_r[i] - curr_r[i]
                if abs(diff) > self.MAX_JOINT_SPEED:
                    cmd_r[i] += self.MAX_JOINT_SPEED if diff > 0 else -self.MAX_JOINT_SPEED
                    reached = False
                else:
                    cmd_r[i] = target_r[i]
            
            if reached:
                print(f"[IK-INT] Reached Home Pose. Waiting for Human Alignment...")
                self.control_mode = 2
                
        elif self.control_mode == 2: # WAITING_FOR_ALIGNMENT
            # Robot holds Home Pose
            cmd_l = self.HOME_POSE_LEFT
            cmd_r = self.HOME_POSE_RIGHT
            
            # Check difference between Human IK (ik_target) and Robot Home (cmd)
            # Use max joint error or avg error
            max_err = 0.0
            for i in range(7):
                max_err = max(max_err, abs(ik_target_left[i] - cmd_l[i]))
                max_err = max(max_err, abs(ik_target_right[i] - cmd_r[i]))
            
            if max_err < self.ALIGNMENT_THRESHOLD:
                self.ALIGNMENT_COUNTER += 1
                if self.ALIGNMENT_COUNTER % 10 == 0:
                    print(f"\r[ALIGN] Aligning... {self.ALIGNMENT_COUNTER}/{self.ALIGNMENT_REQUIRED_FRAMES}", end="")
                    
                if self.ALIGNMENT_COUNTER >= self.ALIGNMENT_REQUIRED_FRAMES:
                    print("\n[IK-INT] Human Aligned! Starting Teleoperation...")
                    self.control_mode = 3
            else:
                self.ALIGNMENT_COUNTER = 0
                # print(f"\r[ALIGN] Waiting for human... Max Error: {max_err:.2f} > {self.ALIGNMENT_THRESHOLD}", end="")

        elif self.control_mode == 3: # TELEOP_RUNNING
            # Target is Human IK
            target_l = ik_target_left
            target_r = ik_target_right
            
            # Logic:
            # If enable-smooth-start is ON:
            #   If diff < 5 deg, send target directly.
            #   If diff >= 5 deg, limit step to 5 deg (smooth).
            # Else:
            #   Send target directly.
            
            for i in range(7):
                # Left
                if self.args.enable_smooth_start:
                    diff_l = target_l[i] - curr_l[i]
                    if abs(diff_l) >= self.JUMP_THRESHOLD:
                        # Too big jump, clamp it
                        print(f"beyond threshold,[IK-INT] Left diff_l: {diff_l:.2f}")
                        change_l = max(-self.SMOOTH_STEP, min(self.SMOOTH_STEP, diff_l))
                        cmd_l[i] = curr_l[i] + change_l
                    else:
                        # Safe jump, send directly
                        cmd_l[i] = target_l[i]
                else:
                    cmd_l[i] = target_l[i]
                
                # Right
                if self.args.enable_smooth_start:
                    diff_r = target_r[i] - curr_r[i]
                    if abs(diff_r) >= self.JUMP_THRESHOLD:
                        print(f"beyond threshold,[IK-INT] Right diff_r: {diff_r:.2f}")
                        change_r = max(-self.SMOOTH_STEP, min(self.SMOOTH_STEP, diff_r))
                        cmd_r[i] = curr_r[i] + change_r
                    else:
                        cmd_r[i] = target_r[i]
                else:
                    cmd_r[i] = target_r[i]
                
        return cmd_l, cmd_r

    def start(self):
        """Start the processing thread"""
        if self.is_running:
            return
        
        # --- Pre-Start Homing Sequence ---
        # If homing is enabled, we perform it BEFORE starting the IK loop.
        # This ensures robot is at Home Pose before we even look at XSens data.
        if self.args.enable_homing:
            print("\n[IK-INT] === Starting Pre-IK Homing Sequence ===")
            
            # 1. UDP Handshake (StartFlag -> SwitchOn -> TryLock)
            dummy_joints = [0.0] * 7
            print("[IK-INT] Performing UDP Handshake...")
            
            # StartFlag
            print("[IK-INT] [STEP] StartFlag = true")
            self.udp_sender.send_control_command(dummy_joints, dummy_joints, start_flag=True)
            time.sleep(0.1)
            
            # SwitchOn
            print("[IK-INT] [STEP] SwitchOn = true")
            self.udp_sender.send_control_command(dummy_joints, dummy_joints, switch_on=True)
            time.sleep(0.1)
            
            # TryLock
            print("[IK-INT] [STEP] tryLock = true")
            self.udp_sender.send_control_command(dummy_joints, dummy_joints, try_lock=True)
            time.sleep(0.1)
            
            print("[IK-INT] Handshake Complete.")
            
            # 2. Move to Home Pose
            print("[IK-INT] Moving Robot to Home Pose...")
            # We need to loop here to send commands until reached
            # But we need feedback to know current pos.
            # Assuming UDP feedback is working (which runs on sender socket usually?)
            # Wait, UDPSender has receive_feedback()
            
            target_l = self.HOME_POSE_LEFT
            target_r = self.HOME_POSE_RIGHT
            
            # Get initial position
            curr_l = None
            curr_r = None
            
            print("[IK-INT] Waiting for robot feedback...")
            for _ in range(20): # Try for 2 seconds
                fb = self.udp_sender.receive_feedback()
                if fb:
                    try:
                        curr_l = fb.get("data", {}).get("Robot", {}).get("AP", None)
                        curr_r = fb.get("data", {}).get("RightArm", {}).get("AP", None)
                        if curr_l and curr_r:
                            break
                    except:
                        pass
                time.sleep(0.1)
                
            if not curr_l:
                print("[IK-INT] [WARN] No feedback received! Assuming zero start (DANGEROUS).")
                curr_l = [0.0]*7
                curr_r = [0.0]*7
            
            # Homing Loop
            homing_speed = 0.002
            while True:
                reached = True
                # Update current pos from feedback if available (Closed Loop Homing)
                fb = self.udp_sender.receive_feedback()
                if fb:
                     try:
                        curr_l = fb.get("data", {}).get("Robot", {}).get("AP", curr_l)
                        curr_r = fb.get("data", {}).get("RightArm", {}).get("AP", curr_r)
                     except:
                        pass
                
                # Calculate next step
                cmd_l = list(curr_l)
                cmd_r = list(curr_r)
                
                for i in range(7):
                    diff = target_l[i] - curr_l[i]
                    if abs(diff) > homing_speed:
                        cmd_l[i] += homing_speed if diff > 0 else -homing_speed
                        reached = False
                    else:
                        cmd_l[i] = target_l[i]
                        
                    diff = target_r[i] - curr_r[i]
                    if abs(diff) > homing_speed:
                        cmd_r[i] += homing_speed if diff > 0 else -homing_speed
                        reached = False
                    else:
                        cmd_r[i] = target_r[i]
                
                self.udp_sender.send_control_command(cmd_l, cmd_r)
                
                if reached:
                    print("[IK-INT] Robot Reached Home Pose.")
                    break
                
                time.sleep(0.01) # 100Hz loop
                
            # 3. Wait for 5 seconds
            print("[IK-INT] Waiting 5 seconds before accepting XSens data...")
            # We must keep sending Home Pose during this wait to keep robot active/holding
            start_wait = time.time()
            while time.time() - start_wait < 5.0:
                self.udp_sender.send_control_command(target_l, target_r)
                time.sleep(0.02) # 50Hz hold
                
            print("[IK-INT] === Ready for XSens Data. Starting IK Loop ===\n")
            
            # Set state to WAITING_FOR_ALIGNMENT (Mode 2) or TELEOP (Mode 3)?
            # User said "accept UDP data ... smooth approach".
            # So we should go to Mode 2 (Alignment) or Mode 3 (Teleop with smooth).
            # Let's go to Mode 2 to be safe (Alignment Check), or Mode 3 if user trusts the smooth logic.
            # Given "smoothly approach", Mode 3 with JUMP_THRESHOLD logic handles it.
            # But Mode 2 is even safer. Let's set to Mode 2 (Alignment) as it naturally transitions to Mode 3.
            # Or if user wants immediate response after 5s, Mode 3.
            # Let's stick to Mode 2 (Alignment) as implemented before, it will just check alignment.
            # But wait, self._process_control_logic handles initialization.
            # We already did initialization manually above!
            # So we need to set control_mode to skip init.
            
            self.control_mode = 2 # Go to Alignment Check
            # self.control_mode = 3 # Or go directly to Teleop
            
        else:
            # If homing disabled, we still rely on the loop to do handshake
            self.control_mode = 0

        self.is_running = True
        self.process_thread = threading.Thread(target=self._processing_loop, daemon=True)
        self.process_thread.start()
        print("IK Processing thread started")

    def stop(self):
        """Stop the processing thread"""
        self.is_running = False
        if self.process_thread:
            self.process_thread.join(timeout=2.0)
            print("IK Processing thread stopped")
            
        # Send cleanup commands (StartFlag=False, tryLock=False)
        # Using dummy joints since we just need to send the flags
        dummy_joints = [0.0] * 7
        try:
            print("[IK-INT] [STEP] StartFlag = false")
            for _ in range(3):
                self.udp_sender.send_control_command(dummy_joints, dummy_joints, start_flag=False)
                time.sleep(0.05)
                
            print("[IK-INT] [STEP] tryLock = false")
            for _ in range(3):
                self.udp_sender.send_control_command(dummy_joints, dummy_joints, try_lock=False)
                time.sleep(0.05)
            print("[IK-INT] Control released.")
        except Exception as e:
            print(f"Error sending cleanup commands: {e}")
            
        self.close()

    def enqueue_data(self, xsens_data: XsensData):
        """Callback to enqueue data from receiver thread"""
        try:
            # If queue is full, drop the oldest frame (or just drop this one? dropping oldest is better for realtime)
            # But queue.Queue doesn't support popping from full queue easily without blocking.
            # So we use non-blocking put, if full, we might want to warn.
            # For realtime, we prefer newest data.
            if self.data_queue.full():
                try:
                    self.data_queue.get_nowait() # Discard oldest
                    self.dropped_frames += 1
                except queue.Empty:
                    pass
            
            self.data_queue.put(xsens_data, block=False)
        except queue.Full:
            pass # Should not happen with above logic

    def _processing_loop(self):
        """Main loop for IK processing"""
        while self.is_running:
            try:
                # Wait for data with timeout to allow checking is_running
                xsens_data = self.data_queue.get(timeout=0.1)
                self.process_data(xsens_data)
                self.data_queue.task_done()
            except queue.Empty:
                continue
            except Exception as e:
                print(f"Error in processing loop: {e}")

    def close(self):
        if self.csv_file:
            self.csv_file.close()

    def get_link_pose(self, xsens_data: XsensData, link_name: str):
        """Get position and rotation matrix for a link from XSens data"""
        for link in xsens_data.link_data:
            if link.name == link_name:
                pos = np.array(link.link_state.position)
                quat = link.link_state.orientation
                # XsensQuaternion is x,y,z,w
                # Pinocchio expects x,y,z,w for constructor? No, check ik_solver_null
                # ik_solver_null uses pin.Quaternion(qw, qx, qy, qz)
                R = pin.Quaternion(quat.w, quat.x, quat.y, quat.z).toRotationMatrix()
                return pos, R
        return None, None

    def compute_human_psi(self, xsens_data: XsensData):
        """Compute arm angles (Psi) from XSens data"""
        
        def get_psi_for_arm(prefix):
            # prefix is "left" or "right"
            # Link names: shoulder, upper_arm, forearm, hand (wrist)
            try:
                # 1. Get raw poses from XSens (World Frame)
                Ps, _ = self.get_link_pose(xsens_data, f"{prefix}_shoulder")
                _, Rua = self.get_link_pose(xsens_data, f"{prefix}_upper_arm")
                _, Rfa = self.get_link_pose(xsens_data, f"{prefix}_forearm")
                Pw_meas, _ = self.get_link_pose(xsens_data, f"{prefix}_hand")
                
                if Ps is None or Rua is None or Rfa is None or Pw_meas is None:
                    return 0.0

                # 2. Reconstruct kinematic chain (matches ik_solver_null logic)
                # Pe = Ps + Rua * (bone_axis * L1)
                Pe = Ps + Rua @ (self.bone_axis_local * self.upper_arm_length)
                
                # Pw_pred = Pe + Rfa * (bone_axis * L2)
                # Pw = Pw_pred (or use Pw_meas if correction enabled, simplified here to use Pw_meas as target/reference 
                # or strictly follow ik_solver_null which computes psi from these points)
                
                # In ik_solver_null.load_human_psi_from_txt:
                # pe_l = _Pfa_l (Wait, code says pe_l = _Pfa_l which is the position of forearm? 
                # Let's check load_human_psi_from_txt in ik_solver_null.py again)
                # It says:
                # _Pua_l, Rua_l = ... (upper arm)
                # _Pfa_l, Rfa_l = ... (forearm)
                # pe_l = _Pfa_l
                # This suggests _Pfa_l (Forearm position) is used as Elbow position? 
                # In XSens model, "forearm" origin is usually at the elbow?
                # If so, we can just use the sensor position directly!
                
                # Let's check XSens model definitions or assume XSens "forearm" position is the elbow.
                # Usually XSens "Forearm" sensor is on the forearm, not at the joint.
                # BUT, ik_solver_null.py seems to be designed for a specific input format "human poses txt".
                # If I look at the commented out lines in ik_solver_null.py:
                # # Pe_l = Ps_l + (Rua_l @ (bone_axis_local * L1))
                # It seems the author tried calculation but switched to using the position from the file.
                # "pe_l = _Pfa_l" -> Position of Forearm block.
                
                # Let's try using the reconstructed method which is more robust if sensor placement varies,
                # provided we trust the orientations and bone lengths.
                # Ps = Shoulder Joint
                # Pe = Shoulder Joint + UpperArmRot * Length
                # Pw = Elbow Joint + ForearmRot * Length
                
                # Use the reconstruction method as it guarantees valid triangle for Psi calculation
                Pe_calc = Ps + Rua @ (self.bone_axis_local * self.upper_arm_length)
                Pw_calc = Pe_calc + Rfa @ (self.bone_axis_local * self.forearm_length)
                
                # Option: Use Pw_meas (Hand position from sensor) for Wrist
                # The ik_solver_null.py uses Pw_meas for Pw if wrist correction is enabled?
                # "pw_l = Pw_l_meas"
                
                # Let's use:
                # Ps = Shoulder Sensor Pos (Approximation of joint?) 
                # Note: XSens "Shoulder" sensor is usually on the scapula.
                # But ArmMapper uses "left_shoulder" link position as "P_shoulder".
                # Let's stick to the reconstruction for Pe, and use Hand sensor for Pw?
                
                return self.ik_solver._psi_from_points_np(Ps, Pe_calc, Pw_meas)
                
            except Exception as e:
                # print(f"Psi calc error: {e}")
                return 0.0

        psi_l = get_psi_for_arm("left")
        psi_r = get_psi_for_arm("right")
        return psi_l, psi_r

    def process_data(self, xsens_data: XsensData):
        """Callback for XSens data"""
        self.frame_count += 1
        
        # 1. Map Arms to Robot Base Frame (Target Poses)
        left_result, right_result = self.mapper.map_both_arms(xsens_data)
        
        if not left_result.success or not right_result.success:
            if self.args.verbose:
                print(f"Mapping failed: Left={left_result.success}, Right={right_result.success}")
            return

        # Construct Tl, Tr (4x4 Homogeneous Matrices)
        def get_T(result):
            T = np.eye(4)
            T[:3, :3] = result.end_effector_orientation
            T[:3, 3] = result.end_effector_position
            return T
            
        Tl = get_T(left_result)
        Tr = get_T(right_result)
        
        # 2. Compute Human Psi (Arm Angle)
        # Note: We need to smooth this potentially, ik_solver_null does EMA filtering on Psi
        # But here we do it frame by frame. The IK solver's _apply_psi_nullspace_correction 
        # uses the passed psi_ref.
        # We might want to add a filter here if it's too jittery.
        psi_l, psi_r = 0.0, 0.0
        if self.ik_solver.psi_enabled:
            psi_l, psi_r = self.compute_human_psi(xsens_data)
        
        # 3. Solve IK
        # psi_ref_l/r are passed to ik_fun
        sol_q, _ = self.ik_solver.ik_fun(Tl, Tr, psi_ref_l=psi_l, psi_ref_r=psi_r)
        
        if sol_q is None:
             if self.args.verbose:
                 print("IK failed (returned None)")
             return
        
        # 4. Post-process (Interpolation/Filtering)
        # process_ik_solution_realtime returns a list of samples (if interpolation is on)
        processed_samples, _ = self.ik_solver.process_ik_solution_realtime(sol_q)
        
        # 5. Save to CSV
        if not processed_samples:
            # If no samples returned (e.g. init phase), we might still want to log something or skip
            pass
            
        for q in processed_samples:
            q = np.asarray(q, dtype=float).reshape(-1)
            if self.save_csv and self.csv_writer:
                row = [f"{v:.6f}" for v in q.tolist()]
                self.csv_writer.writerow(row)
                # self.csv_file.flush() # Removed for performance
            
            # Send via UDP
            # q is 14 elements: 0-6 (Left?), 7-13 (Right?)
            if len(q) >= 14:
                q_list = q.tolist()
                ik_target_left = q_list[:7]
                ik_target_right = q_list[7:14]
                
                # Use our new control logic
                final_cmd_left, final_cmd_right = self._process_control_logic(ik_target_left, ik_target_right)
                
                if final_cmd_left is not None and final_cmd_right is not None:
                    self.udp_sender.send_control_command(final_cmd_left, final_cmd_right)
            
        # Statistics
        current_time = time.time()
        if current_time - self.last_stat_time >= self.stat_interval:
            fps = self.frame_count / (current_time - self.last_stat_time)
            print(f"FPS: {fps:.1f} | Psi: L={psi_l:.2f} R={psi_r:.2f} | IK samples: {len(processed_samples)} | Dropped: {self.dropped_frames}")
            self.frame_count = 0
            self.dropped_frames = 0
            self.last_stat_time = current_time

def main():
    parser = argparse.ArgumentParser(description='XSens IK Solver Integration')
    parser.add_argument('--urdf', type=str, default="assets/Rock_C05_grip.urdf")
    parser.add_argument('--output', type=str, default="data/output/ik_result.csv")
    parser.add_argument('--no-save-csv', action='store_true', default=True, help='Disable saving CSV file')
    
    # IK Solver Args
    parser.add_argument('--realtime', action='store_true', default=True)
    parser.add_argument('--interpolate', action='store_true', default=False) 
    parser.add_argument('--interp-factor', type=int, default=10)
    parser.add_argument('--filter-type', type=str, default='ema', choices=['ema', 'wma', 'none'])
    parser.add_argument('--alpha', type=float, default=0.3)
    parser.add_argument('--adaptive', action='store_true', default=True)
    
    parser.add_argument('--psi-disabled', action='store_true', default=True, help='Disable psi calculation')
    parser.add_argument('--psi-weight', type=float, default=0.2)
    parser.add_argument('--world-up', type=str, default='0,0,1')
    parser.add_argument('--psi-mode', type=str, default='hold', choices=['hold', 'zero', 'target'])
    parser.add_argument('--psi-target', type=float, default=None)
    parser.add_argument('--use-new-limits', action='store_true', help='Use new joint limits provided by user')
    
    # Human Psi Args
    parser.add_argument('--upper-arm-length', type=float, default=0.30)
    parser.add_argument('--forearm-length', type=float, default=0.26)
    parser.add_argument('--bone-axis', type=str, default='0,0,-1')
    
    # XSens Args
    parser.add_argument('--ip', type=str, default="0.0.0.0")
    parser.add_argument('--port', type=int, default=9763)
    parser.add_argument('--buffer-size', type=int, default=10000)
    
    # UDP Sender Args
    parser.add_argument('--target-ip', type=str, default="192.168.100.16")
    parser.add_argument('--target-port', type=int, default=9001)
    
    # Homing configuration
    parser.add_argument('--enable-homing', action='store_true', help='Enable initial homing sequence')
    parser.add_argument('--enable-smooth-start', action='store_true', help='Enable smooth start transition (clamp jump to 5 deg)')
    
    parser.add_argument('--debug', action='store_true')
    parser.add_argument('--verbose', action='store_true')
    parser.add_argument('--log-file', type=str, default=None)

    args = parser.parse_args()
    
    processor = XSensIKSolverProcessor(args)
    processor.start() # Start processing thread
    
    receiver = XSensUDPReceiverFixed(
        ip=args.ip,
        port=args.port,
        buffer_size=args.buffer_size
    )
    
    if not receiver.initialize():
        print("Failed to initialize receiver")
        return
        
    # Use enqueue_data as callback to push to queue instead of processing directly
    receiver.set_data_callback(processor.enqueue_data)
    
    if not receiver.start_receiving():
        print("Failed to start receiving")
        return
        
    print(f"Started XSens IK Solver Integration")
    print(f"  XSens Receiver Listening on: {args.ip}:{args.port}")
    print(f"  Robot Control Target: {args.target_ip}:{args.target_port}")
    print(f"  Output: {args.output}")
    print("Press Ctrl+C to stop")
    
    try:
        while True:
            time.sleep(1)
    except KeyboardInterrupt:
        print("Stopping...")
        receiver.stop_receiving()
        processor.stop()

if __name__ == "__main__":
    main()
