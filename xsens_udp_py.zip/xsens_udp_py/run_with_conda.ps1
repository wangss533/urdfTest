$ENV_NAME = "xsens_env"

# Clear PYTHONPATH to avoid conflicts
$env:PYTHONPATH = ""

# Check for conda
if (-not (Get-Command conda -ErrorAction SilentlyContinue)) {
    Write-Error "Conda is not found in PATH."
    exit 1
}

Write-Host "Running XSens Integration in Conda environment: $ENV_NAME" -ForegroundColor Green

# 尝试直接运行，不再依赖脆弱的 env list 检查
# 如果环境不存在，conda run 会自动报错，这比手动检查更可靠
Write-Host "Executing script..." -ForegroundColor Cyan

# 使用 conda run 来执行脚本
# --no-capture-output 允许实时看到输出
# --live-stream 是新版 conda 的参数，确保输出不被缓冲
conda run -n $ENV_NAME --no-capture-output python xsens_ik_solver_integration.py $args

if ($LASTEXITCODE -ne 0) {
    Write-Host "`nError: Failed to run the script." -ForegroundColor Red
    Write-Host "Possible reasons:"
    Write-Host "1. The environment '$ENV_NAME' was not created successfully."
    Write-Host "2. The script 'xsens_ik_solver_integration.py' has runtime errors."
    Write-Host "3. Conda environment path is not in the registry (try restarting terminal)."
    
    Write-Host "`nTry running setup_conda_env.bat again if you haven't successfully installed dependencies." -ForegroundColor Yellow
    exit $LASTEXITCODE
}
