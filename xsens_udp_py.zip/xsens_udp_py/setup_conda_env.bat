@echo off
echo Starting setup script...
powershell -ExecutionPolicy ByPass -File "%~dp0setup_conda_env.ps1"
if %errorlevel% neq 0 (
    echo Setup encountered errors.
)
pause
