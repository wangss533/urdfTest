#include <iostream>
#include <thread>
#include <chrono>
#include <array>
#include <algorithm>
#include <cstring>
#include <csignal>
#include <atomic>
#include <condition_variable>
#include <mutex>

#include "udp_demo.h"

using namespace std::chrono_literals;

// 高级信号处理类
class SignalHandler
{
private:
    std::atomic<bool> running_{true};
    std::atomic<bool> signal_received_{false};
    std::condition_variable cv_;
    std::mutex mtx_;
    UDPClient *client_ptr_{nullptr};

public:
    static SignalHandler &getInstance()
    {
        static SignalHandler instance;
        return instance;
    }

    void setClient(UDPClient *client)
    {
        client_ptr_ = client;
    }

    bool isRunning() const
    {
        return running_.load();
    }

    void stop()
    {
        std::lock_guard<std::mutex> lock(mtx_);
        running_ = false;
        signal_received_ = true;
        cv_.notify_all();
    }

    void waitForSignal()
    {
        std::unique_lock<std::mutex> lock(mtx_);
        cv_.wait(lock, [this]
                 { return signal_received_.load(); });
    }

    void handleSignal(int signal)
    {
        if (signal == SIGINT || signal == SIGTERM)
        {
            std::cout << "\n[INFO] 接收到中断信号 (Ctrl+C)，正在安全退出...\n";

            if (client_ptr_)
            {
                std::cout << "[STEP] 发送停止命令...\n";
                client_ptr_->sendControlCommand(false);
                std::this_thread::sleep_for(std::chrono::milliseconds(50));

                std::cout << "[STEP] 释放控制权...\n";
                client_ptr_->sendTryLock(false);
                std::this_thread::sleep_for(std::chrono::milliseconds(50));
            }

            stop();
        }
    }

    // 静态信号处理函数
    static void staticSignalHandler(int signal)
    {
        getInstance().handleSignal(signal);
    }
};

// 读取基准 AP；失败则全 0
RobotStateRecv getBaselinePositions(UDPClient &cli)
{
    RobotStateRecv recv{};
    for (int i = 0; i < 20; ++i)
    {
        if (cli.receiveRobotFeedback(recv))
        {
            return recv;
        }
        std::this_thread::sleep_for(std::chrono::milliseconds(50));
    }
    std::cerr << "[WARN] 未能读取反馈，使用全 0 作为基准位置\n";
    return recv;
}

static void sendFrame(UDPClient &cli, RobotState &robotState)
{
    cli.sendRobotControlData(robotState);
}

int main(int argc, char **argv)
{
    // 设置信号处理
    std::signal(SIGINT, SignalHandler::staticSignalHandler);  // Ctrl+C
    std::signal(SIGTERM, SignalHandler::staticSignalHandler); // 终止信号

    std::string ip = (argc >= 2) ? argv[1] : "192.168.2.16";
    uint16_t port = (argc >= 3) ? static_cast<uint16_t>(std::stoi(argv[2])) : 9001;
    IoContext io; // 兼容 18.04
    UDPClient cli(io, ip, port);

    // 设置信号处理器
    auto &signalHandler = SignalHandler::getInstance();
    signalHandler.setClient(&cli);

    try
    {
        std::cout << "[INFO] 目标 " << ip << ":" << port << "\n";

        // 3) StartFlag
        std::cout << "[STEP] StartFlag = true\n";
        cli.sendControlCommand(true);
        std::this_thread::sleep_for(std::chrono::milliseconds(100));

        // 1) SwitchOn
        std::cout << "[STEP] SwitchOn = true\n";
        cli.sendSwitchOnCommand(true);
        std::this_thread::sleep_for(std::chrono::milliseconds(100));

        // 2) tryLock
        std::cout << "[STEP] tryLock = true\n";
        cli.sendTryLock(true);
        std::this_thread::sleep_for(std::chrono::milliseconds(100));

        // 读取基准
        auto P0 = getBaselinePositions(cli);

        double ldelta = 0.01; //
        double rdelta = 0.01; //
        auto period_ms = 1ms; // 1000Hz

        std::array<double, 7> left_P = P0.Robot.AP;
        std::array<double, 7> right_P = P0.RightArm.AP;
        RobotState rs{};
        RobotStateRecv rsv{};

        std::cout << "[INFO] 开始控制循环，按 Ctrl+C 安全退出\n";
        while (signalHandler.isRunning())
        {
            cli.receiveRobotFeedback(rsv);
            if (rsv.Robot.AP[1] < (-70.0) / 180.0 * M_PI)
            {
                ldelta = 0.01;
            }
            if (rsv.RightArm.AP[1] > (70.0) / 180.0 * M_PI)
            {
                rdelta = -0.01;
            }
            if (rsv.Robot.AP[1] > (-50.0) / 180.0 * M_PI)
            {
                ldelta = -0.01;
            }
            if (rsv.RightArm.AP[1] < (50.0) / 180.0 * M_PI)
            {
                rdelta = 0.01;
            }
            left_P[1] = rsv.Robot.AP[1] + ldelta;
            right_P[1] = rsv.RightArm.AP[1] + rdelta;
            rs.Robot.P = left_P;
            rs.RightArm.P = right_P;
            sendFrame(cli, rs);
            std::cout << "[RESULT] joint2 moveto " << left_P[1] << "\n";

            std::this_thread::sleep_for(period_ms);
        }

        std::cout << "[INFO] 控制循环正常结束\n";
        return 0;
    }
    catch (const std::exception &e)
    {
        std::cerr << "[ERROR] " << e.what() << "\n";

        // 结束：关闭推送 & 释放控制权（可选下使能）
        std::cout << "[STEP] StartFlag = false\n";
        cli.sendControlCommand(false);
        std::this_thread::sleep_for(std::chrono::milliseconds(50));

        std::cout << "[STEP] tryLock = false\n";
        cli.sendTryLock(false);
        std::this_thread::sleep_for(std::chrono::milliseconds(50));
        return 1;
    }

    std::cout << "[INFO] 程序安全退出\n";
    return 0;
}
