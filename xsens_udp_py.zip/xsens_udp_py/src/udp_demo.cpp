#include <iostream>
#include <thread>
#include <chrono>
#include <array>
#include <algorithm>
#include <cstring>
#include <csignal>
#include <atomic>

#include "udp_demo.h"

using namespace std::chrono_literals;

// 全局变量用于信号处理
std::atomic<bool> g_running{true};
UDPClient *g_client_ptr = nullptr;

// 信号处理函数
void signalHandler(int signal)
{
    if (signal == SIGINT || signal == SIGTERM)
    {
        std::cout << "\n[INFO] 接收到中断信号 (Ctrl+C)，正在安全退出...\n";
        g_running = false;

        // 如果客户端指针存在，发送停止命令
        if (g_client_ptr)
        {
            std::cout << "[STEP] 发送停止命令...\n";
            g_client_ptr->sendControlCommand(false);
            std::this_thread::sleep_for(std::chrono::milliseconds(50));

            std::cout << "[STEP] 释放控制权...\n";
            g_client_ptr->sendTryLock(false);
            std::this_thread::sleep_for(std::chrono::milliseconds(50));
        }
    }
}

// 读取基准 AP；失败则全 0
RobotStateRecv getBaselinePositions(UDPClient &cli)
{
    RobotStateRecv recv{};
    for (int i = 0; i < 20; ++i)
    {
        if (cli.receiveRobotFeedback(recv))
        {
            return recv;
        }
        std::this_thread::sleep_for(std::chrono::milliseconds(50));
    }
    std::cerr << "[WARN] 未能读取反馈，使用全 0 作为基准位置\n";
    return recv;
}

static void sendFrame(UDPClient &cli,
                      RobotState &robotState)
{
    cli.sendRobotControlData(robotState);
}

int main(int argc, char **argv)
{
    // 设置信号处理
    std::signal(SIGINT, signalHandler);  // Ctrl+C
    std::signal(SIGTERM, signalHandler); // 终止信号

    std::string ip = (argc >= 2) ? argv[1] : "192.168.2.16";
    uint16_t port = (argc >= 3) ? static_cast<uint16_t>(std::stoi(argv[2])) : 9001;
    IoContext io; // 兼容 18.04
    UDPClient cli(io, ip, port);

    // 设置全局客户端指针
    g_client_ptr = &cli;

    try
    {

        std::cout << "[INFO] 目标 " << ip << ":" << port << "\n";

        // 1) StartFlag
        std::cout << "[STEP] StartFlag = true\n";
        cli.sendControlCommand(true);
        std::this_thread::sleep_for(std::chrono::milliseconds(100));

        // 2) SwitchOn
        std::cout << "[STEP] SwitchOn = true\n";
        cli.sendSwitchOnCommand(true);
        std::this_thread::sleep_for(std::chrono::milliseconds(100));

        // 3) tryLock
        std::cout << "[STEP] tryLock = true\n";
        cli.sendTryLock(true);
        std::this_thread::sleep_for(std::chrono::milliseconds(100));

        // 读取基准
        auto P0 = getBaselinePositions(cli);

        double ldelta = 0.01; //
        double rdelta = 0.01; //
        auto period_ms = 1ms; // 100H0z

        std::array<double, 7> left_P = P0.Robot.AP;
        std::array<double, 7> right_P = P0.RightArm.AP;
        RobotState rs{};
        RobotStateRecv rsv{};

        std::cout << "[INFO] 开始控制循环，按 Ctrl+C 安全退出\n";
        while (g_running)
        {
            cli.receiveRobotFeedback(rsv);
            if (rsv.Robot.AP[1] < (-70.0) / 180.0 * M_PI)
            {
                ldelta = 0.01;
            }
            if (rsv.RightArm.AP[1] > (70.0) / 180.0 * M_PI)
            {
                rdelta = -0.01;
            }
            if (rsv.Robot.AP[1] > (-50.0) / 180.0 * M_PI)
            {
                ldelta = -0.01;
            }
            if (rsv.RightArm.AP[1] < (50.0) / 180.0 * M_PI)
            {
                rdelta = 0.01;
            }
            left_P[1] = rsv.Robot.AP[1] + ldelta;
            right_P[1] = rsv.RightArm.AP[1] + rdelta;
            rs.Robot.P = left_P;
            rs.RightArm.P = right_P;
            sendFrame(cli, rs);
            std::cout << "[RESULT] joint2 moveto " << left_P[1] << "\n";

            std::this_thread::sleep_for(period_ms);
        }

        std::cout << "[INFO] 控制循环正常结束\n";
        return 0;
    }
    catch (const std::exception &e)
    {
        std::cerr << "[ERROR] " << e.what() << "\n";

        // 结束：关闭推送 & 释放控制权（可选下使能）
        std::cout << "[STEP] StartFlag = false\n";
        cli.sendControlCommand(false);
        std::this_thread::sleep_for(std::chrono::milliseconds(50));

        std::cout << "[STEP] tryLock = false\n";
        cli.sendTryLock(false);
        std::this_thread::sleep_for(std::chrono::milliseconds(50));
        return 1;
    }

    // 清理全局指针
    g_client_ptr = nullptr;
    std::cout << "[INFO] 程序安全退出\n";
    return 0;
}
