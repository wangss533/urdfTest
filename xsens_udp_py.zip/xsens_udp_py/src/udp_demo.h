
#pragma once
#include <array>
#include <cstdint>
#include <cstring>
#include <iostream>

#include <boost/asio.hpp>
#include <boost/version.hpp>
#include <nlohmann/json.hpp>

using json = nlohmann::json;
using boost::asio::ip::udp;

#ifndef BUFFER_SIZE
#define BUFFER_SIZE 4192
#endif

// 18.04 的 Boost 1.65 可能没有 io_context，这里做兼容别名
#if BOOST_VERSION >= 106600
using IoContext = boost::asio::io_context;
#else
using IoContext = boost::asio::io_service;
#endif

struct JointData {
    std::array<double,7> P{};
    std::array<double,7> V{};
    std::array<double,7> T{};
    std::array<double,7> kp{};
    std::array<double,7> kd{};
};

struct JointDataRecv {
    std::array<double,7> AP{};
    std::array<double,7> AV{};
    std::array<double,7> AT{};
};

struct RobotState {
    JointData Robot{};
    JointData RightArm{};
    RobotState() = default;
};

struct RobotStateRecv {
    JointDataRecv Robot{};
    JointDataRecv RightArm{};
    RobotStateRecv() = default;
};

class UDPClient {
public:
    UDPClient(IoContext& io_context, const std::string& ip = "192.168.2.16", uint16_t port = 9001)
        : socket_(io_context, udp::endpoint(udp::v4(), 0)),
          endpoint_(boost::asio::ip::address::from_string(ip), port)
    {
        boost::asio::socket_base::receive_buffer_size receive_option(BUFFER_SIZE);
        socket_.set_option(receive_option);
        boost::system::error_code ec_nb;
        socket_.non_blocking(true, ec_nb);  // 非阻塞；失败也不致命
    }
    


    void send(const std::array<uint8_t, BUFFER_SIZE>& data) {
        socket_.send_to(boost::asio::buffer(data), endpoint_);
    }

    // 协议：StartFlag
    void sendControlCommand(bool startFlag) {
        json command;
        command["StartFlag"] = startFlag;
        sendJson(command);
    }

    // 协议：SwitchOn
    void sendSwitchOnCommand(bool switchOnFlag) {
        json command;
        command["SwitchOn"] = switchOnFlag;
        sendJson(command);
    }

    // 协议：tryLock
    void sendTryLock(bool tryLockFlag) {
        json command;
        command["tryLock"] = tryLockFlag;
        sendJson(command);
    }

    // 协议：关节控制数据
    void sendRobotControlData(const RobotState& state) {
        json command;
        command["Robot"] = {
            {"P",  state.Robot.P},
            {"V",  state.Robot.V},
            {"T",  state.Robot.T},
            {"kp", state.Robot.kp},
            {"kd", state.Robot.kd}
        };
        command["RightArm"] = {
            {"P",  state.RightArm.P},
            {"V",  state.RightArm.V},
            {"T",  state.RightArm.T},
            {"kp", state.RightArm.kp},
            {"kd", state.RightArm.kd}
        };
        sendJson(command);
    }

    // 接收反馈（仅解析 data.{Robot,RightArm}.{AP,AV,AT}）
    bool receiveRobotFeedback(RobotStateRecv& state) {
        std::array<uint8_t, BUFFER_SIZE> received_data{};
        int len = this->receive(received_data);
        if (len <= 0) return false;

        std::string json_string(reinterpret_cast<const char*>(received_data.data()), static_cast<size_t>(len));
        try {
            json feedback = json::parse(json_string);
            const auto& d = feedback.at("data");

            state.Robot = {
                d.at("Robot").at("AP").get<std::array<double,7>>(),
                d.at("Robot").at("AV").get<std::array<double,7>>(),
                d.at("Robot").at("AT").get<std::array<double,7>>()
            };
            state.RightArm = {
                d.at("RightArm").at("AP").get<std::array<double,7>>(),
                d.at("RightArm").at("AV").get<std::array<double,7>>(),
                d.at("RightArm").at("AT").get<std::array<double,7>>()
            };
            return true;
        } catch (const std::exception& e) {
            std::cerr << "Error parsing JSON: " << e.what() << std::endl;
            return false;
        }
    }

    // 阻塞接收一帧
    int receive(std::array<uint8_t, BUFFER_SIZE>& data, int timeout_ms = 200) 
    {
        data = {};
        udp::endpoint sender;
        auto t0 = std::chrono::steady_clock::now();
        boost::system::error_code ec;

        while (true) {
            size_t len = 0;
            ec.clear();
            len = socket_.receive_from(boost::asio::buffer(data), sender, 0, ec);

            if (!ec && len > 0) {
                return static_cast<int>(len); // 成功拿到一帧
            }
            if (ec == boost::asio::error::would_block || ec == boost::asio::error::try_again) {
                // 没有数据，继续等
            } else if (ec) {
                // 其它错误：打印一次并返回 0
                std::cout << "Error: " << ec.message() << std::endl;
                return 0;
            }

            // 超时判断
            if (timeout_ms >= 0) {
                auto elapsed = std::chrono::duration_cast<std::chrono::milliseconds>(
                                std::chrono::steady_clock::now() - t0).count();
                if (elapsed >= timeout_ms) return 0; // 超时无数据
            }

            std::this_thread::sleep_for(std::chrono::milliseconds(10)); // 小睡一会儿再试
        }
    }

private:
    void sendJson(const json& j) 
    {
        const std::string s = j.dump();
        // 只发有效负载长度，避免尾部 0 破坏对端 JSON 解析
        socket_.send_to(boost::asio::buffer(s.data(), s.size()), endpoint_);
    }

    udp::socket   socket_;
    udp::endpoint endpoint_;
};

// #include <boost/asio.hpp>
// #include <iostream>
// #include <array>
// #include <cstring>
// #include <nlohmann/json.hpp>
// using json = nlohmann::json;

// using boost::asio::ip::udp;

// #define BUFFER_SIZE 4192

// struct JointData
// {
//     std::array<double, 7> P;  // 位置
//     std::array<double, 7> V;  // 速度
//     std::array<double, 7> T;  // 转矩
//     std::array<double, 7> kp; // 比例增益
//     std::array<double, 7> kd; // 微分增益
// };

// struct JointDataRecv
// {
//     std::array<double, 7> AP; // 位置
//     std::array<double, 7> AV; // 速度
//     std::array<double, 7> AT; // 转矩
// };

// struct RobotState
// {
//     JointData Robot;
//     JointData RightArm;

//     RobotState() : Robot{{}, {}, {}, {}, {}},    // 初始化 Robot 为全 0
//                    RightArm{{}, {}, {}, {}, {}}, // 初始化 RightArm 为全 0
//     {
//     }
// };

// struct RobotStateRecv
// {
//     JointDataRecv Robot;
//     JointDataRecv RightArm;

//     RobotStateRecv() : Robot{{}, {}, {}},    // 初始化 Robot 为全 0
//                        RightArm{{}, {}, {}}, // 初始化 RightArm 为全 0
//     {
//     }
// };

// class UDPClient
// {
// public:
//     UDPClient(boost::asio::io_context &io_context, const std::string &ip = "192.168.2.16", uint16_t port = 9001)
//         : socket_(io_context, udp::endpoint(udp::v4(), 0)),
//           endpoint_(boost::asio::ip::address::from_string(ip), port)
//     {
//         boost::asio::socket_base::receive_buffer_size receive_option(BUFFER_SIZE); // 1MB
//         socket_.set_option(receive_option);
//     }

//     void send(const std::array<uint8_t, BUFFER_SIZE> &data)
//     {
//         socket_.send_to(boost::asio::buffer(data), endpoint_);
//     }

//     void sendControlCommand(bool startFlag)
//     {
//         json command;
//         command["StartFlag"] = startFlag;

//         std::array<uint8_t, BUFFER_SIZE> send_data{};
//         std::string json_string = command.dump(); // 将 JSON 转为字符串

//         // 确保数据不超过 BUFFER_SIZE 字节
//         if (json_string.size() > send_data.size())
//         {
//             std::cerr << "Data too large to send!" << std::endl;
//             return;
//         }

//         // 将 JSON 字符串复制到 send_data 中
//         std::memcpy(send_data.data(), json_string.data(), json_string.size());

//         // 发送数据
//         this->send(send_data);
//     }

//     void sendSwitchOnCommand(bool switchOnFlag)
//     {
//         json command;
//         command["SwitchOn"] = switchOnFlag;

//         std::array<uint8_t, BUFFER_SIZE> send_data{};
//         std::string json_string = command.dump(); // 将 JSON 转为字符串

//         // 确保数据不超过 BUFFER_SIZE 字节
//         if (json_string.size() > send_data.size())
//         {
//             std::cerr << "Data too large to send!" << std::endl;
//             return;
//         }

//         // 将 JSON 字符串复制到 send_data 中
//         std::memcpy(send_data.data(), json_string.data(), json_string.size());

//         // 发送数据
//         this->send(send_data);
//     }

//     void sendRobotControlData(const RobotState &state)
//     {
//         json command;

//         // 填充 RobotState 数据
//         command["Robot"] = {
//             {"P", state.Robot.P},
//             {"V", state.Robot.V},
//             {"T", state.Robot.T},
//             {"kp", state.Robot.kp},
//             {"kd", state.Robot.kd}};

//         command["RightArm"] = {
//             {"P", state.RightArm.P},
//             {"V", state.RightArm.V},
//             {"T", state.RightArm.T},
//             {"kp", state.RightArm.kp},
//             {"kd", state.RightArm.kd}};

//         // 将 JSON 转为字符串
//         std::string json_string = command.dump();

//         std::array<uint8_t, BUFFER_SIZE> send_data{};
//         // 确保数据不超过 BUFFER_SIZE 字节
//         if (json_string.size() > send_data.size())
//         {
//             std::cerr << "Data too large to send!" << std::endl;
//             return;
//         }

//         // 将 JSON 字符串复制到 send_data 中
//         std::memcpy(send_data.data(), json_string.data(), json_string.size());

//         // 发送数据
//         this->send(send_data);
//     }

//     bool receiveRobotFeedback(RobotStateRecv &state)
//     {
//         std::array<uint8_t, BUFFER_SIZE> received_data{};
//         int len = this->receive(received_data);
//         if (len == 0)
//             return false;

//         // 将接收到的字节数据转换为 JSON 字符串
//         std::string json_string(std::string(received_data.begin(), received_data.begin() + len));
//         // std::cout << json_string << std::endl;

//         try
//         {
//             json feedback = json::parse(json_string);

//             state.Robot = {
//                 feedback["data"]["Robot"]["AP"].get<std::array<double, 7>>(),
//                 feedback["data"]["Robot"]["AV"].get<std::array<double, 7>>(),
//                 feedback["data"]["Robot"]["AT"].get<std::array<double, 7>>()};
//             state.RightArm = {
//                 feedback["data"]["RightArm"]["AP"].get<std::array<double, 7>>(),
//                 feedback["data"]["RightArm"]["AV"].get<std::array<double, 7>>(),
//                 feedback["data"]["RightArm"]["AT"].get<std::array<double, 7>>()};
//             return true;
//         }
//         catch (const std::exception &e)
//         {
//             std::cerr << "Error parsing JSON: " << e.what() << std::endl;
//             return false;
//         }
//     }

//     int receive(std::array<uint8_t, BUFFER_SIZE> &data)
//     {
//         data = {};
//         boost::system::error_code ec;

//         // 直接接收数据，不使用available()检查
//         size_t len = socket_.receive_from(boost::asio::buffer(data), endpoint_, 0, ec);
//         // std::cout << ec << std::endl;
//         if (ec && ec != boost::asio::error::would_block)
//         {
//             std::cout << "Error: " << ec.message() << std::endl;
//         }

//         return len;
//     }

// private:
//     udp::socket socket_;
//     udp::endpoint endpoint_;
// };