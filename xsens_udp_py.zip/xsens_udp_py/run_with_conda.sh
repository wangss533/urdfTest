#!/bin/bash

# Define environment name
ENV_NAME="xsens_env"

# Clear PYTHONPATH to avoid ROS system package conflicts
export PYTHONPATH=""

# Detect conda
if [ -z "$CONDA_EXE" ]; then
    # Try to guess conda location if not in path
    if [ -f "/home/desaysv/WorkSpace/wss/code/teleop/xr_teleoperate/miniforge3/etc/profile.d/conda.sh" ]; then
        source "/home/desaysv/WorkSpace/wss/code/teleop/xr_teleoperate/miniforge3/etc/profile.d/conda.sh"
    elif [ -f "$HOME/miniforge3/etc/profile.d/conda.sh" ]; then
        source "$HOME/miniforge3/etc/profile.d/conda.sh"
    elif [ -f "$HOME/anaconda3/etc/profile.d/conda.sh" ]; then
        source "$HOME/anaconda3/etc/profile.d/conda.sh"
    elif [ -f "$HOME/miniconda3/etc/profile.d/conda.sh" ]; then
        source "$HOME/miniconda3/etc/profile.d/conda.sh"
    elif [ -f "/opt/conda/etc/profile.d/conda.sh" ]; then
        source "/opt/conda/etc/profile.d/conda.sh"
    else
        # Fallback: assume conda is in PATH or initialized in .bashrc
        # This might fail in non-interactive shells if conda isn't initialized
        :
    fi
else
    # Initialize conda for this script
    eval "$($CONDA_EXE shell.bash hook)"
fi

# Activate environment
conda activate $ENV_NAME

if [ $? -ne 0 ]; then
    echo "Error: Failed to activate Conda environment '$ENV_NAME'."
    echo "Please run ./setup_conda_env.sh first."
    exit 1
fi

# Run the integration script
echo "Running XSens Integration in Conda environment: $ENV_NAME"
python xsens_ik_solver_integration.py "$@"
