#!/usr/bin/env python3
"""
Simple UDP Replay / Simulator for XSens Data
Generates mock XSens UDP packets without needing scapy or pcapng files.
"""

import socket
import time
import struct
import math
import sys

# Define target
TARGET_IP = "127.0.0.1"
TARGET_PORT = 9763

def create_mock_xsens_packet(frame_counter, time_sec):
    """
    Create a mock XSens packet based on the structure expected by XSensUDPReceiverFixed.
    This is a simplified version, constructing the payload manually.
    """
    # Header: ID (4 bytes) + Count (4 bytes) + ...
    # Based on xsens_udp_receiver_fixed.py logic:
    # It expects "MXTP02" header usually? Or specific struct?
    # Let's look at xsens_udp_receiver_fixed.py parse_datagram:
    # header = data[:24]
    # (id_str, sample_counter, datagram_counter, item_count, time_code, char_id, ...)
    # struct.unpack('!6sIIIBBI', header)
    
    # ID String "MXTP02"
    id_str = b'MXTP02'
    sample_counter = frame_counter
    datagram_counter = frame_counter
    item_count = 23 # Typically 23 segments for full body? Or just the ones we map.
    time_code = int(time_sec * 1000)
    char_id = 0
    reserved = 0
    
    header = struct.pack('!6sIIIBBI', id_str, sample_counter, datagram_counter, item_count, time_code, char_id, reserved)
    
    # Payload: 23 Segments * (ID(4) + Pos(12) + Rot(16))
    # Segment ID (4 bytes), Pos X/Y/Z (3*4 bytes), Rot Q1/Q2/Q3/Q4 (4*4 bytes) -> Total 32 bytes per segment
    payload = b''
    
    # Segment Names mapping (simplified order, usually ID 1..23)
    # We just generate some movement for "LeftUpperArm" (ID 12?) and "RightUpperArm" (ID 8?) etc.
    # To keep it simple, we just generate valid data for all IDs 1 to 24.
    
    # Generate a sine wave motion
    angle = math.sin(time_sec * 2.0) * 0.5 # +/- 0.5 rad
    
    for seg_id in range(1, 24):
        # Position (x,y,z) - just keep them at 0 or logical offset
        x, y, z = 0.0, 1.0, 0.0 # Arbitrary
        
        # Orientation (Quaternion x,y,z,w)
        # Identity: 0,0,0,1
        qx, qy, qz, qw = 0.0, 0.0, 0.0, 1.0
        
        # Add some motion to specific segments
        # Right Arm (IDs often 7,8,9,10)
        # Left Arm (IDs often 11,12,13,14)
        if seg_id in [8, 12]: # Upper Arms
             # Rotate around X
             qx = math.sin(angle/2)
             qw = math.cos(angle/2)
        
        segment_data = struct.pack('!Ifffffff', seg_id, x, y, z, qx, qy, qz, qw)
        payload += segment_data
        
    return header + payload

def main():
    sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    print(f"Sending mock XSens data to {TARGET_IP}:{TARGET_PORT}...")
    
    start_time = time.time()
    frame = 0
    
    try:
        while True:
            current_time = time.time() - start_time
            packet = create_mock_xsens_packet(frame, current_time)
            
            sock.sendto(packet, (TARGET_IP, TARGET_PORT))
            
            frame += 1
            if frame % 100 == 0:
                print(f"\rSent {frame} frames...", end="", flush=True)
                
            time.sleep(0.01) # 100Hz
            
    except KeyboardInterrupt:
        print("\nStopped.")

if __name__ == "__main__":
    main()
