#!/usr/bin/env python3
"""
better_parser.py - 更好的pcapng解析器
"""

from scapy.all import *
import socket
import time
import sys

def better_parse_pcapng(pcap_file):
    """更好的pcapng解析"""
    
    packets = rdpcap(pcap_file)
    print(f"读取到 {len(packets)} 个数据包")
    
    udp_packets = []
    
    for i, pkt in enumerate(packets):
        # 方法1: 检查是否有UDP层
        if pkt.haslayer(UDP):
            print(f"包 {i+1}: 有UDP层")
            udp_layer = pkt[UDP]
            payload = bytes(udp_layer.payload)
            udp_packets.append(payload)
            continue
        
        # 方法2: 检查原始载荷
        if pkt.haslayer(Raw):
            raw_data = bytes(pkt[Raw])
            print(f"包 {i+1}: 有Raw层, 长度={len(raw_data)}")
            
            # 尝试从Raw数据中提取UDP
            udp_payload = extract_udp_from_raw(raw_data)
            if udp_payload:
                udp_packets.append(udp_payload)
                print(f"  从Raw提取UDP载荷: {len(udp_payload)} 字节")
            continue
        
        # 方法3: 显示包类型
        print(f"包 {i+1}: 类型={pkt.name}, 长度={len(pkt)}")
        
        # 只检查前10个包
        if i >= 9:
            print("...")
            break
    
    return udp_packets

def extract_udp_from_raw(raw_data):
    """从Raw数据中提取UDP载荷"""
    # 简化：假设是以太网帧
    if len(raw_data) < 14 + 20 + 8:  # 以太网 + IP + UDP头部
        return None
    
    # 跳过以太网头部 (14字节)
    ip_packet = raw_data[14:]
    
    # 检查IP协议 (第10字节，0-based)
    if len(ip_packet) < 10 or ip_packet[9] != 17:  # 17 = UDP
        return None
    
    # IP头部长度 (单位：4字节)
    ip_header_len = (ip_packet[0] & 0x0F) * 4
    
    if len(ip_packet) < ip_header_len + 8:
        return None
    
    # UDP载荷
    udp_payload = ip_packet[ip_header_len + 8:]
    return udp_payload

def main():
    if len(sys.argv) < 2:
        print("用法: python3 better_parser.py <pcap文件>")
        sys.exit(1)
    
    pcap_file = sys.argv[1]
    print(f"解析文件: {pcap_file}")
    
    udp_packets = better_parse_pcapng(pcap_file)
    
    print(f"\n总共提取到 {len(udp_packets)} 个UDP数据包")
    
    if udp_packets:
        # 发送UDP包
        sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        
        print(f"\n发送到 127.0.0.1:9763")
        print("按 Ctrl+C 停止\n")
        
        sent = 0
        try:
            # while(True):
                for i, payload in enumerate(udp_packets, 1):
                    sock.sendto(payload, ('127.0.0.1', 9763))
                    sent += 1
                    
                    print(f"发送包 {i}: {len(payload)} 字节", end='\r')
                    
                    if len(payload) >= 4 and payload[:4] == b'MXTP':
                        print(f"\n  ✅ Xsens数据包 ({len(payload)} 字节)")
                    
                    time.sleep(0.0025)
            
        except KeyboardInterrupt:
            print("\n\n用户中断")
        finally:
            sock.close()
            print(f"\n发送完成: {sent} 个UDP包")

if __name__ == "__main__":
    main()