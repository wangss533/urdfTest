
python data/play_sim.py