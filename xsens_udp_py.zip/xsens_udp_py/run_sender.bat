@echo off
set "SCRIPT_PATH=examples\example_send_fixed_joints.py"

rem Activate Conda environment
call conda activate xsens_env
if %errorlevel% neq 0 (
    echo Error: Failed to activate environment 'xsens_env'.
    pause
    exit /b 1
)

echo Running %SCRIPT_PATH% in xsens_env...
echo (Press Ctrl+C to stop without annoying prompts)
echo.

python "%SCRIPT_PATH%" %*

call conda deactivate
