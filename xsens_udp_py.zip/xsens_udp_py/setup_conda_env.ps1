# 强制输出立即刷新
$OutputEncoding = [Console]::OutputEncoding

Write-Host "Initializing setup script..." -ForegroundColor Cyan

# Check for conda
Write-Host "Checking for Conda..." -NoNewline
if (-not (Get-Command conda -ErrorAction SilentlyContinue)) {
    Write-Host " Not Found!" -ForegroundColor Red
    Write-Error "Conda is not found in PATH. Please install Anaconda, Miniconda, or Miniforge and ensure it is in your PATH."
    exit 1
}
Write-Host " Found." -ForegroundColor Green

# 打印 Conda 信息以便调试
Write-Host "Conda Info:" -ForegroundColor Gray
conda info
Write-Host "--------------------------------" -ForegroundColor Gray

$ENV_NAME = "xsens_env"

Write-Host "Starting environment setup for XSens Control on Windows..." -ForegroundColor Green

# 设置更长的超时时间以应对网络问题
Write-Host "Configuring Conda timeout settings..."
conda config --set remote_read_timeout_secs 120
conda config --set remote_connect_timeout_secs 60

# Check if environment exists
Write-Host "Checking existing environments..."
$envList = conda env list
$envExists = $envList -match $ENV_NAME

if ($envExists) {
    Write-Host "Environment '$ENV_NAME' detected in list. Updating..." -ForegroundColor Yellow
} else {
    Write-Host "Environment '$ENV_NAME' not found (or not detected). Attempting to create..." -ForegroundColor Cyan
    
    $MaxRetries = 3
    $RetryCount = 0
    $Success = $false

    while (-not $Success -and $RetryCount -lt $MaxRetries) {
        if ($RetryCount -gt 0) {
            Write-Host "Retry attempt $($RetryCount + 1)..." -ForegroundColor Yellow
            # 如果之前的尝试失败了，可能残留了部分环境，先尝试清理
            Write-Host "Cleaning up partial environment and cache..."
            conda env remove -n $ENV_NAME -y 2>$null
            conda clean -p -t -y 2>$null
            Start-Sleep -Seconds 3
        }
        
        # 尝试创建环境
        conda create -n $ENV_NAME -c conda-forge python=3.8 -y
        
        if ($LASTEXITCODE -eq 0) {
            $Success = $true
        } else {
            $RetryCount++
            Write-Host "Creation failed (Attempt $RetryCount/$MaxRetries)." -ForegroundColor Red
        }
    }
    
    if (-not $Success) {
        Write-Host "Error: Failed to create environment '$ENV_NAME' after $MaxRetries attempts." -ForegroundColor Red
        Write-Host "Possible solutions:"
        Write-Host "1. Check your internet connection."
        Write-Host "2. Try using a VPN if you are in a restricted network region."
        Write-Host "3. Manually run: conda clean --all"
        exit 1
    }
    
    Write-Host "Environment created successfully." -ForegroundColor Green
}

Write-Host "Installing/Updating dependencies from conda-forge..." -ForegroundColor Green

# 验证环境是否可用 (不依赖 conda env list，直接尝试运行)
Write-Host "Verifying environment '$ENV_NAME'..."
conda run -n $ENV_NAME python --version 2>$null
if ($LASTEXITCODE -ne 0) {
    Write-Host "Warning: Could not run python in '$ENV_NAME'. It might not be fully ready, but we will try to install dependencies anyway." -ForegroundColor Yellow
} else {
    Write-Host "Environment verification passed." -ForegroundColor Green
}

# Installing packages with retry logic
$PkgMaxRetries = 3
$PkgRetryCount = 0
$PkgSuccess = $false

while (-not $PkgSuccess -and $PkgRetryCount -lt $PkgMaxRetries) {
    if ($PkgRetryCount -gt 0) {
        Write-Host "Retry attempt $($PkgRetryCount + 1) for dependencies..." -ForegroundColor Yellow
        conda clean -p -t -y 2>$null
    }

    Write-Host "Solving environment dependencies..." -ForegroundColor Cyan
    Write-Host "Note: This step may take 5-10 minutes. Please be patient." -ForegroundColor Yellow
    
    # 使用 --override-channels 强制只用 conda-forge，避免与 defaults/清华源冲突，大幅加速 Solver
    conda install -n $ENV_NAME -c conda-forge --override-channels -y `
        python=3.8 `
        "pinocchio>=2.6" `
        "casadi>=3.5" `
        "numpy<2.0" `
        scipy `
        ipopt

    if ($LASTEXITCODE -eq 0) {
        $PkgSuccess = $true
    } else {
        $PkgRetryCount++
        Write-Host "Installation failed (Attempt $PkgRetryCount/$PkgMaxRetries)." -ForegroundColor Red
    }
}

if ($PkgSuccess) {
    Write-Host "Environment '$ENV_NAME' setup complete!" -ForegroundColor Green
    Write-Host "To run the project, use: .\run_with_conda.bat"
} else {
    Write-Host "Dependency installation failed after $PkgMaxRetries attempts." -ForegroundColor Red
}
