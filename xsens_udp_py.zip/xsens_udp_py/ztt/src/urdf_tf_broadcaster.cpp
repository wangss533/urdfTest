#include <iostream>
#include <string>
#include <vector>
#include <map>
#include <tinyxml2.h>
#include <Eigen/Dense>
#include <Eigen/Geometry>
#include <iomanip>

// ROS 2 Headers
#include <rclcpp/rclcpp.hpp>
#include <tf2_ros/transform_broadcaster.h>
#include <geometry_msgs/msg/transform_stamped.hpp>
#include <tf2/LinearMath/Quaternion.h>

// Simple structure to represent a transform
struct Transform {
    Eigen::Vector3d translation;
    Eigen::Quaterniond rotation;

    Transform() : translation(0,0,0), rotation(1,0,0,0) {}
    
    static Transform Identity() {
        return Transform();
    }
};

// Structure to represent a URDF Joint
struct Joint {
    std::string name;
    std::string type;
    std::string parent_link;
    std::string child_link;
    Transform origin;
    Eigen::Vector3d axis;
    
    // Limits
    double lower_limit;
    double upper_limit;

    Joint() : axis(1,0,0), lower_limit(0), upper_limit(0) {}
};

// Structure to represent a URDF Link
struct Link {
    std::string name;
    // We could add visual/collision/inertial info here
};

// Simple URDF Parser
class URDFParser {
public:
    bool parse(const std::string& filename) {
        tinyxml2::XMLDocument doc;
        if (doc.LoadFile(filename.c_str()) != tinyxml2::XML_SUCCESS) {
            std::cerr << "Failed to load URDF file: " << filename << std::endl;
            return false;
        }

        tinyxml2::XMLElement* robot = doc.FirstChildElement("robot");
        if (!robot) {
            std::cerr << "No <robot> tag found" << std::endl;
            return false;
        }

        robot_name_ = robot->Attribute("name") ? robot->Attribute("name") : "unnamed";

        // Parse Links
        for (tinyxml2::XMLElement* link_xml = robot->FirstChildElement("link"); link_xml; link_xml = link_xml->NextSiblingElement("link")) {
            Link link;
            const char* name = link_xml->Attribute("name");
            if (name) {
                link.name = name;
                links_[link.name] = link;
            }
        }

        // Parse Joints
        for (tinyxml2::XMLElement* joint_xml = robot->FirstChildElement("joint"); joint_xml; joint_xml = joint_xml->NextSiblingElement("joint")) {
            Joint joint;
            const char* name = joint_xml->Attribute("name");
            const char* type = joint_xml->Attribute("type");
            
            if (name) joint.name = name;
            if (type) joint.type = type;

            // Parent
            tinyxml2::XMLElement* parent_xml = joint_xml->FirstChildElement("parent");
            if (parent_xml && parent_xml->Attribute("link")) {
                joint.parent_link = parent_xml->Attribute("link");
            }

            // Child
            tinyxml2::XMLElement* child_xml = joint_xml->FirstChildElement("child");
            if (child_xml && child_xml->Attribute("link")) {
                joint.child_link = child_xml->Attribute("link");
            }

            // Origin
            tinyxml2::XMLElement* origin_xml = joint_xml->FirstChildElement("origin");
            if (origin_xml) {
                const char* xyz = origin_xml->Attribute("xyz");
                const char* rpy = origin_xml->Attribute("rpy");
                
                if (xyz) {
                    std::stringstream ss(xyz);
                    double x, y, z;
                    ss >> x >> y >> z;
                    joint.origin.translation = Eigen::Vector3d(x, y, z);
                }
                
                if (rpy) {
                    std::stringstream ss(rpy);
                    double r, p, y;
                    ss >> r >> p >> y;
                    // RPY to Quaternion (Fixed XYZ)
                    Eigen::AngleAxisd rollAngle(r, Eigen::Vector3d::UnitX());
                    Eigen::AngleAxisd pitchAngle(p, Eigen::Vector3d::UnitY());
                    Eigen::AngleAxisd yawAngle(y, Eigen::Vector3d::UnitZ());
                    Eigen::Quaterniond q = yawAngle * pitchAngle * rollAngle;
                    joint.origin.rotation = q;
                }
            }

            // Axis
            tinyxml2::XMLElement* axis_xml = joint_xml->FirstChildElement("axis");
            if (axis_xml && axis_xml->Attribute("xyz")) {
                std::stringstream ss(axis_xml->Attribute("xyz"));
                double x, y, z;
                ss >> x >> y >> z;
                joint.axis = Eigen::Vector3d(x, y, z).normalized();
            }

            joints_[joint.name] = joint;
            
            // Build kinematic tree structure
            adj_list_[joint.parent_link].push_back(joint.name);
        }

        // Find root link (a link that is never a child)
        std::map<std::string, bool> is_child;
        for (const auto& kv : joints_) {
            is_child[kv.second.child_link] = true;
        }
        
        for (const auto& kv : links_) {
            if (is_child.find(kv.first) == is_child.end()) {
                root_link_ = kv.first;
                break;
            }
        }
        
        if (root_link_.empty() && !links_.empty()) {
            root_link_ = links_.begin()->first; // Fallback
        }

        return true;
    }

    // Forward Kinematics to compute all link transforms given joint positions
    // Returns map: link_name -> World Transform
    std::map<std::string, Transform> computeFK(const std::map<std::string, double>& joint_positions) {
        std::map<std::string, Transform> transforms;
        if (root_link_.empty()) return transforms;

        // DFS or BFS to traverse tree
        transforms[root_link_] = Transform::Identity();
        
        std::vector<std::string> stack;
        stack.push_back(root_link_);

        while (!stack.empty()) {
            std::string current_link = stack.back();
            stack.pop_back();

            Transform current_tf = transforms[current_link];

            // Iterate over joints where current_link is parent
            if (adj_list_.find(current_link) != adj_list_.end()) {
                for (const std::string& joint_name : adj_list_[current_link]) {
                    const Joint& joint = joints_[joint_name];
                    std::string child_link = joint.child_link;

                    // Compute joint local transform
                    Transform joint_tf; // This is T_parent_child
                    
                    // 1. Static transform from parent to joint frame (origin)
                    Eigen::Vector3d p_static = joint.origin.translation;
                    Eigen::Quaterniond q_static = joint.origin.rotation;

                    // 2. Dynamic transform based on joint type and position
                    double q_val = 0.0;
                    if (joint_positions.find(joint.name) != joint_positions.end()) {
                        q_val = joint_positions.at(joint.name);
                    }

                    Eigen::Vector3d p_dynamic(0,0,0);
                    Eigen::Quaterniond q_dynamic(1,0,0,0);

                    if (joint.type == "revolute" || joint.type == "continuous") {
                        q_dynamic = Eigen::AngleAxisd(q_val, joint.axis);
                    } else if (joint.type == "prismatic") {
                        p_dynamic = joint.axis * q_val;
                    } else if (joint.type == "fixed") {
                        // No motion
                    }

                    // Combined local transform: T_static * T_dynamic
                    // T_parent_child = T_origin * T_joint_motion
                    // Rotation: R = R_static * R_dynamic
                    // Translation: P = P_static + R_static * P_dynamic
                    joint_tf.rotation = q_static * q_dynamic;
                    joint_tf.translation = p_static + q_static * p_dynamic;

                    // Compute global transform
                    Transform child_global;
                    child_global.rotation = current_tf.rotation * joint_tf.rotation;
                    child_global.translation = current_tf.translation + current_tf.rotation * joint_tf.translation;

                    transforms[child_link] = child_global;
                    stack.push_back(child_link);
                }
            }
        }
        return transforms;
    }
    
    // NEW: Compute transforms relative to PARENT (for TF broadcasting tree)
    // Instead of global world transforms, TF prefers Parent->Child transforms.
    // Returns map: child_link_name -> (parent_link_name, Transform_from_parent_to_child)
    struct LinkRelTransform {
        std::string parent_name;
        Transform transform;
    };
    
    std::map<std::string, LinkRelTransform> computeRelativeTransforms(const std::map<std::string, double>& joint_positions) {
        std::map<std::string, LinkRelTransform> rel_transforms;
        
        for (const auto& kv : joints_) {
            const Joint& joint = kv.second;
            
            // 1. Static transform from parent to joint frame (origin)
            Eigen::Vector3d p_static = joint.origin.translation;
            Eigen::Quaterniond q_static = joint.origin.rotation;

            // 2. Dynamic transform based on joint type and position
            double q_val = 0.0;
            if (joint_positions.find(joint.name) != joint_positions.end()) {
                q_val = joint_positions.at(joint.name);
            }

            Eigen::Vector3d p_dynamic(0,0,0);
            Eigen::Quaterniond q_dynamic(1,0,0,0);

            if (joint.type == "revolute" || joint.type == "continuous") {
                q_dynamic = Eigen::AngleAxisd(q_val, joint.axis);
            } else if (joint.type == "prismatic") {
                p_dynamic = joint.axis * q_val;
            }

            // Combined local transform: T_parent_child
            Transform joint_tf;
            joint_tf.rotation = q_static * q_dynamic;
            joint_tf.translation = p_static + q_static * p_dynamic;
            
            LinkRelTransform info;
            info.parent_name = joint.parent_link;
            info.transform = joint_tf;
            
            rel_transforms[joint.child_link] = info;
        }
        
        return rel_transforms;
    }

    const std::map<std::string, Joint>& getJoints() const { return joints_; }
    const std::string& getRootLink() const { return root_link_; }

private:
    std::string robot_name_;
    std::string root_link_;
    std::map<std::string, Link> links_;
    std::map<std::string, Joint> joints_;
    std::map<std::string, std::vector<std::string>> adj_list_; // parent_link -> list of joint names
};

// ROS 2 Node
class URDFPublisherNode : public rclcpp::Node {
public:
    URDFPublisherNode(const std::string& urdf_file) : Node("urdf_tf_broadcaster") {
        // Initialize parser
        if (!parser_.parse(urdf_file)) {
            RCLCPP_ERROR(this->get_logger(), "Failed to parse URDF file: %s", urdf_file.c_str());
            return;
        }
        RCLCPP_INFO(this->get_logger(), "URDF Parsed successfully. Root link: %s", parser_.getRootLink().c_str());

        // Initialize TF Broadcaster
        tf_broadcaster_ = std::make_unique<tf2_ros::TransformBroadcaster>(*this);

        // Timer for publishing loop (e.g., 30 Hz)
        timer_ = this->create_wall_timer(
            std::chrono::milliseconds(33),
            std::bind(&URDFPublisherNode::timer_callback, this));
            
        // Initialize dummy joint state
        // In a real app, you might subscribe to /joint_states
        const auto& joints = parser_.getJoints();
        for (const auto& kv : joints) {
            if (kv.second.type != "fixed") {
                joint_state_[kv.first] = 0.0;
            }
        }
        
        t_start_ = this->now().seconds();
    }

private:
    void timer_callback() {
        // Update joint state (Simple animation)
        double t = this->now().seconds() - t_start_;
        
        // Example: Animate left arm shoulder (joint_arm_l1)
        if (joint_state_.count("joint_arm_l1")) {
            joint_state_["joint_arm_l1"] = 0.5 * sin(t); 
        }
        // Example: Animate right arm shoulder
        if (joint_state_.count("joint_arm_r1")) {
            joint_state_["joint_arm_r1"] = -0.5 * sin(t);
        }

        // Compute Relative Transforms (Parent -> Child)
        auto rel_transforms = parser_.computeRelativeTransforms(joint_state_);

        // Broadcast TF
        rclcpp::Time now = this->now();
        for (const auto& kv : rel_transforms) {
            const std::string& child_frame = kv.first;
            const std::string& parent_frame = kv.second.parent_name;
            const Transform& tf = kv.second.transform;

            geometry_msgs::msg::TransformStamped t;
            t.header.stamp = now;
            t.header.frame_id = parent_frame;
            t.child_frame_id = child_frame;

            t.transform.translation.x = tf.translation.x();
            t.transform.translation.y = tf.translation.y();
            t.transform.translation.z = tf.translation.z();

            t.transform.rotation.x = tf.rotation.x();
            t.transform.rotation.y = tf.rotation.y();
            t.transform.rotation.z = tf.rotation.z();
            t.transform.rotation.w = tf.rotation.w();

            tf_broadcaster_->sendTransform(t);
        }
        
        // Broadcast Root (Optional: Map -> Base)
        // geometry_msgs::msg::TransformStamped t_root;
        // t_root.header.stamp = now;
        // t_root.header.frame_id = "map";
        // t_root.child_frame_id = parser_.getRootLink();
        // t_root.transform.rotation.w = 1.0;
        // tf_broadcaster_->sendTransform(t_root);
    }

    URDFParser parser_;
    std::unique_ptr<tf2_ros::TransformBroadcaster> tf_broadcaster_;
    rclcpp::TimerBase::SharedPtr timer_;
    std::map<std::string, double> joint_state_;
    double t_start_;
};

int main(int argc, char** argv) {
    rclcpp::init(argc, argv);

    std::string urdf_file = "../rock_c05l_with_grippers.urdf";
    if (argc > 1) {
        urdf_file = argv[1];
    }

    auto node = std::make_shared<URDFPublisherNode>(urdf_file);
    rclcpp::spin(node);
    rclcpp::shutdown();
    return 0;
}
