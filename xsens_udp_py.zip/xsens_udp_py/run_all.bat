@echo off
start "XSens IK Solver" cmd /k "python xsens_ik_solver_integration.py --enable-smooth-start"
timeout /t 10 /nobreak
start "Broadcast Data" cmd /k ".\data\broadcast.bat" > broadcast.log
