#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Dual-arm IK adapter with Pinocchio+CasADi and a corrected human arm-angle (psi) loader.

Key assumptions (as provided by user):
- Human TXT quaternion format: wxyz
- Human segment orientations are expressed in WORLD frame
- World frame: +x forward, +y left, +z up

This script:
- Solves dual-arm IK using CasADi+Pinocchio
- Computes robot psi via proxy joint frames (Route B)
- Optimizes psi angle using weighted loss in the objective function (NOT null space)
  (psi_weight parameter controls the loss weight, multiplied by 500)
- Loads human psi from a TXT (56 floats per line: left 4 segments + right 4 segments, each xyz+qwxyz)
  and reconstructs elbow/wrist centers using segment orientation + bone lengths
"""

from cgi import print_form
import sys
from pathlib import Path
import argparse
import numpy as np

# Ensure "tv" env packages preferred (optional, keep as in user's code)
sys.path.insert(0, "/home/desaysv/.conda/envs/tv/lib/python3.8/site-packages")

import casadi as casadi
import pinocchio as pin
from pinocchio import casadi as cpin

# Optional: user local util
try:
    from modules.utils.weighted_moving_filter import WeightedMovingFilter
except Exception:
    WeightedMovingFilter = None


class Arm_IK_Casadi_Adapter_Interpolated_Filtered:
    def __init__(self, urdf_path, urdf_dir,
                 debug=False, verbose=False, log_file=None,
                 psi_enabled=True, psi_weight=0.2,
                 world_up=(0.0, 0.0, 1.0),
                 psi_mode='hold', psi_target=None):
        self.debug = bool(debug)
        self.verbose = bool(verbose)
        self.log_file = log_file

        # --- Psi config (Route B) ---
        self.psi_enabled = bool(psi_enabled)
        self.psi_weight = float(psi_weight)
        self.psi_mode = str(psi_mode)
        self.psi_target = psi_target

        self.world_up = np.array(world_up, dtype=float).reshape(3,)
        wu_norm = float(np.linalg.norm(self.world_up))
        if wu_norm < 1e-9:
            self.world_up = np.array([0.0, 0.0, 1.0], dtype=float)
        else:
            self.world_up /= wu_norm

        self.prev_psi_l = 0.0
        self.prev_psi_r = 0.0

        # --- Real-time interpolation/filtering config ---
        self.interp_enabled = True
        self.interp_factor = 10
        self.filter_enabled = True
        self.filter_type = 'ema'  # 'ema' or 'wma'
        self.alpha = 0.3
        self.adaptive = True
        self.prev_joint = None
        self.interp_buffer = []
        self.ema_filtered = None

        if self.debug:
            import logging
            logging.basicConfig(
                level=logging.DEBUG,
                format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
                filename=log_file if log_file else None,
                filemode='w' if log_file else 'a'
            )
            self.logger = logging.getLogger(__name__)

        np.set_printoptions(precision=5, suppress=True, linewidth=220)

        # -----------------------------
        # Build robot / reduced model
        # -----------------------------
        self.model = pin.buildModelFromUrdf(urdf_path)
        self.robot = pin.RobotWrapper(self.model)

        # Lock non-arm joints (Rock_C05)
        self.mixed_jointsToLockIDs = [
            "joint_waist_pitch",
            "joint_waist_up",
            "joint_wheel_l",
            "joint_wheel_r"
        ]

        joint_ids_to_lock = []
        for joint_name in self.mixed_jointsToLockIDs:
            try:
                joint_ids_to_lock.append(self.robot.model.getJointId(joint_name))
            except Exception:
                print(f"Warning: Joint {joint_name} not found in model")

        reference_config = np.zeros(self.robot.model.nq)
        reduced_model = pin.buildReducedModel(self.robot.model, joint_ids_to_lock, reference_config)
        self.reduced_robot = pin.RobotWrapper(reduced_model)

        # -----------------------------
        # Add frames (EE + psi proxies)
        # -----------------------------
        try:
            # Right EE at joint_arm_r7
            joint_arm_r7_id = self.reduced_robot.model.getJointId('joint_arm_r7')
            gripper_pos_r = np.array([0, -0.128, -0.037], dtype=float)
            gripper_rpy_r = np.array([-1.5708, -1.5708, 0], dtype=float)
            gripper_rot_r = pin.rpy.rpyToMatrix(*gripper_rpy_r.tolist())
            self.reduced_robot.model.addFrame(
                pin.Frame('R_ee', joint_arm_r7_id, pin.SE3(gripper_rot_r, gripper_pos_r), pin.FrameType.OP_FRAME)
            )

            # Psi proxy frames
            I3 = pin.SE3.Identity()
            jid_l1 = self.reduced_robot.model.getJointId('joint_arm_l1')
            jid_l4 = self.reduced_robot.model.getJointId('joint_arm_l4')
            jid_l7 = self.reduced_robot.model.getJointId('joint_arm_l7')
            jid_r1 = self.reduced_robot.model.getJointId('joint_arm_r1')
            jid_r4 = self.reduced_robot.model.getJointId('joint_arm_r4')
            jid_r7 = self.reduced_robot.model.getJointId('joint_arm_r7')

            self.reduced_robot.model.addFrame(pin.Frame('L_shoulder', jid_l1, I3, pin.FrameType.OP_FRAME))
            self.reduced_robot.model.addFrame(pin.Frame('L_elbow',    jid_l4, I3, pin.FrameType.OP_FRAME))
            self.reduced_robot.model.addFrame(pin.Frame('L_wrist',    jid_l7, I3, pin.FrameType.OP_FRAME))
            self.reduced_robot.model.addFrame(pin.Frame('R_shoulder', jid_r1, I3, pin.FrameType.OP_FRAME))
            self.reduced_robot.model.addFrame(pin.Frame('R_elbow',    jid_r4, I3, pin.FrameType.OP_FRAME))
            self.reduced_robot.model.addFrame(pin.Frame('R_wrist',    jid_r7, I3, pin.FrameType.OP_FRAME))

            # Left EE at joint_arm_l7
            joint_arm_l7_id = self.reduced_robot.model.getJointId('joint_arm_l7')
            gripper_pos_l = np.array([0, 0.128, -0.037], dtype=float)
            gripper_rpy_l = np.array([1.5708, -1.5708, 0], dtype=float)
            gripper_rot_l = pin.rpy.rpyToMatrix(*gripper_rpy_l.tolist())
            self.reduced_robot.model.addFrame(
                pin.Frame('L_ee', joint_arm_l7_id, pin.SE3(gripper_rot_l, gripper_pos_l), pin.FrameType.OP_FRAME)
            )

            self.reduced_robot.data = self.reduced_robot.model.createData()

        except Exception as e:
            print(f"Error: Could not add frames. Check joint names. {e}")
            raise

        # Frame IDs
        self.L_hand_id = self.reduced_robot.model.getFrameId("L_ee")
        self.R_hand_id = self.reduced_robot.model.getFrameId("R_ee")
        self.L_sh_id = self.reduced_robot.model.getFrameId("L_shoulder")
        self.L_el_id = self.reduced_robot.model.getFrameId("L_elbow")
        self.L_wr_id = self.reduced_robot.model.getFrameId("L_wrist")
        self.R_sh_id = self.reduced_robot.model.getFrameId("R_shoulder")
        self.R_el_id = self.reduced_robot.model.getFrameId("R_elbow")
        self.R_wr_id = self.reduced_robot.model.getFrameId("R_wrist")

        # Initial joints (14 DoF: 7L + 7R)
        self.init_data = np.zeros(self.reduced_robot.model.nq)
        self.init_data[:7] = np.array([-0.4531, -1.4079, 0.3750, -0.4259, -0.1644, -0.3088, -0.1463], dtype=float)
        self.init_data[7:] = np.array([ 0.4531, -1.4079, 0.3750,  0.4259,  0.1644, -0.3088,  0.1463], dtype=float)

        # Init psi state from initial configuration
        try:
            self.prev_psi_l, self.prev_psi_r = self._compute_psi_np(self.init_data)
        except Exception:
            self.prev_psi_l, self.prev_psi_r = 0.0, 0.0

        # -----------------------------
        # CasADi model
        # -----------------------------
        self.cmodel = cpin.Model(self.reduced_robot.model)
        self.cdata = self.cmodel.createData()

        self.cq = casadi.SX.sym("q", self.reduced_robot.model.nq, 1)
        self.cTf_l = casadi.SX.sym("tf_l", 4, 4)
        self.cTf_r = casadi.SX.sym("tf_r", 4, 4)
        cpin.framesForwardKinematics(self.cmodel, self.cdata, self.cq)

        # ---- symbolic psi ----
        def _safe_norm_sx(v, eps=1e-6):
            return casadi.sqrt(casadi.dot(v, v) + eps)

        def _unit_sx(v):
            return v / _safe_norm_sx(v)

        def _psi_from_points_sx(Ps, Pe, Pw):
            # print(f"Ps: {Ps}, Pe: {Pe}, Pw: {Pw}")
            wu = casadi.SX(self.world_up.tolist())
            a = _unit_sx(Pw - Ps)
            n_arm = _unit_sx(casadi.cross(Pe - Ps, Pw - Ps))
            
            # Handle degeneracy when Pw-Ps nearly parallel to world_up
            n_ref_raw = casadi.cross(wu, Pw - Ps)
            n_ref_norm = _safe_norm_sx(n_ref_raw)
            
            # Use conditional to handle degeneracy
            ex = casadi.SX([1.0, 0.0, 0.0])
            ey = casadi.SX([0.0, 1.0, 0.0])
            
            # Choose reference axis based on dot product with arm axis
            dot_ex_a = casadi.dot(ex, a)
            use_ex = casadi.fabs(dot_ex_a) < 0.95
            ref_dir = casadi.if_else(use_ex, ex, ey)
            
            # Fallback reference when n_ref is too small (increased threshold)
            n_ref_fallback = _unit_sx(casadi.cross(ref_dir, Pw - Ps))
            n_ref = casadi.if_else(n_ref_norm < 1e-4, n_ref_fallback, _unit_sx(n_ref_raw))
            
            s = casadi.dot(casadi.cross(n_ref, n_arm), a)
            c = casadi.dot(n_ref, n_arm)
            return casadi.atan2(s, c)

        Ps_l = self.cdata.oMf[self.L_sh_id].translation
        Pe_l = self.cdata.oMf[self.L_el_id].translation
        Pw_l = self.cdata.oMf[self.L_wr_id].translation
        Ps_r = self.cdata.oMf[self.R_sh_id].translation
        Pe_r = self.cdata.oMf[self.R_el_id].translation
        Pw_r = self.cdata.oMf[self.R_wr_id].translation

        self.psi_l_sx = _psi_from_points_sx(Ps_l, Pe_l, Pw_l)
        self.psi_r_sx = _psi_from_points_sx(Ps_r, Pe_r, Pw_r)

        self.psi_fun = casadi.Function('psi_fun', [self.cq], [self.psi_l_sx, self.psi_r_sx])
        self.psi_grad_fun = casadi.Function(
            'psi_grad_fun',
            [self.cq],
            [casadi.jacobian(self.psi_l_sx, self.cq), casadi.jacobian(self.psi_r_sx, self.cq)]
        )

        # Task-space error (dual ee)
        self.error = casadi.Function(
            "error",
            [self.cq, self.cTf_l, self.cTf_r],
            [casadi.vertcat(
                cpin.log6(self.cdata.oMf[self.L_hand_id].inverse() * cpin.SE3(self.cTf_l)).vector,
                cpin.log6(self.cdata.oMf[self.R_hand_id].inverse() * cpin.SE3(self.cTf_r)).vector
            )],
        )
        self.Jerr_fun = casadi.Function(
            'Jerr_fun',
            [self.cq, self.cTf_l, self.cTf_r],
            [casadi.jacobian(self.error(self.cq, self.cTf_l, self.cTf_r), self.cq)]
        )

        # NLP (IK)
        self.opti = casadi.Opti()
        self.var_q = self.opti.variable(self.reduced_robot.model.nq)
        self.param_tf_l = self.opti.parameter(4, 4)
        self.param_tf_r = self.opti.parameter(4, 4)
        self.param_psi_ref_l = self.opti.parameter()
        self.param_psi_ref_r = self.opti.parameter()

        totalcost = casadi.sumsqr(self.error(self.var_q, self.param_tf_l, self.param_tf_r))
        regularization = casadi.sumsqr(self.var_q)

        # Psi error (weighted loss)
        # Use the existing psi_fun to compute psi from var_q
        psi_l_current, psi_r_current = self.psi_fun(self.var_q)

        # Angle difference with periodicity handling
        psi_l_diff = casadi.atan2(
            casadi.sin(psi_l_current - self.param_psi_ref_l),
            casadi.cos(psi_l_current - self.param_psi_ref_l)
        )
        psi_r_diff = casadi.atan2(
            casadi.sin(psi_r_current - self.param_psi_ref_r),
            casadi.cos(psi_r_current - self.param_psi_ref_r)
        )

        psi_cost = casadi.sumsqr(psi_l_diff) + casadi.sumsqr(psi_r_diff)

        self.opti.subject_to(self.opti.bounded(
            self.reduced_robot.model.lowerPositionLimit,
            self.var_q,
            self.reduced_robot.model.upperPositionLimit
        ))
        # Use psi_weight * 50 as the psi loss weight (so psi_weight=0.2 gives weight=10)
        # Reduced from 500 to avoid numerical instability
        print(f"psi_enabled: {self.psi_enabled}")
        if self.psi_enabled:
            psi_loss_weight = self.psi_weight 
        else:
            psi_loss_weight = 0.0
        self.opti.minimize(20 * totalcost + 0.01 * regularization + psi_loss_weight * psi_cost)

        opts = {
            'ipopt': {
                'print_level': 0,
                'max_iter': 100,
                'tol': 1e-4,
                'constr_viol_tol': 1e-3,
                'acceptable_tol': 1e-3,
                'acceptable_iter': 10,
                'mu_init': 1e-2,
                'barrier_tol_factor': 1e-3
            },
            'print_time': False
        }
        self.opti.solver("ipopt", opts)

    # -----------------------------
    # Numeric psi (robot)
    # -----------------------------
    @staticmethod
    def _unit_np(v, eps=1e-9):
        n = float(np.linalg.norm(v))
        return v / (n + eps)

    @staticmethod
    def _angle_wrap_pi(a):
        """wrap to [-pi, pi]"""
        a = float(a)
        while a > np.pi:
            a -= 2*np.pi
        while a < -np.pi:
            a += 2*np.pi
        return a

    @staticmethod
    def _angle_diff(a, b):
        """minimal (a-b) in [-pi, pi]"""
        return Arm_IK_Casadi_Adapter_Interpolated_Filtered._angle_wrap_pi(float(a) - float(b))

    @staticmethod
    def _adjust_psi_reference(psi_current, psi_target):
        """adjust psi_target by 2pi*k to be closest to psi_current"""
        psi_current = float(psi_current)
        psi_target = float(psi_target)
        diff = psi_target - psi_current
        while diff > np.pi:
            diff -= 2*np.pi
        while diff < -np.pi:
            diff += 2*np.pi
        return Arm_IK_Casadi_Adapter_Interpolated_Filtered._angle_wrap_pi(psi_current + diff)

    def _psi_from_points_np(self, Ps, Pe, Pw):
        """
        Robust psi computation from 3 points.
        Uses reference plane normal n_ref = cross(world_up, Pw-Ps).
        Handles degeneracy when Pw-Ps nearly parallel to world_up.
        """
        Ps = np.asarray(Ps, dtype=float).reshape(3,)
        Pe = np.asarray(Pe, dtype=float).reshape(3,)
        Pw = np.asarray(Pw, dtype=float).reshape(3,)

        a = self._unit_np(Pw - Ps)
        n_arm = np.cross(Pe - Ps, Pw - Ps)
        n_arm = self._unit_np(n_arm)

        n_ref_raw = np.cross(self.world_up, Pw - Ps)
        if float(np.linalg.norm(n_ref_raw)) < 1e-6:
            # fallback: choose another reference axis not collinear with arm axis
            ex = np.array([1.0, 0.0, 0.0])
            ey = np.array([0.0, 1.0, 0.0])
            ref_dir = ex if abs(float(np.dot(ex, a))) < 0.95 else ey
            n_ref_raw = np.cross(ref_dir, Pw - Ps)
        n_ref = self._unit_np(n_ref_raw)

        s = float(np.dot(np.cross(n_ref, n_arm), a))
        c = float(np.dot(n_ref, n_arm))
        return float(np.arctan2(s, c))

    def _compute_psi_np(self, q):
        pin.framesForwardKinematics(self.reduced_robot.model, self.reduced_robot.data, q)
        pin.updateFramePlacements(self.reduced_robot.model, self.reduced_robot.data)

        Ps_l = self.reduced_robot.data.oMf[self.L_sh_id].translation
        Pe_l = self.reduced_robot.data.oMf[self.L_el_id].translation
        Pw_l = self.reduced_robot.data.oMf[self.L_wr_id].translation

        Ps_r = self.reduced_robot.data.oMf[self.R_sh_id].translation
        Pe_r = self.reduced_robot.data.oMf[self.R_el_id].translation
        Pw_r = self.reduced_robot.data.oMf[self.R_wr_id].translation

        return (self._psi_from_points_np(Ps_l, Pe_l, Pw_l),
                self._psi_from_points_np(Ps_r, Pe_r, Pw_r))

    # -----------------------------
    # Nullspace projector + psi correction
    # -----------------------------
    def _nullspace_projector(self, J, damping=1e-6):
        m, n = J.shape
        JJt = J @ J.T
        A = JJt + float(damping) * np.eye(m)
        X = np.linalg.solve(A, J)   # (m x m)^{-1} (m x n) -> (m x n)
        N = np.eye(n) - J.T @ X
        return N

    def _apply_psi_nullspace_correction(self, q, left_pose, right_pose,
                                        psi_ref_l, psi_ref_r,
                                        steps=3, gain=0.2, damping=1e-6,
                                        verbose=False):
        nq = self.reduced_robot.model.nq
        q = np.asarray(q, dtype=float).reshape(nq,).copy()

        lower = np.asarray(self.reduced_robot.model.lowerPositionLimit, dtype=float).reshape(-1)
        upper = np.asarray(self.reduced_robot.model.upperPositionLimit, dtype=float).reshape(-1)

        psi_ref_l = float(psi_ref_l)
        psi_ref_r = float(psi_ref_r)

        for _ in range(int(steps)):
            q_col = q.reshape(nq, 1)

            psi_l_dm, psi_r_dm = self.psi_fun(q_col)
            psi_l = float(psi_l_dm)
            psi_r = float(psi_r_dm)

            pin.framesForwardKinematics(self.reduced_robot.model, self.reduced_robot.data, q)
            pin.updateFramePlacements(self.reduced_robot.model, self.reduced_robot.data)

            Ps_l = self.reduced_robot.data.oMf[self.L_sh_id].translation
            Pe_l = self.reduced_robot.data.oMf[self.L_el_id].translation
            Pw_l = self.reduced_robot.data.oMf[self.L_wr_id].translation

            Ps_r = self.reduced_robot.data.oMf[self.R_sh_id].translation
            Pe_r = self.reduced_robot.data.oMf[self.R_el_id].translation
            Pw_r = self.reduced_robot.data.oMf[self.R_wr_id].translation

            # print(f"[Position Info] Left Arm - Shoulder: {Ps_l}, Elbow: {Pe_l}, Wrist: {Pw_l}")
            # print(f"[Position Info] Right Arm - Shoulder: {Ps_r}, Elbow: {Pe_r}, Wrist: {Pw_r}")

            # adjust targets for periodicity
            psi_ref_l_adj = self._adjust_psi_reference(psi_l, psi_ref_l)
            psi_ref_r_adj = self._adjust_psi_reference(psi_r, psi_ref_r)

            diff_l = self._angle_diff(psi_l, psi_ref_l_adj)
            diff_r = self._angle_diff(psi_r, psi_ref_r_adj)

            g_l_dm, g_r_dm = self.psi_grad_fun(q_col)
            g_l = np.array(g_l_dm, dtype=float).reshape(-1)[:nq]
            g_r = np.array(g_r_dm, dtype=float).reshape(-1)[:nq]

            grad = diff_l * g_l + diff_r * g_r

            J_dm = self.Jerr_fun(q_col, left_pose, right_pose)
            J = np.array(J_dm, dtype=float).reshape(12, nq)

            N = self._nullspace_projector(J, damping=damping)

            total_err = abs(diff_l) + abs(diff_r)
            adaptive_gain = float(gain) * (1.0 + min(total_err / np.pi, 1.0))
            dq = -adaptive_gain * (N @ grad)

            q = np.clip(q + dq, lower, upper)

            if verbose:
                print(f"[psi] psi_l={psi_l:+.3f}, ref={psi_ref_l:+.3f}, diff={diff_l:+.3f} | "
                      f"psi_r={psi_r:+.3f}, ref={psi_ref_r:+.3f}, diff={diff_r:+.3f} | "
                      f"gain={adaptive_gain:.3f}")

        return q

    # -----------------------------
    # IK solve
    # -----------------------------
    def ik_fun(self, left_pose, right_pose, motorstate=None, motorV=None, psi_ref_l=None, psi_ref_r=None):
        if motorstate is not None:
            self.init_data = np.asarray(motorstate, dtype=float).copy()

        self.opti.set_initial(self.var_q, self.init_data)
        self.opti.set_value(self.param_tf_l, left_pose)
        self.opti.set_value(self.param_tf_r, right_pose)

        # Determine psi reference
        if psi_ref_l is not None and psi_ref_r is not None:
            psi_ref_l_base, psi_ref_r_base = float(psi_ref_l), float(psi_ref_r)
        elif self.psi_mode == 'zero':
            psi_ref_l_base, psi_ref_r_base = 0.0, 0.0
        elif self.psi_mode == 'target' and (self.psi_target is not None):
            psi_ref_l_base, psi_ref_r_base = float(self.psi_target), float(self.psi_target)
        else:
            psi_ref_l_base, psi_ref_r_base = float(self.prev_psi_l), float(self.prev_psi_r)

        # Set psi reference parameters for weighted loss optimization
        if self.psi_enabled:
            self.opti.set_value(self.param_psi_ref_l, psi_ref_l_base)
            self.opti.set_value(self.param_psi_ref_r, psi_ref_r_base)
        else:
            # Disable psi optimization by setting very small weight
            self.opti.set_value(self.param_psi_ref_l, 0.0)
            self.opti.set_value(self.param_psi_ref_r, 0.0)

        try:
            sol = self.opti.solve_limited()
            sol_q = np.asarray(self.opti.value(self.var_q), dtype=float).reshape(-1)

            # update psi memory
            try:
                self.prev_psi_l, self.prev_psi_r = self._compute_psi_np(sol_q)
            except Exception:
                pass

            # velocity (not used here)
            if motorV is not None:
                v = np.asarray(motorV, dtype=float) * 0.0
            else:
                v = (sol_q - self.init_data) * 0.0

            self.init_data = sol_q

            tau_ff = pin.rnea(self.reduced_robot.model, self.reduced_robot.data,
                              sol_q, v, np.zeros(self.reduced_robot.model.nv))
            return sol_q, tau_ff

        except Exception as e:
            print(f"ERROR in IK convergence: {e}")
            return self.init_data, None

    # -----------------------------
    # Pose loaders (robot EE target)
    # -----------------------------
    def load_poses_from_txt(self, poses_file):
        """
        Each line: left [x y z qw qx qy qz] + right [x y z qw qx qy qz] = 14 floats
        (Quaternion is wxyz)
        """
        poses = []
        with open(poses_file, 'r') as f:
            for i, line in enumerate(f):
                line = line.strip()
                if not line:
                    continue
                vals = list(map(float, line.replace(',', ' ').split()))
                if len(vals) != 14:
                    print(f"Warning: Invalid pose data at line {i+1}, expected 14 floats, got {len(vals)}")
                    continue

                left = vals[:7]
                right = vals[7:]

                left_pos = np.array(left[:3], dtype=float)
                qx, qy, qz, qw = left[3:]
                left_rot = pin.Quaternion(qw, qx, qy, qz).toRotationMatrix()
                Tl = np.eye(4)
                Tl[:3, :3] = left_rot
                Tl[:3, 3] = left_pos

                right_pos = np.array(right[:3], dtype=float)
                qx, qy, qz, qw = right[3:]
                right_rot = pin.Quaternion(qw, qx, qy, qz).toRotationMatrix()
                Tr = np.eye(4)
                Tr[:3, :3] = right_rot
                Tr[:3, 3] = right_pos

                poses.append((Tl, Tr))

        return poses

    # -----------------------------
    # Corrected human psi loader (MAIN FIX)
    # -----------------------------
    @staticmethod
    def _quat_wxyz_to_R(quat_wxyz):
        qw, qx, qy, qz = map(float, quat_wxyz)
        return pin.Quaternion(qw, qx, qy, qz).toRotationMatrix()

    @staticmethod
    def _parse_block_pose_wxyz(block, idx):
        base = idx * 7
        p = np.array(block[base:base+3], dtype=float)
        q = block[base+3:base+7]  # qw,qx,qy,qz
        R = Arm_IK_Casadi_Adapter_Interpolated_Filtered._quat_wxyz_to_R(q)
        return p, R

    def load_human_psi_from_txt(self,
                               poses_file,
                               upper_arm_length=0.30,
                               forearm_length=0.26,
                               bone_axis_local=(0.0, 0.0, 1.0),
                               use_wrist_position_correction=True,
                               wrist_correction_alpha=0.35,
                               verbose=False):
        """
        Each line: 56 floats = (left 4 segments + right 4 segments) * 7
          seg order per arm:
            0 shoulder: xyz + qw qx qy qz
            1 upperarm: xyz + qw qx qy qz
            2 forearm : xyz + qw qx qy qz
            3 wrist   : xyz + qw qx qy qz
        Assumptions: quaternion is WORLD orientation of each segment frame.

        Joint reconstruction:
          Pe = Ps + R_upperarm * (bone_axis_local * L_upper)
          Pw_pred = Pe + R_forearm * (bone_axis_local * L_fore)
          Pw = (1-a)*Pw_pred + a*Pw_meas   (optional correction)
        """
        bone_axis_local = np.array(bone_axis_local, dtype=float).reshape(3,)
        L1 = float(upper_arm_length)
        L2 = float(forearm_length)
        a = float(np.clip(wrist_correction_alpha, 0.0, 1.0))

        psi_list = []
        with open(poses_file, 'r') as f:
            for lineno, line in enumerate(f, start=1):
                s = line.strip()
                if not s:
                    continue
                try:
                    data = list(map(float, s.replace(',', ' ').split()))
                except ValueError:
                    if verbose:
                        print(f"[human_psi] line {lineno}: parse fail")
                    continue

                if len(data) != 56:
                    if verbose:
                        print(f"[human_psi] line {lineno}: expected 56 floats, got {len(data)}")
                    continue

                left = data[:28]
                right = data[28:]

                try:
                    Ps_l, _Rsh_l = self._parse_block_pose_wxyz(left, 0)
                    _Pua_l, Rua_l = self._parse_block_pose_wxyz(left, 1)
                    _Pfa_l, Rfa_l = self._parse_block_pose_wxyz(left, 2)
                    Pw_l_meas, _Rw_l = self._parse_block_pose_wxyz(left, 3)

                    Ps_r, _Rsh_r = self._parse_block_pose_wxyz(right, 0)
                    _Pua_r, Rua_r = self._parse_block_pose_wxyz(right, 1)
                    _Pfa_r, Rfa_r = self._parse_block_pose_wxyz(right, 2)
                    Pw_r_meas, _Rw_r = self._parse_block_pose_wxyz(right, 3)

                    Pe_l = Ps_l + (Rua_l @ (bone_axis_local * L1))
                    Pe_r = Ps_r + (Rua_r @ (bone_axis_local * L1))

                    Pw_l_pred = Pe_l + (Rfa_l @ (bone_axis_local * L2))
                    Pw_r_pred = Pe_r + (Rfa_r @ (bone_axis_local * L2))

                    if use_wrist_position_correction:
                        Pw_l = (1.0 - a) * Pw_l_pred + a * Pw_l_meas
                        Pw_r = (1.0 - a) * Pw_r_pred + a * Pw_r_meas
                    else:
                        Pw_l, Pw_r = Pw_l_pred, Pw_r_pred

                    psi_l = self._psi_from_points_np(Ps_l, Pe_l, Pw_l)
                    psi_r = self._psi_from_points_np(Ps_r, Pe_r, Pw_r)
                    psi_list.append((psi_l, psi_r))

                    if verbose and lineno <= 3:
                        print(f"[human_psi] line {lineno}: "
                              f"psi_l={psi_l:+.3f}, psi_r={psi_r:+.3f}")

                except Exception as e:
                    if verbose:
                        print(f"[human_psi] line {lineno}: compute fail: {e}")
                    continue

        return psi_list

    # -----------------------------
    # Realtime filtering/interp (optional)
    # -----------------------------
    def apply_realtime_filter(self, joint_angles):
        if not self.filter_enabled:
            return joint_angles

        joint_angles = np.asarray(joint_angles, dtype=float)

        if self.filter_type == 'ema':
            if self.ema_filtered is None:
                self.ema_filtered = joint_angles.copy()
                return joint_angles

            if self.adaptive:
                velocity = joint_angles - self.ema_filtered
                vmag = float(np.linalg.norm(velocity))
                max_velocity = 1.0
                vnorm = min(vmag / max_velocity, 1.0)
                adaptive_alpha = self.alpha + 0.3 * vnorm
                adaptive_alpha = float(np.clip(adaptive_alpha, 0.1, 0.9))
            else:
                adaptive_alpha = float(self.alpha)

            self.ema_filtered = adaptive_alpha * joint_angles + (1 - adaptive_alpha) * self.ema_filtered
            return self.ema_filtered

        if self.filter_type == 'wma' and WeightedMovingFilter is not None:
            if not hasattr(self, 'wma_filter'):
                self.wma_filter = WeightedMovingFilter([0.4, 0.3, 0.2, 0.1], data_size=14)
            self.wma_filter.add_data(joint_angles)
            return self.wma_filter.filtered_data

        return joint_angles

    def process_ik_solution_realtime(self, sol_q):
        processed = []
        sol_q = np.asarray(sol_q, dtype=float)

        if not self.interp_enabled:
            processed.append(self.apply_realtime_filter(sol_q))
            return processed, True

        if self.prev_joint is None:
            self.prev_joint = sol_q
            processed.append(self.apply_realtime_filter(sol_q))
            return processed, True

        if len(self.interp_buffer) > 0:
            for j in self.interp_buffer:
                processed.append(self.apply_realtime_filter(j))
            self.interp_buffer = []
            return processed, False

        step = (sol_q - self.prev_joint) / float(self.interp_factor)
        for k in range(1, int(self.interp_factor) + 1):
            if k < self.interp_factor:
                self.interp_buffer.append(self.prev_joint + step * k)
            else:
                self.prev_joint = sol_q
                processed.append(self.apply_realtime_filter(sol_q))

        if len(self.interp_buffer) > 0:
            for j in self.interp_buffer:
                processed.append(self.apply_realtime_filter(j))
            self.interp_buffer = []

        return processed, True

    def reset_realtime_state(self):
        self.prev_joint = None
        self.interp_buffer = []
        self.ema_filtered = None
        if hasattr(self, 'wma_filter'):
            del self.wma_filter

    def set_realtime_config(self, interp_enabled=True, interp_factor=10,
                            filter_enabled=True, filter_type='ema',
                            alpha=0.3, adaptive=True):
        self.interp_enabled = bool(interp_enabled)
        self.interp_factor = int(interp_factor)
        self.filter_enabled = bool(filter_enabled)
        self.filter_type = str(filter_type)
        self.alpha = float(alpha)
        self.adaptive = bool(adaptive)

    # -----------------------------
    # Batch processing helpers
    # -----------------------------
    def process_poses_realtime(self, poses_file, human_psi=None):
        self.reset_realtime_state()
        poses = self.load_poses_from_txt(poses_file)
        out = []

        if human_psi is not None and len(human_psi) != len(poses):
            print(f"Warning: human psi length {len(human_psi)} != poses {len(poses)} (will use min length).")

        for i, (Tl, Tr) in enumerate(poses):
            psi_ref_l = psi_ref_r = None
            if human_psi is not None and i < len(human_psi):
                psi_ref_l, psi_ref_r = human_psi[i]

            sol_q, _ = self.ik_fun(Tl, Tr, psi_ref_l=psi_ref_l, psi_ref_r=psi_ref_r)
            processed, _ = self.process_ik_solution_realtime(sol_q)
            out.extend(processed)

        return out


def main():
    parser = argparse.ArgumentParser(description='Dual-arm IK + corrected human psi loader (wxyz, world-based).')
    parser.add_argument('--urdf', type=str, default="assets/myself/Rock_C05_grip.urdf")
    parser.add_argument('--urdf-dir', type=str, default='assets')
    parser.add_argument('--poses', type=str, default="data/arm_poses.txt",
                        help='Robot EE target poses: each line 14 floats (L xyz qwxyz + R xyz qwxyz).')
    parser.add_argument('--output', type=str, default="data/result_1.txt",
                        help='Output CSV of joint angles (14 cols).')

    parser.add_argument('--realtime', action='store_true', default=True)
    parser.add_argument('--interpolate', action='store_true', default=True)
    parser.add_argument('--interp-factor', type=int, default=10)
    parser.add_argument('--filter-type', type=str, default='ema', choices=['ema', 'wma', 'none'])
    parser.add_argument('--alpha', type=float, default=0.3)
    parser.add_argument('--adaptive', action='store_true', default=True)

    # Psi bias
    psi_group = parser.add_mutually_exclusive_group()
    psi_group.add_argument('--psi-enabled', action='store_true', default=True)
    psi_group.add_argument('--psi-disabled', action='store_true',default=True)
    parser.add_argument('--psi-weight', type=float, default=0.2,
                        help='Weight for psi error in the optimization objective function (multiplied by 500)')
    parser.add_argument('--world-up', type=str, default='0,0,1')
    parser.add_argument('--psi-mode', type=str, default='hold', choices=['hold', 'zero', 'target'])
    parser.add_argument('--psi-target', type=float, default=None)

    # Human psi input
    parser.add_argument('--human-poses', type=str, default="data/arm_poses_7DOF.txt",
                        help='Human segment poses: each line 56 floats (left 4 seg + right 4 seg), each seg xyz+qwxyz.')
    parser.add_argument('--upper-arm-length', type=float, default=0.30)
    parser.add_argument('--forearm-length', type=float, default=0.26)
    parser.add_argument('--bone-axis', type=str, default='0,0,-1',
                        help='Local bone axis in each segment frame (default +Z). If psi sign is flipped, try 0,0,-1.')
    parser.add_argument('--wrist-corr', action='store_true', default=False)
    parser.add_argument('--wrist-alpha', type=float, default=0.35)

    parser.add_argument('--debug', action='store_true', default=False)
    parser.add_argument('--verbose', action='store_true', default=False)
    parser.add_argument('--log-file', type=str, default=None)

    args = parser.parse_args()

    world_up = tuple(map(float, args.world_up.split(',')))
    bone_axis = tuple(map(float, args.bone_axis.split(',')))

    ik = Arm_IK_Casadi_Adapter_Interpolated_Filtered(
        args.urdf, args.urdf_dir,
        debug=args.debug, verbose=args.verbose, log_file=args.log_file,
        psi_enabled=(not args.psi_disabled),
        psi_weight=args.psi_weight,
        world_up=world_up,
        psi_mode=args.psi_mode,
        psi_target=args.psi_target
    )

    human_psi = None
    if args.human_poses:
        print(f"Loading human psi from: {args.human_poses}")
        human_psi = ik.load_human_psi_from_txt(
            args.human_poses,
            upper_arm_length=args.upper_arm_length,
            forearm_length=args.forearm_length,
            bone_axis_local=bone_axis,
            use_wrist_position_correction=bool(args.wrist_corr),
            wrist_correction_alpha=args.wrist_alpha,
            verbose=args.verbose
        )
        print(f"Loaded {len(human_psi)} human psi frames")

    ik.set_realtime_config(
        interp_enabled=bool(args.interpolate),
        interp_factor=int(args.interp_factor),
        filter_enabled=(args.filter_type != 'none'),
        filter_type=('ema' if args.filter_type == 'ema' else ('wma' if args.filter_type == 'wma' else 'ema')),
        alpha=float(args.alpha),
        adaptive=bool(args.adaptive)
    )

    processed = ik.process_poses_realtime(args.poses, human_psi=human_psi)

    # Save CSV
    output_file = Path(args.output)
    output_file.parent.mkdir(parents=True, exist_ok=True)
    header = ",".join([f"joint_{i+1}" for i in range(14)])

    with open(output_file, 'w') as f:
        f.write(header + "\n")
        for q in processed:
            q = np.asarray(q, dtype=float).reshape(-1)
            f.write(",".join([f"{v:.6f}" for v in q.tolist()]) + "\n")

    print(f"Saved {len(processed)} samples to: {output_file}")
    print("Tip: If psi sign is flipped, rerun with --bone-axis 0,0,-1")


if __name__ == "__main__":
    main()
