#!/usr/bin/env python3
"""
Simple UDP Receiver to display received JSON data.
Useful for debugging example_send_fixed_joints.py
"""

import socket
import json
import argparse

def main():
    parser = argparse.ArgumentParser(description='Receive and print UDP JSON packets')
    parser.add_argument('--ip', type=str, default="127.0.0.1", help='Listen IP address')
    parser.add_argument('--port', type=int, default=9001, help='Listen port')
    
    args = parser.parse_args()

    sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    
    try:
        sock.bind((args.ip, args.port))
        print(f"Listening on {args.ip}:{args.port}...")
        print("Press Ctrl+C to stop.")
        
        while True:
            data, addr = sock.recvfrom(4096)  # Buffer size 4096 bytes
            try:
                json_data = json.loads(data.decode('utf-8'))
                print(f"\nReceived from {addr}:")
                print(json.dumps(json_data, indent=2))
            except json.JSONDecodeError:
                print(f"\nReceived raw data from {addr}: {data}")
            except Exception as e:
                print(f"Error processing packet: {e}")
                
    except Exception as e:
        print(f"Socket error: {e}")
    finally:
        sock.close()

if __name__ == "__main__":
    main()
