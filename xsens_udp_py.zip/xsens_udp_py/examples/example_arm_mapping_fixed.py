#!/usr/bin/env python3
"""
使用修复版本的手臂映射示例
基于修复后的UDP接收器，可以正确解析broadcast.sh发送的数据
"""

import sys
import os
import json
import time
from datetime import datetime

# 添加父目录到路径
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

# 使用修复版本的UDP接收器
from modules.xsens_udp_receiver_fixed import XSensUDPReceiverFixed as XSensUDPReceiver
from modules.arm_mapper import ArmMapper
from modules.xsens_data_types import XsensData


class XSensArmMappingProcessor:
    """XSens手臂映射处理器"""
    
    def __init__(self, output_file: str = None, txt_output_file: str = None):
        self.output_file = output_file
        self.txt_output_file = txt_output_file
        self.mapper = ArmMapper()
        self.frame_count = 0
        self.start_time = time.time()
        self.last_stat_time = time.time()
        self.stat_interval = 2.0  # 每2秒统计一次
        
        # 存储历史数据
        self.left_arm_history = []
        self.right_arm_history = []
        self.max_history_size = 100
        
        # 清空txt输出文件
        if self.txt_output_file:
            try:
                with open(self.txt_output_file, 'w') as f:
                    f.write('')
                print(f"已清空txt输出文件: {self.txt_output_file}")
            except Exception as e:
                print(f"清空txt输出文件时出错: {e}")
    
    def process_data(self, xsens_data: XsensData):
        """处理接收到的XSens数据"""
        self.frame_count += 1
        
        # 打印数据摘要
        print(f"\n{'='*60}")
        print(f"Frame {xsens_data.frame_id} - {datetime.now().strftime('%H:%M:%S.%f')[:-3]}")
        print(f"{'='*60}")
        
        # 打印肩膀数据信息
        print("\n肩膀数据信息:")
        print(f"{'='*40}")
        
        # 获取并打印左肩数据
        left_shoulder_link = self.mapper.get_link_data(xsens_data, "left_shoulder")
        if left_shoulder_link:
            print("左肩:")
            print(f"  位置: X={left_shoulder_link.link_state.position[0]:.6f}, Y={left_shoulder_link.link_state.position[1]:.6f}, Z={left_shoulder_link.link_state.position[2]:g}")
            print(f"  姿态 (四元数): X={left_shoulder_link.link_state.orientation.x:.6f}, Y={left_shoulder_link.link_state.orientation.y:.6f}, Z={left_shoulder_link.link_state.orientation.z:.6f}, W={left_shoulder_link.link_state.orientation.w:.6f}")
        else:
            print("左肩: 未找到数据")
        
        # 获取并打印右肩数据
        right_shoulder_link = self.mapper.get_link_data(xsens_data, "right_shoulder")
        if right_shoulder_link:
            print("右肩:")
            print(f"  位置: X={right_shoulder_link.link_state.position[0]:.6f}, Y={right_shoulder_link.link_state.position[1]:.6f}, Z={right_shoulder_link.link_state.position[2]:g}")
            print(f"  姿态 (四元数): X={right_shoulder_link.link_state.orientation.x:.6f}, Y={right_shoulder_link.link_state.orientation.y:.6f}, Z={right_shoulder_link.link_state.orientation.z:.6f}, W={right_shoulder_link.link_state.orientation.w:.6f}")
        else:
            print("右肩: 未找到数据")
        print(f"{'='*40}")
        
        # 映射双臂
        left_result, right_result = self.mapper.map_both_arms(xsens_data)
        
        # 统计帧率
        current_time = time.time()
        if current_time - self.last_stat_time >= self.stat_interval:
            elapsed = current_time - self.last_stat_time
            fps = self.frame_count / elapsed
            print(f"\n接收速率: {fps:.1f} FPS")
            self.frame_count = 0
            self.last_stat_time = current_time
        
        # 处理左臂
        if left_result.success:
            self._process_arm_result(left_result, "左臂")
            self._store_history(self.left_arm_history, left_result)
        else:
            print("左臂: 映射失败")
        
        # 处理右臂
        if right_result.success:
            self._process_arm_result(right_result, "右臂")
            self._store_history(self.right_arm_history, right_result)
        else:
            print("右臂: 映射失败")
        
        # 保存数据到文件
        if self.output_file:
            self._save_data(xsens_data, left_result, right_result)
        
        # 保存到txt文件
        if self.txt_output_file:
            self._save_to_txt(left_result, right_result)
    
    def _process_arm_result(self, result, arm_name: str):
        """处理单个手臂的映射结果"""
        print(f"\n{arm_name}信息:")
        print(f"  手臂长度: {result.arm_length:.4f} 米")
        print(f"  末端位置 (肩膀坐标系):")
        print(f"    X: {result.end_effector_position[0]:.6f} 米")
        print(f"    Y: {result.end_effector_position[1]:.6f} 米")
        print(f"    Z: {result.end_effector_position[2]:.6f} 米")
        
        # 计算欧拉角
        from modules.arm_mapper import ArmMapper
        mapper = ArmMapper()
        euler_angles = mapper.rotation_matrix_to_euler(result.end_effector_orientation)
        print(f"  末端姿态 (欧拉角):")
        print(f"    Roll:  {euler_angles[0]*180/3.14159:.2f}°")
        print(f"    Pitch: {euler_angles[1]*180/3.14159:.2f}°")
        print(f"    Yaw:   {euler_angles[2]*180/3.14159:.2f}°")
    
    def _store_history(self, history: list, result):
        """存储历史数据"""
        history.append({
            'timestamp': time.time(),
            'position': result.end_effector_position.copy(),
            'orientation': result.end_effector_orientation.copy(),
            'arm_length': result.arm_length
        })
        
        # 限制历史数据大小
        if len(history) > self.max_history_size:
            history.pop(0)
    
    def _save_data(self, xsens_data: XsensData, left_result, right_result):
        """保存数据到文件"""
        try:
            import json
            
            data_dict = {
                'frame_id': xsens_data.frame_id,
                'time_stamp': xsens_data.time_stamp,
                'timestamp': datetime.now().isoformat(),
                'left_arm': {
                    'success': left_result.success,
                    'arm_length': left_result.arm_length,
                    'end_effector_position': left_result.end_effector_position.tolist(),
                    'end_effector_orientation': left_result.end_effector_orientation.tolist()
                } if left_result.success else {'success': False},
                'right_arm': {
                    'success': right_result.success,
                    'arm_length': right_result.arm_length,
                    'end_effector_position': right_result.end_effector_position.tolist(),
                    'end_effector_orientation': right_result.end_effector_orientation.tolist()
                } if right_result.success else {'success': False}
            }
            
            with open(self.output_file, 'w', encoding='utf-8') as f:
                json.dump(data_dict, f, indent=2, ensure_ascii=False)
            
        except Exception as e:
            print(f"保存数据时出错: {e}")
    
    def _save_to_txt(self, left_result, right_result):
        """保存手臂映射结果到txt文件
        格式：左手xyz+xyzw 右手xyz+xyzw
        例如：0.159924 0.420383 -0.562747 0.140419 -0.171156 0.045398 0.974129 0.159034 -0.41727 -0.563578 -0.241686 -0.211582 0.00531693 0.946991
        """
        try:
            # 构建数据字符串
            data_parts = []
            
            # 左手数据
            if left_result.success:
                # 位置 (xyz)
                pos = left_result.end_effector_position
                data_parts.extend([f"{pos[0]:.6f}", f"{pos[1]:.6f}", f"{pos[2]:.6f}"])
                
                # 四元数 (xyzw)
                quat = left_result.end_effector_orientation_quat
                data_parts.extend([f"{quat[0]:.6f}", f"{quat[1]:.6f}", f"{quat[2]:.6f}", f"{quat[3]:.6f}"])
            else:
                # 如果失败，使用默认值
                data_parts.extend(["0.0"] * 7)
            
            # 右手数据
            if right_result.success:
                # 位置 (xyz)
                pos = right_result.end_effector_position
                data_parts.extend([f"{pos[0]:.6f}", f"{pos[1]:.6f}", f"{pos[2]:.6f}"])
                
                # 四元数 (xyzw)
                quat = right_result.end_effector_orientation_quat
                data_parts.extend([f"{quat[0]:.6f}", f"{quat[1]:.6f}", f"{quat[2]:.6f}", f"{quat[3]:.6f}"])
            else:
                # 如果失败，使用默认值
                data_parts.extend(["0.0"] * 7)
            
            # 写入文件（追加模式）
            with open(self.txt_output_file, 'a') as f:
                f.write(','.join(data_parts) + '\n')
            
        except Exception as e:
            print(f"保存到txt文件时出错: {e}")

    def print_statistics(self):
        """打印统计信息"""
        total_time = time.time() - self.start_time
        print(f"\n统计信息:")
        print(f"  总运行时间: {total_time:.1f} 秒")
        print(f"  总帧数: {self.frame_count}")
        if total_time > 0:
            print(f"  平均帧率: {self.frame_count/total_time:.1f} FPS")


def main():
    """主函数"""
    print("="*60)
    print("XSens手臂映射（修复版本）")
    print("="*60)
    
    # 配置参数
    UDP_IP = "0.0.0.0"
    # UDP_IP = "127.0.0.1"   
    UDP_PORT = 9763
    BUFFER_SIZE = 10000
    OUTPUT_FILE = "arm_mapping_data.json"
    TXT_OUTPUT_FILE = "arm_mapping_results.txt"
    
    # 创建处理器
    processor = XSensArmMappingProcessor(output_file=OUTPUT_FILE, txt_output_file=TXT_OUTPUT_FILE)
    
    # 创建接收器
    receiver = XSensUDPReceiver(
        ip=UDP_IP,
        port=UDP_PORT,
        buffer_size=BUFFER_SIZE
    )
    
    # 初始化
    print(f"\n初始化接收器...")
    print(f"  IP地址: {UDP_IP}")
    print(f"  端口: {UDP_PORT}")
    print(f"  缓冲区大小: {BUFFER_SIZE}")
    
    if not receiver.initialize():
        print("初始化失败!")
        return
    
    print("初始化成功!")
    
    # 设置数据回调
    receiver.set_data_callback(processor.process_data)
    
    # 开始接收
    print(f"\n开始接收数据...")
    print(f"数据将保存到: {OUTPUT_FILE}")
    print(f"手臂映射结果将保存到: {TXT_OUTPUT_FILE}")
    print(f"按 Ctrl+C 停止接收")
    print("="*60)
    
    if not receiver.start_receiving():
        print("启动接收失败!")
        return
    
    try:
        # 保持运行
        while True:
            time.sleep(1)
            
    except KeyboardInterrupt:
        print("\n\n接收到停止信号...")
        print("正在停止接收器...")
        receiver.stop_receiving()
        
        # 打印统计信息
        processor.print_statistics()
        
        print("\n程序已退出")


if __name__ == "__main__":
    main()
