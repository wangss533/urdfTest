r'''
Author: uidq5094 Saisai.Wang@desaysv.com
Date: 2026-01-30 09:15:12
LastEditors: uidq5094 Saisai.Wang@desaysv.com
LastEditTime: 2026-01-30 11:29:32
FilePath: \xsens_udp_py\examples\example_send_fixed_joints.py
Description: 这是默认设置,请设置`customMade`, 打开koroFileHeader查看配置 进行设置: https://github.com/OBKoro1/koro1FileHeader/wiki/%E9%85%8D%E7%BD%AE
'''
#!/usr/bin/env python3
"""
示例：向指定IP发送固定的双臂关节角度信息
"""

import sys
import os
import time
import argparse

# 添加父目录到路径，以便导入模块
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from modules.udp_sender import UDPSender

def main():
    parser = argparse.ArgumentParser(description='Send fixed joint angles via UDP')
    parser.add_argument('--ip', type=str, default="192.168.100.16", help='Target IP address')
    # parser.add_argument('--ip', type=str, default="127.0.0.1", help='Target IP address')
    parser.add_argument('--port', type=int, default=9001, help='Target port')
    parser.add_argument('--loop', action='store_true', help='Send continuously in a loop')
    parser.add_argument('--count', type=int, default=-1, help='Number of frames to send in loop mode (default: -1 for infinite)')
    parser.add_argument('--interval', type=float, default=0.02, help='Interval between packets in seconds (if looping)')
    
    args = parser.parse_args()

    # 初始化UDP发送器
    sender = UDPSender(ip=args.ip, port=args.port)
    
    # 定义固定的关节角度 (弧度)
    # 假设每个手臂有7个自由度
    # 左臂关节角度
    left_joints = [
        -0.4531,    # Joint 1
        -1.4079,    # Joint 2
        0.3750,     # Joint 3
        -0.4259,    # Joint 4
        -0.1644,    # Joint 5
        -0.3088,    # Joint 6
        -0.1463     # Joint 7
    ]
    
    # 右臂关节角度
    right_joints = [
        0.4531,     # Joint 1
        -1.4079,    # Joint 2
        0.3750,     # Joint 3
        0.4259,     # Joint 4
        0.1644,     # Joint 5
        -0.3088,    # Joint 6
        0.1463      # Joint 7
    ]

    print(f"目标地址: {args.ip}:{args.port}")
    print(f"左臂关节角度: {left_joints}")
    print(f"右臂关节角度: {right_joints}")

    if args.loop:
        print(f"开始连续发送 (间隔 {args.interval} 秒)... 按 Ctrl+C 停止")
        if args.count > 0:
            print(f"将在发送 {args.count} 帧后自动停止")

        try:
            # 参考 C++ udp_demo.cpp 的初始化流程
            # 1) StartFlag
            print("[STEP] StartFlag = true")
            sender.send_control_command(left_joints, right_joints, start_flag=True)
            time.sleep(0.1)

            # 2) SwitchOn
            print("[STEP] SwitchOn = true")
            sender.send_control_command(left_joints, right_joints, switch_on=True)
            time.sleep(0.1)

            # 3) tryLock
            print("[STEP] tryLock = true")
            sender.send_control_command(left_joints, right_joints, try_lock=True)
            time.sleep(0.1)

            # 4) 循环发送关节数据
            print("[INFO] 开始循环发送关节数据...")
            
            # 先尝试读取几帧反馈来获取初始位置
            initial_left = None
            initial_right = None
            print("正在读取机器人初始位置...", end="")
            for _ in range(20):
                fb = sender.receive_feedback()
                if fb:
                    initial_left = fb.get("data", {}).get("Robot", {}).get("AP", [])
                    initial_right = fb.get("data", {}).get("RightArm", {}).get("AP", [])
                    if initial_left and initial_right:
                        print(f" 成功!\n初始左臂: {initial_left}\n初始右臂: {initial_right}")
                        break
                time.sleep(0.05)
                print(".", end="", flush=True)
            print("")

            if not initial_left:
                 print("\n[ERROR] 未能读取到机器人初始位置！")
                 print("[INFO] 为了安全起见，程序将终止运行。")
                 print("[INFO] 请检查：")
                 print("  1. 机器人是否已上电并联网")
                 print("  2. UDP端口 9001 (Control) 和反馈端口是否通畅")
                 print("  3. 目标IP是否正确")
                 
                 # 执行清理并退出
                 print("\n[INFO] 执行退出清理流程...")
                 print("[STEP] StartFlag = false")
                 sender.send_control_command(left_joints, right_joints, start_flag=False)
                 print("[STEP] tryLock = false")
                 sender.send_control_command(left_joints, right_joints, try_lock=False)
                 return # 直接退出 main 函数

            # 目标位置 (Hardcoded in left_joints/right_joints)
            # 运动逻辑：
            # 1. 从初始位置 -> 目标位置 (left_joints, right_joints)
            # 2. 从目标位置 -> 初始位置
            # 3. 循环上述过程
            
            # 记录初始位置
            start_left = list(initial_left)
            start_right = list(initial_right)
            
            # 记录目标位置
            target_left_cfg = list(left_joints)
            target_right_cfg = list(right_joints)
            
            # 当前控制位置
            current_left = list(start_left)
            current_right = list(start_right)
            
            # 状态机：0=去程(Start->Target), 1=回程(Target->Start)
            motion_state = 0 
            
            # 速度参数
            SPEED_STEP = 0.002 # 每次迭代的步长 (rad)
            
            frame_count = 0
            
            while True:
                # 检查是否达到设定帧数
                if args.count > 0 and frame_count >= args.count:
                    print(f"\n[INFO] 已达到设定帧数 ({args.count})，准备退出...")
                    break
                
                # 获取最新反馈以更新实际位置（用于打印和安全检查，但不用于直接驱动指令，避免抖动）
                feedback = sender.receive_feedback()
                real_left_ap = current_left # 默认 fallback
                
                if feedback:
                    try:
                        real_left_ap = feedback.get("data", {}).get("Robot", {}).get("AP", current_left)
                        # real_right_ap = feedback.get("data", {}).get("RightArm", {}).get("AP", current_right)
                    except:
                        pass

                # --- 运动规划逻辑 ---
                # 确定当前的临时目标
                if motion_state == 0:
                    temp_target_l = target_left_cfg
                    temp_target_r = target_right_cfg
                    state_str = "Go->Target"
                else:
                    temp_target_l = start_left
                    temp_target_r = start_right
                    state_str = "Back->Start"

                all_reached = True
                
                # 计算下一帧位置
                for i in range(7):
                    # 左臂
                    diff_l = temp_target_l[i] - current_left[i]
                    if abs(diff_l) > SPEED_STEP:
                        current_left[i] += SPEED_STEP if diff_l > 0 else -SPEED_STEP
                        all_reached = False
                    else:
                        current_left[i] = temp_target_l[i] # 到位吸附
                    
                    # 右臂
                    diff_r = temp_target_r[i] - current_right[i]
                    if abs(diff_r) > SPEED_STEP:
                        current_right[i] += SPEED_STEP if diff_r > 0 else -SPEED_STEP
                        all_reached = False
                    else:
                        current_right[i] = temp_target_r[i]

                # 如果所有关节都到达了临时目标，切换状态
                if all_reached:
                    motion_state = 1 - motion_state # 0->1, 1->0
                    # 可选：到达后停顿一下？
                    # time.sleep(1.0) 
                    print(f"\n[INFO] Reached {state_str}. Switching direction...")

                # 发送指令
                sender.send_control_command(current_left, current_right)
                frame_count += 1
                
                # 打印状态
                if feedback:
                    # 打印 J2 关节的状态
                    print(f"\r[Run] [{state_str}] Cmd J2: {current_left[1]:.3f} | Real J2: {real_left_ap[1]:.3f}", end="", flush=True)
                else:
                    print(".", end="", flush=True)
                
                time.sleep(args.interval)

        except KeyboardInterrupt:
            print("\n[INFO] 接收到停止信号 (Ctrl+C)，正在安全退出...")
            
        finally:
            # 退出流程：无论是因为 Ctrl+C 还是循环结束，都执行清理
            print("\n[INFO] 执行退出清理流程...")
            
            # 参考 C++ udp_demo.cpp 的退出流程
            # 1) StartFlag = false (关闭推送)
            print("[STEP] StartFlag = false")
            for _ in range(3):
                sender.send_control_command(left_joints, right_joints, start_flag=False)
                time.sleep(0.05)
            
            # 2) tryLock = false (释放控制权)
            print("[STEP] tryLock = false")
            for _ in range(3):
                sender.send_control_command(left_joints, right_joints, try_lock=False)
                time.sleep(0.05)
                
            print("[INFO] 控制权已释放，停止发送")
    else:
        print("发送单次数据包...")
        # 单次发送模式下，仅发送数据，假设环境已就绪
        sender.send_control_command(left_joints, right_joints)
        print("发送完成")

if __name__ == "__main__":
    main()
