import rclpy
from rclpy.node import Node
from std_msgs.msg import Float64
import math
import time

class ArmWaver(Node):
    def __init__(self):
        super().__init__('arm_waver_node')
        
        # ================= 配置区域 =================
        # 1. 话题名称：必须和你 gz topic -l 查到的一模一样
        self.topic_name = '/model/r1_pro/joint/left_arm_joint1/cmd_pos'
        
        # 2. 运动参数
        self.speed = 2.0      # 速度 (数值越大越快)
        self.amplitude = 1.0  # 幅度 (摆动范围，单位弧度)
        self.offset = 0.5     # 中心位置 (在哪个角度附近摆动)
        # ===========================================

        # 创建发布者
        self.publisher_ = self.create_publisher(Float64, self.topic_name, 10)
        
        # 创建定时器：0.05秒执行一次 (20Hz)，保证运动平滑
        self.timer = self.create_timer(0.05, self.timer_callback)
        self.start_time = time.time()
        
        self.get_logger().info(f'开始向 {self.topic_name} 发送连续指令...')

    def timer_callback(self):
        # 计算运行时间
        current_time = time.time() - self.start_time
        
        # 使用正弦函数生成平滑曲线
        # 结果会在 (offset - amplitude) 到 (offset + amplitude) 之间变化
        angle = self.offset + self.amplitude * math.sin(self.speed * current_time)
        
        # 打包消息
        msg = Float64()
        msg.data = angle
        
        # 发送
        self.publisher_.publish(msg)
        # self.get_logger().info(f'发送角度: {angle:.2f}') #以此看日志，嫌烦可以注释掉

def main(args=None):
    rclpy.init(args=args)
    node = ArmWaver()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        rclpy.shutdown()

if __name__ == '__main__':
    main()