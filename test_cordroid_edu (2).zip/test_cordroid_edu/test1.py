import time
from gz.transport13 import Node
from gz.msgs10.joint_trajectory_pb2 import JointTrajectory

# 确保这里的名字和 gz topic -l 查到的一模一样
TOPIC = "/codroidRobot/joint_trajectory"

def force_move():
    node = Node()
    pub = node.advertise(TOPIC, JointTrajectory)
    time.sleep(2) # 等待连接

    msg = JointTrajectory()
    msg.joint_names.extend([
        "J_arm_l_01", "J_arm_l_02", "J_arm_l_03", 
        "J_arm_l_04", "J_arm_l_05", "J_arm_l_06", "J_arm_l_07"
    ])
    
    point = msg.points.add()
    # 给一个非常明显的动作：全部转到 1.0 弧度
    point.positions.extend([1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0])
    
    # 给 5 秒钟慢慢动
    point.time_from_start.sec = 5
    point.time_from_start.nsec = 0
    
    print(f"正在发送强力指令到 {TOPIC} ...")
    pub.publish(msg)
    print("指令已发送。")

if __name__ == "__main__":
    while(1):
        force_move()