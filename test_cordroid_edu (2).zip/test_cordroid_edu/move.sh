
gz topic -t "/codroidRobot/joint_trajectory" -m gz.msgs.JointTrajectory -p '
header {
  stamp {
    sec: 0
    nsec: 0
  }
}
joint_names: "J_arm_l_01"
joint_names: "J_arm_l_02"
joint_names: "J_arm_l_03"
joint_names: "J_arm_l_04"
joint_names: "J_arm_l_05"
joint_names: "J_arm_l_06"
joint_names: "J_arm_l_07"
points {
  positions: 0.0
  positions: 0.0
  positions: 0.0
  positions: 0.0
  positions: 0.0
  positions: 0.0
  positions: 0.0
  time_from_start {
    sec: 2
    nsec: 0
  }
}
'