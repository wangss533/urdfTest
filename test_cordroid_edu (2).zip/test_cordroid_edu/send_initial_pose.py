#!/usr/bin/env python3
import rclpy
from rclpy.node import Node
from trajectory_msgs.msg import JointTrajectory, JointTrajectoryPoint

class InitialPosePublisher(Node):
    def __init__(self):
        super().__init__('initial_pose_publisher')
        self.publisher_ = self.create_publisher(
            JointTrajectory, 
            'codroidRobot/joint_trajectory', 
            10
        )
        
        # 延迟1秒发布（确保仿真和控制器已启动）
        self.timer = self.create_timer(1.0, self.publish_initial_pose)

    def publish_initial_pose(self):
        # 创建轨迹消息
        traj_msg = JointTrajectory()
        
        # 填写需要控制的关节名（与URDF中一致）
        traj_msg.joint_names = [
            "J_arm_l_01", "J_arm_l_02", "J_arm_l_03",
            "J_arm_l_04", "J_arm_l_05", "J_arm_l_06", "J_arm_l_07"
        ]
        
        # 创建轨迹点（平举的目标位置，替换为实际需要的弧度值）
        point = JointTrajectoryPoint()
        # 示例：平举对应的关节角度（你需要根据实际机械结构调整这些数值）
        point.positions = [0.0, 0.5, 0.0, 0.0, 0.0, 0.0, 0.0]  # 关键：替换为平举的实际角度
        point.velocities = [0.0] * 7  # 初始速度为0
        point.accelerations = [0.1] * 7  # 小加速度避免冲击
        point.time_from_start.sec = 2  # 2秒内到达目标位置
        
        traj_msg.points = [point]
        
        # 发布消息
        self.publisher_.publish(traj_msg)
        self.get_logger().info("已发布手臂平举初始姿态指令")
        
        # 发布后停止定时器
        self.timer.cancel()

def main(args=None):
    rclpy.init(args=args)
    node = InitialPosePublisher()
    rclpy.spin(node)
    node.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()