import time
from gz.transport13 import Node
from gz.msgs10.joint_trajectory_pb2 import JointTrajectory

# 请务必先通过 gz topic -l 确认这个名字
TOPIC = "/codroidRobot/joint_trajectory" 

def test_move():
    node = Node()
    pub = node.advertise(TOPIC, JointTrajectory)
    
    # 等待 Gazebo 接收端上线
    print("等待连接...")
    time.sleep(2) 
    
    msg = JointTrajectory()
    
    # ！！！这里只测试一个关节，减少干扰！！！
    msg.joint_names.append("J_arm_l_02") 
    
    point = msg.points.add()
    # 让它转动 1.0 弧度 (约57度)
    point.positions.append(1.0)
    
    # 给它足够的时间移动 (1秒)
    point.time_from_start.sec = 1
    point.time_from_start.nsec = 0
    
    print(f"发送指令到 {TOPIC} ...")
    pub.publish(msg)
    print("指令已发送")

if __name__ == "__main__":
    test_move()