gz topic -t "/model/codroidRobot/joint_trajectory" -m gz.msgs.JointTrajectory -p  '
joint_names: "J_arm_l_01"
joint_names: "J_arm_l_02"
points {
  positions: -0.7854
  positions: 1.5708
  time_from_start {
    sec: 0
    nsec: 250000000
  }
}
points {
  positions: -1.5708
  positions: 0
  time_from_start {
    sec: 0
    nsec: 500000000
  }
}
points {
  positions: -1.5708
  positions: -1.5708
  time_from_start {
    sec: 0
    nsec: 750000000
  }
}
points {
  positions: 0
  positions: 0
  time_from_start {
    sec: 1
    nsec: 0
  }
}' 


gz topic -t "/model/codroidRobot/joint_trajectory" -m gz.msgs.JointTrajectory -p  '
joint_names: "J_arm_l_01"
joint_names: "J_arm_l_02"
joint_names: "J_arm_l_03"
joint_names: "J_arm_l_04"
joint_names: "J_arm_l_05"
joint_names: "J_arm_l_06"
joint_names: "J_arm_l_07"
points {
  positions: 0.0
  positions: -1.4
  positions: 0.0
  positions: 0.0
  positions: 0.0
  positions: 0.0
  positions: 0.0

  time_from_start {
    sec: 3
    nsec: 0
  }
  }
points {
  positions: 0.0
  positions: 0.0
  positions: 0.0
  positions: 0.0
  positions: 0.0
  positions: 0.0
  positions: 0.0

  time_from_start {
    sec: 3
    nsec: 0
  }
  }' 