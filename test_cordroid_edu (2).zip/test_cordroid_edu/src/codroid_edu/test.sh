cd /mnt/hgfs/ubuntu24/00.robot/test_cordroid_edu/
ls -l
rm  -rf install log build
colcon build --packages-select codroid_edu
source install/setup.bash


# export GZ_SIM_RESOURCE_PATH=$GZ_SIM_RESOURCE_PATH:/mnt/hgfs/ubuntu24/00.robot/test_cordroid_edu

export GZ_SIM_RENDER_ENGINE="ogre"
ros2  launch codroid_edu  ros2gazebo.launch.py
