import os
from ament_index_python.packages import get_package_share_directory
from launch import LaunchDescription
from launch.actions import IncludeLaunchDescription, SetEnvironmentVariable
from launch.launch_description_sources import PythonLaunchDescriptionSource
from launch_ros.actions import Node
from launch.actions import ExecuteProcess, TimerAction

def generate_launch_description():
    # 1. 获取包路径
    pkg_r1_pro = get_package_share_directory('codroid_edu')
    pkg_ros_gz_sim = get_package_share_directory('ros_gz_sim')

    # 2. 设置 Gazebo 模型路径 (让 Gazebo 能找到 meshes)
    # 假设 meshes 在 r1_pro 包的上级目录 (即 src 目录)
    # 这里通过拼接路径动态设置环境变量
    install_dir = os.path.dirname(os.path.dirname(pkg_r1_pro)) # 获取 install 目录
    # 注意：更稳妥的方式是把 mesh 路径写死或者指向源码目录，这里简化处理
    # 建议手动在终端 export GZ_SIM_RESOURCE_PATH，或者在这里硬编码 src 路径
    
    # 3. 启动 Gazebo (替换 empty_world.launch)
    gazebo = IncludeLaunchDescription(
        PythonLaunchDescriptionSource(
            os.path.join(pkg_ros_gz_sim, 'launch', 'gz_sim.launch.py')
        ),
        launch_arguments={'gz_args': '-r empty.sdf'}.items(),
    )

    # 4. 生成机器人 (替换 spawn_model)
    spawn_entity = Node(
        package='ros_gz_sim',
        executable='create',
        arguments=[
            '-name', 'codroid_edu',
            '-file', os.path.join(pkg_r1_pro, 'urdf', 'codroid_edu_mdh_aligned_gripper_gazebo.urdf'), # 确保文件名对
            '-z', '2.0' # 稍微抬高一点防止卡地里
        ],
        output='screen',
    )

    # 5. 发布静态 TF (替换 tf static_transform_publisher)
    # ROS 2 中 args 格式是: x y z qx qy qz qw frame_id child_frame_id
    # 或者: x y z roll pitch yaw frame_id child_frame_id
    # static_tf = Node(
    #     package='tf2_ros',
    #     executable='static_transform_publisher',
    #     arguments=['0', '0', '0', '0', '0', '0', 'base_link', 'base_footprint'],
    #     output='screen'
    # )
    
    # 6. (可选) Robot State Publisher 
    # 读取 URDF 并发布 /robot_description 话题，这对 ROS 2 非常重要
    robot_state_publisher = Node(
        package='robot_state_publisher',
        executable='robot_state_publisher',
        parameters=[{'robot_description': open(os.path.join(pkg_r1_pro, 'urdf', 'codroid_edu_mdh_aligned_gripper_gazebo.urdf'), 'r').read()}]
    )

        # 发布初始姿态（延迟3秒，确保Gazebo和控制器已就绪）
    initial_pose = Node(
        package='codroid_edu',  # 替换为你的ROS2包名
        executable='send_initial_pose.py',
        output='screen'
    )
    

    return LaunchDescription([
        gazebo,
        robot_state_publisher, # 建议加上这个
        spawn_entity
        # TimerAction(period = 2.0,actions=[spawn_entity]),
        # TimerAction(period=5.0, actions=[initial_pose])
        # static_tf,
    ])