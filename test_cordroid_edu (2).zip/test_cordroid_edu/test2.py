import rclpy
from rclpy.node import Node
from trajectory_msgs.msg import JointTrajectory, JointTrajectoryPoint

class ArmController(Node):
    def __init__(self):
        super().__init__('arm_controller')
        # 发布到 ROS 2 控制器话题
        self.publisher_ = self.create_publisher(
            JointTrajectory, 
            '/left_arm_controller/joint_trajectory', 
            10)
        
    def send_command(self):
        msg = JointTrajectory()
        msg.joint_names = [
            "J_arm_l_01", "J_arm_l_02", "J_arm_l_03", 
            "J_arm_l_04", "J_arm_l_05", "J_arm_l_06", "J_arm_l_07"
        ]
        
        point = JointTrajectoryPoint()
        # 目标: 抬起手臂
        point.positions = [0.5, 0.0, 0.0, -1.57, 0.0, 0.0, 0.0]
        point.time_from_start.sec = 2
        
        msg.points.append(point)
        
        self.get_logger().info('Sending trajectory...')
        self.publisher_.publish(msg)

def main(args=None):
    rclpy.init(args=args)
    node = ArmController()
    
    # 延时一会等待连接
    import time
    time.sleep(2)
    
    node.send_command()
    # rclpy.spin(node) # 如果需要持续监听回调
    node.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()